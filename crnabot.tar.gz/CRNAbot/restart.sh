#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
PORT="${APP_PORT:-80}"
HOST="${APP_HOST:-127.0.0.1}"
PYTHON="$(pwd)/.venv/bin/python3"

lan_urls() {
  local ip port_suffix=""
  if [ "${PORT}" != "80" ]; then
    port_suffix=":${PORT}"
  fi
  for iface in en0 en1 en2; do
    ip="$(ipconfig getifaddr "${iface}" 2>/dev/null || true)"
    if [ -n "${ip}" ]; then
      echo "  http://${ip}${port_suffix}/"
    fi
  done
}

echo "Останавливаю сервер на порту ${PORT}…"
if [ "${PORT}" = "80" ]; then
  pids=$(sudo lsof -ti tcp:"${PORT}" 2>/dev/null || true)
else
  pids=$(lsof -ti tcp:"${PORT}" 2>/dev/null || true)
fi
if [ -n "${pids}" ]; then
  if [ "${PORT}" = "80" ]; then
    sudo kill ${pids} 2>/dev/null || true
  else
    kill ${pids} 2>/dev/null || true
  fi
  sleep 1
  if [ "${PORT}" = "80" ]; then
    pids=$(sudo lsof -ti tcp:"${PORT}" 2>/dev/null || true)
  else
    pids=$(lsof -ti tcp:"${PORT}" 2>/dev/null || true)
  fi
  if [ -n "${pids}" ]; then
    if [ "${PORT}" = "80" ]; then
      sudo kill -9 ${pids} 2>/dev/null || true
    else
      kill -9 ${pids} 2>/dev/null || true
    fi
  fi
fi

echo "Запускаю CRNAbot…"
if [ "${HOST}" = "0.0.0.0" ]; then
  echo "Режим сети: сайт доступен с других компьютеров в Wi‑Fi/офисе."
  echo "На этом Mac: http://crna/ (если настроен setup-hosts.sh)"
  echo "С другого компьютера откройте один из адресов:"
  lan_urls
  echo "Оба устройства должны быть в одной сети."
else
  if [ "${PORT}" = "80" ]; then
    echo "Адрес на этом Mac: http://crna/"
  else
    echo "Адрес на этом Mac: http://crna:${PORT}/"
  fi
fi

if [ "${PORT}" = "80" ]; then
  echo "Для порта 80 нужен пароль администратора Mac."
  sudo APP_HOST="${HOST}" APP_PORT="${PORT}" "${PYTHON}" web_app.py
else
  APP_HOST="${HOST}" APP_PORT="${PORT}" "${PYTHON}" web_app.py
fi
