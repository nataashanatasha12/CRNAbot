#!/usr/bin/env bash
set -euo pipefail
export APP_HOST=0.0.0.0
exec "$(dirname "$0")/restart.sh"
