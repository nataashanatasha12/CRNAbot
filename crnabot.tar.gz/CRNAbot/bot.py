from __future__ import annotations

import asyncio
import logging
import os
import re
import sys
from io import BytesIO
from pathlib import Path

from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

from services.egrul import EgrulError, download_egrul_pdf, search_egrul
from services.girbo import GirBoError, download_document, get_organization, latest_year_documents

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("crnabot")

INN_OGRN_RE = re.compile(r"^\d{10,15}$")


def format_record(record) -> str:
    return (
        f"<b>{record.name}</b>\n"
        f"ИНН: <code>{record.inn}</code>\n"
        f"ОГРН: <code>{record.ogrn}</code>\n"
        f"Адрес: {record.address or '—'}\n"
        f"Статус: {record.status or '—'}\n"
        f"Дата рег.: {record.reg_date or '—'}"
    )


async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.exception("Ошибка при обработке сообщения", exc_info=context.error)
    if isinstance(update, Update) and update.effective_message:
        await update.effective_message.reply_text(
            "Произошла ошибка. Попробуйте ещё раз или отправьте /start."
        )


async def post_init(app: Application) -> None:
    me = await app.bot.get_me()
    logger.info("Бот запущен: @%s (id=%s)", me.username, me.id)
    logger.info("Пишите этому боту в Telegram: https://t.me/%s", me.username)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.info("Команда /start от user_id=%s", update.effective_user.id if update.effective_user else "?")
    await update.message.reply_text(
        "Привет! Я <b>CRNAbot</b>.\n\n"
        "Команды:\n"
        "/egrul 7707083893 — поиск в ЕГРЮЛ/ЕГРИП\n"
        "/pdf 1037739877299 — выписка PDF (ОГРН)\n"
        "/bo 7707083893 — бухотчётность из ГИР БО\n\n"
        "Можно просто отправить ИНН или ОГРН — сделаю поиск в ЕГРЮЛ.",
        parse_mode="HTML",
    )


async def cmd_egrul(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = " ".join(context.args).strip() if context.args else ""
    if not query:
        await update.message.reply_text("Укажите ИНН или ОГРН: /egrul 7707083893")
        return
    await send_egrul_search(update, query)


async def cmd_pdf(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = " ".join(context.args).strip() if context.args else ""
    if not query or not INN_OGRN_RE.match(query):
        await update.message.reply_text(
            "Укажите ИНН или ОГРН:\n/pdf 7707083893\n/pdf 1037739877299"
        )
        return

    wait = await update.message.reply_text(
        "Запрашиваю выписку PDF у ФНС…\nЭто может занять до 2 минут."
    )
    try:
        pdf = await download_egrul_pdf(query)
    except EgrulError as exc:
        await wait.edit_text(str(exc))
        return
    except TimeoutError:
        await wait.edit_text(
            "ФНС слишком долго отвечает. Повторите через минуту "
            "или скачайте на egrul.nalog.ru."
        )
        return
    except Exception:
        logger.exception("egrul pdf failed")
        await wait.edit_text("Ошибка при скачивании PDF. Попробуйте позже.")
        return

    await wait.delete()
    await update.message.reply_document(
        document=BytesIO(pdf),
        filename=f"egrul_{query}.pdf",
        caption=f"Выписка ЕГРЮЛ/ЕГРИП по {query}",
    )


async def cmd_bo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    inn = " ".join(context.args).strip() if context.args else ""
    if not inn.isdigit() or len(inn) not in (10, 12):
        await update.message.reply_text("Укажите ИНН: /bo 7707083893")
        return

    wait = await update.message.reply_text("Ищу бухотчётность в ГИР БО…")
    try:
        org = await get_organization(inn)
        sent = 0
        for doc in latest_year_documents(org.documents):
            data, filename, _ = await download_document(doc)
            await update.message.reply_document(
                document=BytesIO(data),
                filename=filename,
                caption=f"{doc.title}\nИНН: {inn}",
            )
            sent += 1
        if sent == 0:
            raise GirBoError("Файлы не скачались.")
        await wait.delete()
        await update.message.reply_text(
            f"Карточка на сайте:\n{org.card_url}",
            disable_web_page_preview=True,
        )
    except GirBoError as exc:
        await wait.edit_text(
            f"{exc}\n\nОткройте вручную:\nhttps://bo.nalog.gov.ru/search?query={inn}"
        )
        return
    except Exception:
        logger.exception("girbo failed")
        await wait.edit_text("Ошибка при получении отчётности. Попробуйте позже.")
        return


async def plain_query(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await send_egrul_search(update, update.message.text.strip())


async def unknown_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.info("Неизвестное сообщение: %r", update.message.text if update.message else None)
    await update.message.reply_text(
        "Не понял запрос.\n\n"
        "Отправьте /start или ИНН/ОГРН (10–15 цифр).\n"
        "Пример: 7707083893"
    )


async def send_egrul_search(update: Update, query: str) -> None:
    wait = await update.message.reply_text("Ищу в ЕГРЮЛ/ЕГРИП…")
    try:
        records = await search_egrul(query)
    except EgrulError as exc:
        await wait.edit_text(str(exc))
        return
    except Exception:
        logger.exception("egrul search failed")
        await wait.edit_text("Ошибка при обращении к ФНС. Попробуйте позже.")
        return

    text = "\n\n".join(format_record(r) for r in records[:3])
    if len(records) > 3:
        text += f"\n\n…и ещё {len(records) - 3} записей."
    text += "\n\nДля PDF: /pdf ОГРН"
    await wait.edit_text(text, parse_mode="HTML")


def get_token() -> str:
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token or token.startswith("your_"):
        raise SystemExit(
            "BOT_TOKEN не задан.\n"
            f"Откройте файл: {BASE_DIR / '.env'}\n"
            "и вставьте токен от @BotFather."
        )
    return token


async def check_telegram_connection(token: str) -> str:
    from telegram import Bot
    from telegram.error import InvalidToken, NetworkError

    bot = Bot(token)
    try:
        me = await asyncio.wait_for(bot.get_me(), timeout=20)
    except InvalidToken as exc:
        raise SystemExit(
            "Неверный BOT_TOKEN в .env.\n"
            "Получите новый токен у @BotFather → /mybots → API Token."
        ) from exc
    except (NetworkError, TimeoutError, OSError) as exc:
        raise SystemExit(
            "Не удалось подключиться к Telegram API.\n"
            "Частая причина в РФ — нужен VPN.\n"
            "Проверьте интернет и выполните: curl -I https://api.telegram.org\n"
            f"Ошибка: {exc}"
        ) from exc
    except Exception as exc:
        raise SystemExit(f"Ошибка проверки бота: {exc}") from exc

    username = me.username or "?"
    logger.info("Подключение OK: @%s — https://t.me/%s", username, username)
    return username


def main() -> None:
    (BASE_DIR / "downloads").mkdir(exist_ok=True)
    token = get_token()

    logger.info("Проверяю подключение к Telegram…")
    loop = asyncio.get_event_loop()
    loop.run_until_complete(check_telegram_connection(token))

    app = (
        Application.builder()
        .token(token)
        .post_init(post_init)
        .build()
    )

    app.add_error_handler(on_error)
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("egrul", cmd_egrul))
    app.add_handler(CommandHandler("pdf", cmd_pdf))
    app.add_handler(CommandHandler("bo", cmd_bo))
    app.add_handler(MessageHandler(filters.Regex(INN_OGRN_RE), plain_query))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, unknown_text))

    logger.info("Запускаю polling… (терминал не закрывайте)")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    try:
        asyncio.get_event_loop()
    except RuntimeError:
        asyncio.set_event_loop(asyncio.new_event_loop())
    main()
