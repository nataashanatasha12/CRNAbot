#!/usr/bin/env bash
set -euo pipefail

HOSTNAME="crna"
LINE="127.0.0.1 ${HOSTNAME}"
PORT="${APP_PORT:-80}"

if grep -Eq "[[:space:]]${HOSTNAME}([[:space:]]|$)" /etc/hosts; then
  echo "Запись для ${HOSTNAME} уже есть в /etc/hosts."
else
  echo "Добавляю ${LINE} в /etc/hosts (потребуется пароль администратора)…"
  echo "${LINE}" | sudo tee -a /etc/hosts >/dev/null
  echo "Готово."
fi

echo ""
if [ "${PORT}" = "80" ]; then
  echo "Открывайте сайт: http://${HOSTNAME}/"
else
  echo "Открывайте сайт: http://${HOSTNAME}:${PORT}/"
fi
echo "Перезапуск сервера: ~/CRNAbot/restart.sh"
