from __future__ import annotations

import asyncio
import logging
import re
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from services.cookie_consent import dismiss_cookie_consent
from services.inn_utils import normalize_inn

logger = logging.getLogger("crnabot.fsgs")

FSGS_INFO_URL = "https://websbor.rosstat.gov.ru/online/info"

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
)

_HEAD_MARKERS = ("головн", "юридическ", "респондент", "основное")
_BRANCH_MARKERS = (
    "филиал",
    "обособлен",
    "тосп",
    "представительств",
    "структурное подразделение",
    "обособленное",
)

_BLOCKED_RESOURCE_TYPES = frozenset({"image", "font", "media"})

_playwright_ref = None
_browser_ref = None
_context_ref = None
_page_ref = None
_browser_lock = None

_PDF_CACHE: dict[str, tuple[float, bytes]] = {}
_PDF_CACHE_TTL_SEC = 3600
_PDF_CACHE_VERSION = "v12"

_OPTION_SELECTOR = (
    '[role="listbox"] [role="option"], '
    ".cdk-overlay-pane mat-option, .cdk-overlay-pane .mat-mdc-option, "
    ".cdk-overlay-pane [role='option'], "
    ".cdk-overlay-container mat-option, .cdk-overlay-container .mat-mdc-option, "
    ".cdk-overlay-container [role='option'], "
    "mat-option, .mat-mdc-option, [role='option']"
)

_EXPORT_MENU_PANEL_SELECTOR = (
    ".mat-menu-panel, .mat-mdc-menu-panel, "
    ".cdk-overlay-pane .mat-mdc-menu-panel, .cdk-overlay-pane [role='menu'], "
    ".mat-menu-content, .mat-mdc-menu-content"
)

_EXPORT_MENU_ITEM_SELECTOR = (
    '.mat-menu-panel button[role="menuitem"], '
    '.mat-mdc-menu-panel button[role="menuitem"], '
    '.mat-menu-content button, '
    '.mat-mdc-menu-content button, '
    '.cdk-overlay-pane [role="menu"] button, '
    '.cdk-overlay-pane [role="menuitem"], '
    '.cdk-overlay-pane .mat-mdc-menu-item, '
    '[role="menu"] [role="menuitem"]'
)


def _pdf_cache_key(inn: str) -> str:
    key = normalize_inn(inn)
    return f"{_PDF_CACHE_VERSION}:{key}" if key else ""


class FsgsError(Exception):
    pass


@dataclass
class FsgsMatchHints:
    ogrn: str | None = None
    name: str | None = None
    short_name: str | None = None
    address: str | None = None
    city: str | None = None
    is_branch_entity: bool = False


def get_cached_fsgs_pdf(inn: str) -> bytes | None:
    key = _pdf_cache_key(inn)
    if not key:
        return None
    cached = _PDF_CACHE.get(key)
    if cached and time.monotonic() - cached[0] < _PDF_CACHE_TTL_SEC:
        return cached[1]
    return None


def _store_cached_pdf(inn: str, data: bytes) -> None:
    key = _pdf_cache_key(inn)
    if key and data.startswith(b"%PDF"):
        _PDF_CACHE[key] = (time.monotonic(), data)


def _get_browser_lock():
    global _browser_lock
    if _browser_lock is None:
        _browser_lock = asyncio.Lock()
    return _browser_lock


def _playwright_available() -> bool:
    try:
        import playwright  # noqa: F401

        return True
    except ImportError:
        return False


async def _block_heavy_resources(route) -> None:
    if route.request.resource_type in _BLOCKED_RESOURCE_TYPES:
        await route.abort()
    else:
        await route.continue_()


async def _poll_until(page, predicate, *, timeout_ms: int = 3000, interval_ms: int = 100) -> bool:
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        if await predicate():
            return True
        await page.wait_for_timeout(interval_ms)
    return False


async def _reset_browser() -> None:
    global _playwright_ref, _browser_ref, _context_ref, _page_ref
    if _page_ref is not None:
        try:
            await _page_ref.close()
        except Exception:
            pass
    _page_ref = None
    if _context_ref is not None:
        try:
            await _context_ref.close()
        except Exception:
            pass
    _context_ref = None
    if _browser_ref is not None:
        try:
            await _browser_ref.close()
        except Exception:
            pass
    _browser_ref = None
    if _playwright_ref is not None:
        try:
            await _playwright_ref.stop()
        except Exception:
            pass
    _playwright_ref = None


async def _launch_browser(playwright):
    launch_kwargs = {
        "headless": True,
        "args": ["--disable-blink-features=AutomationControlled"],
    }
    for channel in ("chrome", "chromium"):
        try:
            if channel == "chrome":
                return await playwright.chromium.launch(channel="chrome", **launch_kwargs)
            return await playwright.chromium.launch(**launch_kwargs)
        except Exception as exc:
            logger.info("ФСГС Playwright launch via %s failed: %s", channel, exc)
    return None


async def _ensure_browser():
    global _playwright_ref, _browser_ref
    if _browser_ref is not None:
        try:
            if _browser_ref.is_connected():
                return _browser_ref
        except Exception:
            pass
        await _reset_browser()
    from playwright.async_api import async_playwright

    _playwright_ref = await async_playwright().start()
    _browser_ref = await _launch_browser(_playwright_ref)
    if _browser_ref is None:
        raise FsgsError("Не удалось запустить браузер для выгрузки ФСГС.")
    return _browser_ref


async def _ensure_page(browser):
    global _context_ref, _page_ref
    if _context_ref is None:
        _context_ref = await browser.new_context(
            user_agent=USER_AGENT,
            locale="ru-RU",
            ignore_https_errors=True,
            viewport={"width": 1440, "height": 900},
        )
        await _context_ref.route("**/*", _block_heavy_resources)
        _page_ref = await _context_ref.new_page()
        return _page_ref

    if _page_ref is None or _page_ref.is_closed():
        _page_ref = await _context_ref.new_page()
    return _page_ref


def _digits(text: str | None) -> str:
    return re.sub(r"\D", "", text or "")


def _normalize_name(text: str) -> str:
    cleaned = re.sub(r"[«»\"'()]", " ", (text or "").lower())
    return re.sub(r"\s+", " ", cleaned).strip()


def _name_tokens(text: str | None) -> set[str]:
    if not text:
        return set()
    stop = {
        "ооо",
        "ао",
        "пао",
        "зао",
        "оао",
        "ип",
        "общество",
        "ограниченной",
        "ответственностью",
        "компания",
        "организация",
    }
    tokens = re.findall(r"[а-яa-z0-9\-]{3,}", _normalize_name(text))
    return {token for token in tokens if token not in stop}


def detect_branch_entity(name: str | None) -> bool:
    lower = _normalize_name(name or "")
    return any(marker in lower for marker in _BRANCH_MARKERS)


def _row_has_branch_marker(text: str) -> bool:
    lower = text.lower()
    return any(marker in lower for marker in _BRANCH_MARKERS)


def _location_tokens(hints: FsgsMatchHints) -> set[str]:
    tokens: set[str] = set()
    if hints.city:
        tokens.add(_normalize_name(hints.city))
    if hints.address:
        norm = _normalize_name(hints.address)
        for match in re.findall(r"г\.?\s*([а-яё\-]+)", norm):
            tokens.add(match)
        for match in re.findall(r"город\s+([а-яё\-]+)", norm):
            tokens.add(match)
        for match in re.findall(r"([а-яё\-]{4,})", norm):
            if match not in {"россия", "российская", "федерация", "улица", "проспект", "переулок"}:
                tokens.add(match)
    return {token for token in tokens if len(token) >= 4}


def score_fsgs_row(text: str, hints: FsgsMatchHints) -> int:
    lower = text.lower()
    norm_text = _normalize_name(text)
    score = 0

    ogrn_digits = _digits(hints.ogrn)
    if ogrn_digits and ogrn_digits in _digits(text):
        score += 100

    for marker in _HEAD_MARKERS:
        if marker in lower:
            score += 12

    if _row_has_branch_marker(text):
        score -= 55 if not hints.is_branch_entity else 8

    for name_value in (hints.name, hints.short_name):
        if not name_value:
            continue
        norm_name = _normalize_name(name_value)
        if norm_name and norm_name in norm_text:
            score += 70 if name_value == hints.name else 55
        name_tokens = _name_tokens(name_value)
        if name_tokens:
            row_tokens = _name_tokens(text)
            overlap = len(name_tokens & row_tokens)
            if overlap:
                score += min(45, overlap * 12)

    for token in _location_tokens(hints):
        if token and token in norm_text:
            score += 20

    if hints.is_branch_entity:
        for marker in _BRANCH_MARKERS:
            if marker in lower:
                score += 10

    return score


def _narrow_fsgs_candidates(
    candidates: list[tuple[Any, str]],
    hints: FsgsMatchHints,
) -> list[tuple[Any, str]]:
    narrowed = list(candidates)
    ogrn_digits = _digits(hints.ogrn)
    if ogrn_digits:
        ogrn_matches = [(row, text) for row, text in narrowed if ogrn_digits in _digits(text)]
        if ogrn_matches:
            narrowed = ogrn_matches

    if not hints.is_branch_entity and len(narrowed) > 1:
        head_rows = [(row, text) for row, text in narrowed if not _row_has_branch_marker(text)]
        if head_rows:
            narrowed = head_rows

    return narrowed


def pick_fsgs_row(candidates: list[tuple[Any, str]], hints: FsgsMatchHints) -> tuple[Any, str, int]:
    if not candidates:
        raise FsgsError("Список организаций/филиалов ФСГС пуст.")

    pool = _narrow_fsgs_candidates(candidates, hints)
    scored = [(row, text, score_fsgs_row(text, hints)) for row, text in pool]
    scored.sort(key=lambda item: item[2], reverse=True)
    best_row, best_text, best_score = scored[0]

    if len(scored) > 1:
        second_score = scored[1][2]
        if best_score == second_score:
            if hints.is_branch_entity:
                branch_rows = [item for item in scored if _row_has_branch_marker(item[1])]
                if branch_rows:
                    best_row, best_text, best_score = branch_rows[0]
            else:
                head_rows = [item for item in scored if not _row_has_branch_marker(item[1])]
                if head_rows:
                    best_row, best_text, best_score = head_rows[0]

    if best_score <= 0 and len(scored) > 1 and not hints.is_branch_entity:
        head_rows = [item for item in scored if not _row_has_branch_marker(item[1])]
        if head_rows:
            best_row, best_text, best_score = head_rows[0]

    if best_score <= 0:
        raise FsgsError(
            "Не удалось выбрать нужный филиал ФСГС по наименованию и адресу. "
            "Откройте сайт вручную и выберите подразделение."
        )

    if len(scored) > 1:
        preview = ", ".join(f"{item[2]}:{item[1][:60]!r}" for item in scored[:4])
        logger.info("ФСГС branch candidates top=%s", preview)

    return best_row, best_text, best_score


def _is_table_header_row(text: str) -> bool:
    lower = text.lower().strip()
    if lower in {"окпо", "инн", "огрн", "огрнип", "наименование", "наименование организации"}:
        return True
    if len(lower) <= 80 and re.match(r"^(окпо|инн|огрн|№\s*\d*|наименование)\b", lower):
        return True
    return False


async def _collect_candidate_rows(page) -> list[tuple[Any, str]]:
    js_candidates = await page.evaluate(
        """() => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const isHeader = (t) => {
                const lower = t.toLowerCase();
                if (['окпо', 'инн', 'огрн', 'огрнип', 'наименование'].includes(lower)) return true;
                return lower.length <= 80 && /^(окпо|инн|огрн|№\\s*\\d*|наименование)\\b/i.test(lower);
            };
            const isForm = (t) => /^\\d{1,3}[-–—]/.test(t) || /\\bп-\\d/i.test(t);
            const selectors = [
                'table tbody tr',
                'table tr',
                'mat-row',
                '.mat-row',
                '.mat-mdc-row',
                '.cdk-overlay-pane table tbody tr',
                '.cdk-overlay-pane mat-row',
                'mat-list-item',
                '.mat-list-item',
                '[role="row"]',
            ];
            const out = [];
            const seen = new Set();
            for (const sel of selectors) {
                for (const el of document.querySelectorAll(sel)) {
                    const text = norm(el.innerText);
                    if (!text || text.length < 6 || seen.has(text)) continue;
                    const first = norm(text.split('\\n')[0]);
                    if (isHeader(first) || isHeader(text)) continue;
                    if (isForm(text)) continue;
                    seen.add(text);
                    out.push(text.slice(0, 400));
                }
            }
            return out;
        }"""
    )

    candidates: list[tuple[Any, str]] = []
    row_locators = [
        page.locator("table tbody tr, mat-row, .mat-row, .mat-mdc-row, mat-list-item, [role=row]"),
        page.locator("table tr").filter(has=page.locator("td")),
    ]
    for rows in row_locators:
        count = await rows.count()
        for idx in range(count):
            row = rows.nth(idx)
            text = (await row.inner_text()).strip()
            if not text or _is_table_header_row(text) or _looks_like_form_row(text):
                continue
            if not _looks_like_org_row(text) and len(text) < 20:
                continue
            candidates.append((row, text))

    if candidates:
        deduped: list[tuple[Any, str]] = []
        seen_text: set[str] = set()
        for row, text in candidates:
            key = re.sub(r"\s+", " ", text).strip()
            if key in seen_text:
                continue
            seen_text.add(key)
            deduped.append((row, text))
        return deduped

    for text in js_candidates or []:
        if _is_table_header_row(text) or _looks_like_form_row(text):
            continue
        loc = page.get_by_text(text[:80], exact=False).first
        if await loc.count() == 0:
            loc = page.locator("tr, mat-row, .mat-row, mat-list-item").filter(
                has_text=re.compile(re.escape(text[:40]))
            ).first
        if await loc.count() > 0:
            candidates.append((loc, text))
    return candidates


async def _open_info_page(page) -> None:
    last_error: Exception | None = None
    for url in (FSGS_INFO_URL, "https://websbor.gks.ru/online/info"):
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            inn_input = await _wait_for_inn_input(page, timeout_ms=12000)
            if inn_input is not None:
                return
            try:
                await page.wait_for_load_state("load", timeout=8000)
            except Exception:
                pass
            inn_input = await _wait_for_inn_input(page, timeout_ms=4000)
            if inn_input is not None:
                return
        except Exception as exc:
            last_error = exc
            logger.info("ФСГС open %s failed: %s", url, exc)
    if last_error:
        raise FsgsError(f"Не удалось открыть страницу ФСГС: {last_error}") from last_error
    raise FsgsError("Поле ИНН на странице ФСГС не появилось.")


async def _page_scopes(page):
    scopes = [page]
    for frame in page.frames:
        if frame != page.main_frame:
            scopes.append(frame)
    return scopes


async def _visible_input_meta(page) -> list[dict[str, Any]]:
    try:
        return await page.evaluate(
            """() => Array.from(document.querySelectorAll('input')).map((el) => ({
                id: el.id || '',
                name: el.name || '',
                type: el.type || '',
                placeholder: el.placeholder || '',
                formcontrolname: el.getAttribute('formcontrolname') || '',
                aria: el.getAttribute('aria-label') || '',
                visible: !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length),
            }))"""
        )
    except Exception:
        return []


async def _try_locate_inn_input_once(page):
    for scope in await _page_scopes(page):
        selectors = (
            "#inn",
            "input#inn",
            'input[name="inn"]',
            'input[formcontrolname="inn"]',
            'input[formcontrolname="Inn"]',
            'input[id*="inn" i]',
            'input[placeholder*="ИНН" i]',
            'input[aria-label*="ИНН" i]',
        )
        for selector in selectors:
            loc = scope.locator(selector).first
            if await loc.count() == 0:
                continue
            try:
                if await loc.is_visible():
                    return loc
            except Exception:
                continue

        for getter in (
            lambda s: s.get_by_role("textbox", name=re.compile(r"ИНН", re.I)).first,
            lambda s: s.get_by_label(re.compile(r"ИНН", re.I)).first,
            lambda s: s.get_by_placeholder(re.compile(r"ИНН", re.I)).first,
        ):
            loc = getter(scope)
            if await loc.count() == 0:
                continue
            try:
                if await loc.is_visible():
                    return loc
            except Exception:
                continue

        mat_field = scope.locator("mat-form-field").filter(
            has=scope.locator("mat-label", has_text=re.compile(r"^ИНН$", re.I))
        )
        if await mat_field.count() > 0:
            loc = mat_field.first.locator("input").first
            try:
                if await loc.is_visible():
                    return loc
            except Exception:
                pass

        visible_inputs = scope.locator(
            'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"])'
        )
        try:
            count = await visible_inputs.count()
        except Exception:
            count = 0
        if count == 1:
            loc = visible_inputs.first
            try:
                if await loc.is_visible():
                    return loc
            except Exception:
                pass
        if count >= 3:
            loc = visible_inputs.nth(2)
            try:
                if await loc.is_visible():
                    return loc
            except Exception:
                pass

    return None


async def _wait_for_inn_input(page, *, timeout_ms: int = 12000):
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        loc = await _try_locate_inn_input_once(page)
        if loc is not None:
            return loc
        await page.wait_for_timeout(150)
    return None


async def _try_locate_field_once(page, field: str):
    field = field.lower()
    patterns = {
        "inn": (
            "#inn",
            "input#inn",
            'input[name="inn"]',
            'input[formcontrolname="inn"]',
            'input[formcontrolname="Inn"]',
            'input[id*="inn" i]',
            'input[placeholder*="ИНН" i]',
            'input[aria-label*="ИНН" i]',
        ),
        "ogrn": (
            "#ogrn",
            "input#ogrn",
            'input[name="ogrn"]',
            'input[formcontrolname="ogrn"]',
            'input[formcontrolname="Ogrn"]',
            'input[id*="ogrn" i]',
            'input[placeholder*="ОГРН" i]',
            'input[aria-label*="ОГРН" i]',
        ),
    }
    label_re = {
        "inn": re.compile(r"^ИНН$", re.I),
        "ogrn": re.compile(r"^ОГРН", re.I),
    }
    selectors = patterns.get(field, ())

    for scope in await _page_scopes(page):
        for selector in selectors:
            loc = scope.locator(selector).first
            if await loc.count() == 0:
                continue
            try:
                if await loc.is_visible():
                    return loc
            except Exception:
                continue

        if field in label_re:
            mat_field = scope.locator("mat-form-field").filter(
                has=scope.locator("mat-label", has_text=label_re[field])
            )
            if await mat_field.count() > 0:
                loc = mat_field.first.locator("input").first
                try:
                    if await loc.is_visible():
                        return loc
                except Exception:
                    pass

            for getter in (
                lambda s: s.get_by_role("textbox", name=re.compile(r"ИНН", re.I)).first
                if field == "inn"
                else s.get_by_role("textbox", name=re.compile(r"ОГРН", re.I)).first,
                lambda s: s.get_by_label(label_re[field]).first,
                lambda s: s.get_by_placeholder(label_re[field]).first,
            ):
                loc = getter(scope)
                if await loc.count() == 0:
                    continue
                try:
                    if await loc.is_visible():
                        return loc
                except Exception:
                    continue
    return None


async def _locate_field(page, field: str, *, timeout_ms: int = 8000):
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        loc = await _try_locate_field_once(page, field)
        if loc is not None:
            return loc
        await page.wait_for_timeout(150)
    return None


async def _locate_inn_input(page):
    return await _locate_field(page, "inn", timeout_ms=12000)


async def _click_search_button(page) -> None:
    for btn_name in ("Получить", "Поиск", "Найти"):
        btn = page.get_by_role("button", name=re.compile(btn_name, re.I))
        if await btn.count() > 0:
            await btn.first.click()
            return
    await page.keyboard.press("Enter")


async def _fill_search_and_submit(
    page,
    inn: str,
    hints: FsgsMatchHints | None = None,
) -> str:
    inn_norm = normalize_inn(inn)
    ogrn_digits = _digits(hints.ogrn if hints else None)

    if ogrn_digits:
        ogrn_input = await _locate_field(page, "ogrn", timeout_ms=5000)
        if ogrn_input is not None:
            await ogrn_input.click()
            await ogrn_input.fill(ogrn_digits)
            logger.info("ФСГС search by OGRN inn=%s ogrn=%s", inn_norm, ogrn_digits)
            await _click_search_button(page)
            await _wait_for_search_results(page, timeout_ms=18000)
            return "ogrn"

    inn_input = await _locate_inn_input(page)
    if inn_input is None:
        meta = await _visible_input_meta(page)
        logger.warning(
            "ФСГС: поле поиска не найдено inn=%s url=%s inputs=%s",
            inn_norm,
            page.url,
            meta,
        )
        raise FsgsError("Поле ИНН на сайте ФСГС не найдено.")

    await inn_input.click()
    await inn_input.fill(inn_norm)
    logger.info("ФСГС search by INN inn=%s", inn_norm)
    await _click_search_button(page)
    await _wait_for_search_results(page, timeout_ms=18000)
    return "inn"


def _looks_like_form_row(text: str) -> bool:
    lower = text.lower()
    if re.search(r"^\s*\d{1,3}[-–—]", text):
        return True
    if re.search(r"\bп-\d", lower):
        return True
    if "код формы" in lower or "наименование формы" in lower:
        return True
    return False


def _looks_like_org_row(text: str) -> bool:
    if _looks_like_form_row(text):
        return False
    lower = text.lower()
    if _row_has_branch_marker(text):
        return True
    if re.search(r"\d{10,15}", text):
        return True
    return any(token in lower for token in ("пао", "ао", "ооо", "зао", "публичное", "акционерное"))


async def _page_has_org_dropdown_results(page) -> bool:
    try:
        return await page.evaluate(
            """() => {
                const t = (document.body?.innerText || '').toLowerCase();
                const hasResults =
                    t.includes('результаты запроса') ||
                    t.includes('количество организаций') ||
                    t.includes('выбрать организацию');
                if (!hasResults) return false;
                return !!document.querySelector('mat-select, mat-mdc-select, [role=combobox]');
            }"""
        )
    except Exception:
        return False


async def _org_combobox_index(page) -> int:
    try:
        return int(
            await page.evaluate(
                """() => {
                    const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim().toLowerCase();
                    const boxes = [...document.querySelectorAll('[role=combobox]')];
                    if (!boxes.length) return -1;

                    const scoreBox = (box) => {
                        const label = norm(box.getAttribute('aria-label') || '');
                        const text = norm(box.innerText || '');
                        const parent = box.closest('mat-form-field, .mat-mdc-form-field, section, div');
                        const parentText = norm(parent?.innerText || '');
                        const id = norm(box.id || '');
                        let score = 0;
                        if (/выбрать организацию/.test(text + ' ' + label + ' ' + parentText)) score += 120;
                        if (/наименование организации/.test(parentText)) score += 100;
                        if (/^инн$|^огрн|окпо/.test(label) || /inn|ogrn|okpo/.test(id)) score -= 100;
                        if (parentText.includes('результаты запроса')) score += 40;
                        if (parentText.includes('количество организаций')) score += 40;
                        return score;
                    };

                    let bestIdx = -1;
                    let bestScore = -999;
                    boxes.forEach((box, idx) => {
                        const score = scoreBox(box);
                        if (score > bestScore) {
                            bestScore = score;
                            bestIdx = idx;
                        }
                    });

                    if (bestIdx >= 0 && bestScore > 0) return bestIdx;
                    if (norm(document.body?.innerText || '').includes('количество организаций')) {
                        return boxes.length - 1;
                    }
                    return bestIdx;
                }"""
            )
        )
    except Exception:
        return -1


async def _locate_org_combobox_input(page):
    for pattern in (r"Выбрать организацию", r"Наименование организации"):
        field = page.locator("mat-form-field, .mat-mdc-form-field").filter(
            has_text=re.compile(pattern, re.I)
        )
        if await field.count() > 0:
            inner = field.first.locator(
                'input[role="combobox"], input.mat-mdc-autocomplete-trigger, input:not([type="hidden"])'
            ).first
            if await inner.count() > 0:
                return inner
    return await _locate_org_combobox(page)


def _org_typeahead_seeds(hints: FsgsMatchHints | None) -> list[str]:
    seeds: list[str] = []
    if hints:
        ogrn = _digits(hints.ogrn)
        if ogrn:
            seeds.extend([ogrn, ogrn[-8:]])
        for raw in (hints.short_name, hints.name):
            token = _normalize_name(raw or "")
            if token and len(token) >= 4:
                seeds.append(token[:30])
                seeds.append(token[:12])
    seen: set[str] = set()
    ordered: list[str] = []
    for seed in seeds:
        if seed not in seen:
            seen.add(seed)
            ordered.append(seed)
    ordered.append("")
    return ordered


async def _try_typeahead_open_org_dropdown(page, hints: FsgsMatchHints | None) -> bool:
    combo = await _locate_org_combobox_input(page)
    if combo is None:
        return False

    field = page.locator("mat-form-field, .mat-mdc-form-field").filter(
        has_text=re.compile(r"Выбрать организацию|Наименование организации", re.I)
    ).first

    for seed in _org_typeahead_seeds(hints):
        await dismiss_cookie_consent(page, site="fsgs")
        await _dismiss_cdk_overlays(page)
        try:
            if await field.count() > 0:
                suffix = field.locator(
                    ".mat-mdc-form-field-icon-suffix, .mat-mdc-select-arrow-wrapper, mat-icon, button"
                ).first
                if await suffix.count() > 0:
                    await suffix.click(timeout=3000, force=True)
                    if await _poll_until(page, lambda: _dropdown_options_visible(page), timeout_ms=1500):
                        logger.info("ФСГС org dropdown opened via suffix seed=%r", seed[:30] if seed else "<arrow>")
                        return True

            await combo.scroll_into_view_if_needed()
            await combo.click(timeout=5000, force=True)
            await combo.fill("")
            if seed:
                await combo.press_sequentially(seed, delay=35)
            else:
                await page.keyboard.press("ArrowDown")
            if not await _poll_until(page, lambda: _dropdown_options_visible(page), timeout_ms=1200):
                await page.keyboard.press("ArrowDown")
            if await _dropdown_options_visible(page):
                logger.info("ФСГС org dropdown opened typeahead seed=%r", seed[:30] if seed else "<arrow>")
                return True
        except Exception as exc:
            logger.info(
                "ФСГС typeahead seed=%r failed: %s",
                seed[:20] if seed else "<arrow>",
                exc,
            )
    return False


async def _locate_org_combobox(page):
    idx = await _org_combobox_index(page)
    if idx < 0:
        field = page.locator("mat-form-field, .mat-mdc-form-field").filter(
            has_text=re.compile(r"Наименование организации", re.I)
        )
        if await field.count() > 0:
            inner = field.first.locator('[role="combobox"], input').first
            if await inner.count() > 0:
                return inner
        return None
    combo = page.get_by_role("combobox").nth(idx)
    if await combo.count() > 0:
        return combo
    return None


async def _dropdown_options_visible(page) -> bool:
    try:
        visible = await page.evaluate(
            """() => {
                for (const box of document.querySelectorAll('[role=combobox]')) {
                    const listId = box.getAttribute('aria-controls');
                    if (listId) {
                        const count =
                            document.getElementById(listId)?.querySelectorAll('[role=option]').length || 0;
                        if (count > 0) return true;
                    }
                }
                return (
                    document.querySelectorAll('[role=listbox] [role=option]').length > 0 ||
                    document.querySelectorAll(
                        '.cdk-overlay-pane mat-option, .cdk-overlay-pane .mat-mdc-option, .cdk-overlay-pane [role=option]'
                    ).length > 0
                );
            }"""
        )
        if visible:
            return True
    except Exception:
        pass
    return await page.locator(_OPTION_SELECTOR).count() > 0



async def _log_dropdown_debug(page) -> None:
    try:
        debug = await page.evaluate(
            """() => {
                const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
                const boxes = [...document.querySelectorAll('[role=combobox]')].map((el, idx) => ({
                    idx,
                    id: el.id || '',
                    label: el.getAttribute('aria-label') || '',
                    expanded: el.getAttribute('aria-expanded') || '',
                    text: norm(el.innerText || '').slice(0, 120),
                    parent: norm(el.closest('mat-form-field, .mat-mdc-form-field')?.innerText || '').slice(0, 120),
                }));
                return {
                    matSelect: document.querySelectorAll('mat-select, mat-mdc-select').length,
                    comboboxes: boxes,
                    listboxOptions: document.querySelectorAll('[role=listbox] [role=option]').length,
                    overlayOptions: document.querySelectorAll(
                        '.cdk-overlay-pane mat-option, .cdk-overlay-pane .mat-mdc-option, .cdk-overlay-pane [role=option]'
                    ).length,
                };
            }"""
        )
        logger.warning("ФСГС dropdown debug %s", debug)
    except Exception as exc:
        logger.warning("ФСГС dropdown debug failed: %s", exc)


async def _open_org_dropdown(page, hints: FsgsMatchHints | None = None) -> bool:
    await dismiss_cookie_consent(page, site="fsgs")
    await _dismiss_cdk_overlays(page)

    if await _try_typeahead_open_org_dropdown(page, hints):
        return True

    combo = await _locate_org_combobox_input(page)
    if combo is None:
        combo = await _locate_org_combobox(page)
    if combo is None:
        await _log_dropdown_debug(page)
        return False

    idx = await _org_combobox_index(page)
    logger.info("ФСГС org combobox index=%s", idx)

    open_targets = [combo]
    try:
        field = page.locator("mat-form-field, .mat-mdc-form-field").filter(
            has_text=re.compile(r"Выбрать организацию|Наименование организации", re.I)
        )
        if await field.count() > 0:
            arrow = field.first.locator(
                ".mat-mdc-select-arrow-wrapper, .mat-mdc-select-arrow, .mat-select-arrow-wrapper, button"
            ).first
            if await arrow.count() > 0:
                open_targets.append(arrow)
    except Exception:
        pass

    for target in open_targets:
        try:
            await target.scroll_into_view_if_needed()
            await target.click(timeout=5000, force=True)
            if await _poll_until(page, lambda: _dropdown_options_visible(page), timeout_ms=1500):
                return True
        except Exception as exc:
            logger.info("ФСГС combobox open click failed: %s", exc)

    try:
        await combo.focus()
        for key in ("ArrowDown", "Alt+ArrowDown", "Space", "Enter"):
            await page.keyboard.press(key)
            if await _poll_until(page, lambda: _dropdown_options_visible(page), timeout_ms=800):
                return True
    except Exception as exc:
        logger.info("ФСГС combobox keyboard open failed: %s", exc)

    try:
        opened = await page.evaluate(
            """(hints) => {
                const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim().toLowerCase();
                const boxes = [...document.querySelectorAll('[role=combobox]')];
                let target =
                    boxes.find((box) =>
                        /выбрать организацию/i.test(
                            norm(box.closest('mat-form-field, .mat-mdc-form-field')?.innerText || '')
                        )
                    ) ||
                    boxes.find((box) => /выбрать организацию/i.test(norm(box.innerText || ''))) ||
                    boxes.find((box) =>
                        /наименование организации/i.test(
                            norm(box.closest('mat-form-field, .mat-mdc-form-field')?.innerText || '')
                        )
                    ) ||
                    boxes[boxes.length - 1];
                if (!target) return false;
                target.focus();
                target.click();
                if (hints && hints.ogrn) {
                    target.value = hints.ogrn;
                    target.dispatchEvent(new InputEvent('input', { bubbles: true, data: hints.ogrn }));
                    target.dispatchEvent(new Event('change', { bubbles: true }));
                }
                target.dispatchEvent(
                    new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true, cancelable: true })
                );
                const listId = target.getAttribute('aria-controls');
                if (listId) {
                    const list = document.getElementById(listId);
                    if (list) {
                        list.hidden = false;
                        list.style.display = '';
                    }
                }
                return true;
            }""",
            {"ogrn": _digits(hints.ogrn if hints else None)},
        )
        if opened and await _poll_until(page, lambda: _dropdown_options_visible(page), timeout_ms=2000):
            return True
    except Exception as exc:
        logger.info("ФСГС combobox JS open failed: %s", exc)

    if await _try_typeahead_open_org_dropdown(page, hints):
        return True

    await _log_dropdown_debug(page)
    return False


async def _collect_dropdown_options(page) -> list[tuple[Any, str]]:
    if not await _dropdown_options_visible(page):
        await _poll_until(page, lambda: _dropdown_options_visible(page), timeout_ms=1500)

    option_loc = page.locator(_OPTION_SELECTOR)
    try:
        await option_loc.first.wait_for(state="visible", timeout=8000)
    except Exception:
        texts = await page.evaluate(
            """() => [...document.querySelectorAll(
                '[role=listbox] [role=option], .cdk-overlay-pane mat-option, .cdk-overlay-pane .mat-mdc-option, .cdk-overlay-pane [role=option], mat-option, .mat-mdc-option, [role=option]'
            )].map((el) => (el.innerText || '').replace(/\\s+/g, ' ').trim()).filter((t) => t.length > 3)"""
        )
        if not texts:
            return []
        candidates: list[tuple[Any, str]] = []
        for text in texts:
            loc = page.locator(_OPTION_SELECTOR).filter(
                has_text=re.compile(re.escape(text[:40]))
            ).first
            if await loc.count() > 0:
                candidates.append((loc, text))
        return candidates

    count = await option_loc.count()
    candidates: list[tuple[Any, str]] = []
    for idx in range(count):
        opt = option_loc.nth(idx)
        text = (await opt.inner_text()).strip()
        if not text or _is_table_header_row(text):
            continue
        candidates.append((opt, text))
    return candidates


async def _click_dropdown_option(page, option_locator, text: str) -> None:
    try:
        await option_locator.click(timeout=5000)
        return
    except Exception:
        pass
    snippet = text[:80]
    await page.evaluate(
        """(snippet) => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const target = norm(snippet);
            const options = [
                ...document.querySelectorAll(
                    '[role=listbox] [role=option], .cdk-overlay-pane mat-option, .cdk-overlay-pane .mat-mdc-option, .cdk-overlay-pane [role=option], mat-option, .mat-mdc-option, [role=option]'
                ),
            ];
            const match = options.find((el) => {
                const t = norm(el.innerText);
                return t === target || t.includes(target.slice(0, 30)) || target.includes(t.slice(0, 30));
            });
            if (match) match.click();
        }""",
        snippet,
    )


async def _select_org_dropdown_js(page, hints: FsgsMatchHints) -> str | None:
    payload = {
        "ogrn": _digits(hints.ogrn),
        "short": _normalize_name(hints.short_name or ""),
        "name": _normalize_name(hints.name or ""),
        "is_branch": hints.is_branch_entity,
    }
    try:
        opened = await page.evaluate(
            """(hints) => {
                const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim().toLowerCase();
                const boxes = [...document.querySelectorAll('[role=combobox]')];
                let target =
                    boxes.find((box) =>
                        /выбрать организацию/i.test(
                            norm(box.closest('mat-form-field, .mat-mdc-form-field')?.innerText || '')
                        )
                    ) ||
                    boxes.find((box) => /выбрать организацию/i.test(norm(box.innerText || ''))) ||
                    boxes.find((box) =>
                        /наименование организации/i.test(
                            norm(box.closest('mat-form-field, .mat-mdc-form-field')?.innerText || '')
                        )
                    ) ||
                    boxes[boxes.length - 1];
                if (!target) return false;
                target.focus();
                target.click();
                if (hints.ogrn) {
                    target.value = hints.ogrn;
                    target.dispatchEvent(new InputEvent('input', { bubbles: true, data: hints.ogrn }));
                    target.dispatchEvent(new Event('change', { bubbles: true }));
                }
                target.dispatchEvent(
                    new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true, cancelable: true })
                );
                const listId = target.getAttribute('aria-controls');
                if (listId) {
                    const list = document.getElementById(listId);
                    if (list) {
                        list.hidden = false;
                        list.style.display = '';
                    }
                }
                return true;
            }""",
            payload,
        )
        if not opened:
            return None
        await _poll_until(page, lambda: _dropdown_options_visible(page), timeout_ms=2000)
        return await page.evaluate(
            """(hints) => {
                const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim().toLowerCase();
                const branchMarkers = [
                    'филиал', 'обособлен', 'тосп', 'представительств', 'обособленное',
                ];
                const options = [];
                for (const box of document.querySelectorAll('[role=combobox]')) {
                    const listId = box.getAttribute('aria-controls');
                    if (listId) {
                        const list = document.getElementById(listId);
                        if (list) options.push(...list.querySelectorAll('[role=option]'));
                    }
                }
                options.push(
                    ...document.querySelectorAll(
                        '[role=listbox] [role=option], .cdk-overlay-pane mat-option, .cdk-overlay-pane .mat-mdc-option, .cdk-overlay-pane [role=option], mat-option, .mat-mdc-option, [role=option]'
                    )
                );
                const unique = [...new Set(options)];
                if (!unique.length) return null;
                let best = null;
                let bestScore = -1;
                for (const opt of unique) {
                    const text = norm(opt.innerText || '');
                    if (!text) continue;
                    let score = 0;
                    if (hints.ogrn && text.includes(hints.ogrn)) score += 100;
                    if (hints.short && text.includes(hints.short)) score += 70;
                    if (hints.name && text.includes(hints.name)) score += 55;
                    if (branchMarkers.some((m) => text.includes(m))) {
                        score += hints.is_branch ? 10 : -55;
                    }
                    if (score > bestScore) {
                        bestScore = score;
                        best = opt;
                    }
                }
                if (!best || bestScore <= 0) best = unique[0];
                if (!best) return null;
                best.click();
                return (best.innerText || '').replace(/\\s+/g, ' ').trim();
            }""",
            payload,
        )
    except Exception as exc:
        logger.info("ФСГС combobox JS select failed: %s", exc)
        return None


async def _select_from_org_dropdown(page, hints: FsgsMatchHints) -> None:
    if await _page_has_org_codes_data(page):
        logger.info("ФСГС org codes already visible, skip dropdown")
        return

    picked = await _select_org_dropdown_js(page, hints)
    if picked:
        logger.info("ФСГС combobox JS pick=%r", picked[:160])
        await _dismiss_cdk_overlays(page)
        await _wait_after_org_pick(page, timeout_ms=10000)
        return

    opened = await _open_org_dropdown(page, hints)
    candidates: list[tuple[Any, str]] = []

    if opened:
        candidates = await _collect_dropdown_options(page)

    if not candidates:
        if await _page_has_org_codes_data(page):
            logger.info("ФСГС org codes visible after dropdown attempt, continue export")
            return
        await _log_dropdown_debug(page)
        raise FsgsError("Не удалось открыть список организаций ФСГС.")

    if len(candidates) == 1:
        picked_text = candidates[0][1]
        logger.info("ФСГС dropdown single pick=%r", picked_text[:160])
        await _click_dropdown_option(page, candidates[0][0], picked_text)
    else:
        row, text, score = pick_fsgs_row(candidates, hints)
        logger.info(
            "ФСГС dropdown pick score=%s name=%r picked=%r",
            score,
            hints.short_name or hints.name,
            text[:160],
        )
        await _click_dropdown_option(page, row, text)

    await _dismiss_cdk_overlays(page)
    await _wait_after_org_pick(page, timeout_ms=10000)


async def _page_has_org_codes_data(page) -> bool:
    try:
        return await page.evaluate(
            """() => {
                const t = (document.body?.innerText || '').toLowerCase();
                return (
                    t.includes('данные о кодах статистики') ||
                    (t.includes('окпо') && t.includes('окато')) ||
                    t.includes('ок тэи')
                );
            }"""
        )
    except Exception:
        return False


async def _wait_after_org_pick(page, *, timeout_ms: int = 12000) -> None:
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        if await _page_has_org_codes_data(page) or await _page_has_forms_list(page):
            return
        await page.wait_for_timeout(200)


async def _page_has_forms_list(page) -> bool:
    if await _page_has_org_codes_data(page):
        return False
    try:
        text = (await page.inner_text("body")).lower()
    except Exception:
        return False
    has_forms_marker = any(
        marker in text
        for marker in ("перечень форм", "формы отчетности", "формы отчётности", "код формы")
    )
    if not has_forms_marker:
        return False
    rows = page.locator("table tbody tr")
    count = await rows.count()
    if count > 0:
        for idx in range(min(count, 5)):
            row_text = (await rows.nth(idx).inner_text()).strip()
            if row_text and _looks_like_form_row(row_text):
                return True
    if await page.locator("mat-checkbox, table input[type='checkbox']").count() > 0:
        return True
    return "наименование формы" in text


async def _wait_for_search_results(page, *, timeout_ms: int = 25000) -> None:
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        if await _page_has_org_dropdown_results(page):
            return
        candidates = await _collect_candidate_rows(page)
        if len(candidates) > 1:
            return
        if len(candidates) == 1 and _looks_like_org_row(candidates[0][1]):
            return
        if await _page_has_forms_list(page):
            return
        await page.wait_for_timeout(250)


async def _wait_for_forms_list(page, *, timeout_ms: int = 6000) -> None:
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        if await _page_has_forms_list(page):
            return
        await page.wait_for_timeout(200)


async def _click_row(page, row) -> None:
    link = row.locator("a").first
    if await link.count() > 0:
        await link.click()
    else:
        await row.click()


async def _log_fsgs_page_state(page, inn: str, *, note: str) -> None:
    try:
        state = await page.evaluate(
            """() => ({
                url: location.href,
                tables: document.querySelectorAll('table').length,
                tbodyTr: document.querySelectorAll('table tbody tr').length,
                matRow: document.querySelectorAll('mat-row,.mat-row,.mat-mdc-row').length,
                body: (document.body?.innerText || '').replace(/\\s+/g, ' ').trim().slice(0, 500),
            })"""
        )
        logger.warning("ФСГС page state inn=%s note=%s state=%s", inn, note, state)
    except Exception as exc:
        logger.warning("ФСГС page state inn=%s note=%s err=%s", inn, note, exc)


async def _select_branch(page, hints: FsgsMatchHints | None, *, inn: str) -> None:
    await _wait_for_search_results(page, timeout_ms=18000)
    match_hints = hints or FsgsMatchHints()

    if await _page_has_org_dropdown_results(page):
        await _select_from_org_dropdown(page, match_hints)
        return

    if await _page_has_forms_list(page) or await _page_has_org_codes_data(page):
        return

    candidates = await _collect_candidate_rows(page)

    if len(candidates) > 1:
        row, text, score = pick_fsgs_row(candidates, match_hints)
        logger.info(
            "ФСГС branch pick score=%s name=%r picked=%r",
            score,
            match_hints.short_name or match_hints.name,
            text[:160],
        )
        await _click_row(page, row)
        await _wait_after_org_pick(page, timeout_ms=10000)
        return

    if len(candidates) == 1 and _looks_like_org_row(candidates[0][1]):
        logger.info("ФСГС single org row pick=%r", candidates[0][1][:160])
        await _click_row(page, candidates[0][0])
        await _wait_after_org_pick(page, timeout_ms=10000)
        return

    if candidates:
        await _log_fsgs_page_state(page, inn, note="unrecognized-rows")
        raise FsgsError("Список организаций/филиалов ФСГС не удалось распознать.")

    await _log_fsgs_page_state(page, inn, note="no-rows")
    raise FsgsError("Список организаций/филиалов ФСГС не найден.")


async def _read_download(download) -> bytes:
    path = await download.path()
    if path:
        return Path(path).read_bytes()
    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
        tmp_path = tmp.name
    try:
        await download.save_as(tmp_path)
        return Path(tmp_path).read_bytes()
    finally:
        Path(tmp_path).unlink(missing_ok=True)


async def _dismiss_cdk_overlays(page) -> None:
    try:
        await page.keyboard.press("Escape")
    except Exception:
        pass
    try:
        await page.evaluate(
            """() => {
                document.querySelectorAll('.cdk-overlay-backdrop').forEach((el) => el.remove());
                document.querySelectorAll('.cdk-overlay-container').forEach((el) => {
                    el.querySelectorAll('.cdk-overlay-backdrop').forEach((b) => b.remove());
                });
            }"""
        )
    except Exception:
        pass


async def _select_all_forms(page) -> int:
    try:
        selected = await page.evaluate(
            """() => {
                let count = 0;
                for (const box of document.querySelectorAll('mat-checkbox')) {
                    const input = box.querySelector('input[type="checkbox"]');
                    if (!input || input.disabled || input.checked) continue;
                    box.click();
                    count += 1;
                }
                for (const cb of document.querySelectorAll('table input[type="checkbox"]')) {
                    if (cb.disabled || cb.checked) continue;
                    cb.click();
                    count += 1;
                }
                return count;
            }"""
        )
        return int(selected or 0)
    except Exception:
        return 0


def _export_menu_item_score(text: str, *, prefer_forms: bool) -> int:
    lower = text.lower().replace("\n", " ")
    if re.search(r"excel|xls", lower):
        return 0
    if re.search(r"уведомление", lower) and re.search(r"ок\s*тэи", lower):
        if re.search(r"\(pdf\)|\.pdf\b|\bpdf\b", lower):
            return 120
        if not prefer_forms:
            return 80
        return 0
    if prefer_forms and lower.strip() == "pdf":
        return 100
    if re.search(r"\.pdf$", lower) or re.search(r"\(pdf\)", lower):
        return 90
    if prefer_forms and re.search(r"\bpdf\b", lower):
        return 70
    return 0


def _export_menu_item_matches(text: str, *, prefer_forms: bool) -> bool:
    return _export_menu_item_score(text, prefer_forms=prefer_forms) > 0


async def _collect_export_menu_item_texts(page) -> list[str]:
    try:
        texts = await page.evaluate(
            """(selector) => {
                const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
                return [...document.querySelectorAll(selector)]
                    .map((el) => norm(el.innerText))
                    .filter(Boolean);
            }""",
            _EXPORT_MENU_ITEM_SELECTOR,
        )
        return [text for text in texts if text]
    except Exception:
        return []


async def _log_open_export_menu_items(page) -> list[str]:
    texts = await _collect_export_menu_item_texts(page)
    if texts:
        logger.info("ФСГС export menu items=%r", texts)
    else:
        logger.info("ФСГС export menu items=[] (menu may be closed)")
    return texts


class _PdfCapture:
    def __init__(self, page) -> None:
        self.page = page
        self.context = page.context
        self._data: bytes | None = None
        self._event = asyncio.Event()
        self._handlers: list[tuple[Any, str, Any]] = []

    def _store(self, data: bytes | None) -> None:
        if data and data.startswith(b"%PDF") and self._data is None:
            self._data = data
            self._event.set()

    async def _on_response(self, response) -> None:
        try:
            if response.status < 200 or response.status >= 400:
                return
            content_type = (response.headers.get("content-type") or "").lower()
            url = response.url.lower()
            looks_like_pdf = (
                "application/pdf" in content_type
                or url.endswith(".pdf")
                or "/export" in url
                or "pdf" in url
            )
            if not looks_like_pdf:
                return
            body = await response.body()
            self._store(body)
        except Exception:
            pass

    async def _on_download(self, download) -> None:
        try:
            self._store(await _read_download(download))
        except Exception:
            pass

    async def _on_popup(self, popup) -> None:
        try:
            await popup.wait_for_load_state("domcontentloaded", timeout=15000)
            url = popup.url.lower()
            if url.startswith("blob:") or url.startswith("data:application/pdf") or ".pdf" in url:
                data = await popup.evaluate(
                    """async () => {
                        const resp = await fetch(location.href);
                        const buf = await resp.arrayBuffer();
                        return Array.from(new Uint8Array(buf));
                    }"""
                )
                if data:
                    self._store(bytes(data))
            await popup.close()
        except Exception:
            pass

    def start(self) -> None:
        self.page.on("response", self._on_response)
        self.page.on("download", self._on_download)
        self.context.on("page", self._on_popup)
        self._handlers = [
            (self.page, "response", self._on_response),
            (self.page, "download", self._on_download),
            (self.context, "page", self._on_popup),
        ]

    def stop(self) -> None:
        for target, event, handler in self._handlers:
            try:
                target.remove_listener(event, handler)
            except Exception:
                pass
        self._handlers.clear()

    async def wait(self, *, timeout_ms: int = 30000) -> bytes | None:
        try:
            await asyncio.wait_for(self._event.wait(), timeout=timeout_ms / 1000)
        except asyncio.TimeoutError:
            pass
        return self._data


async def _click_export_menu_item_js(page, *, prefer_forms: bool) -> bool:
    try:
        return bool(
            await page.evaluate(
                """({ preferForms, selector }) => {
                    const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
                    const score = (t) => {
                        const lower = norm(t).toLowerCase();
                        if (/excel|xls/i.test(lower)) return 0;
                        if (/уведомление/i.test(lower) && /ок\\s*тэи/i.test(lower)) {
                            if (/\\(pdf\\)|\\.pdf\\b|\\bpdf\\b/i.test(lower)) return 120;
                            if (!preferForms) return 80;
                            return 0;
                        }
                        if (preferForms && /^pdf$/i.test(lower)) return 100;
                        if (/\\.pdf$/i.test(lower) || /\\(pdf\\)/i.test(lower)) return 90;
                        if (preferForms && /\\bpdf\\b/i.test(lower)) return 70;
                        return 0;
                    };
                    const items = [...document.querySelectorAll(selector)].filter((el) => {
                        if (el.disabled || el.getAttribute('aria-disabled') === 'true') return false;
                        const rect = el.getBoundingClientRect();
                        return rect.width > 0 && rect.height > 0;
                    });
                    let target = null;
                    let best = 0;
                    for (const el of items) {
                        const value = score(norm(el.innerText));
                        if (value > best) {
                            best = value;
                            target = el;
                        }
                    }
                    if (!target || best <= 0) return false;
                    target.click();
                    return true;
                }""",
                {"preferForms": prefer_forms, "selector": _EXPORT_MENU_ITEM_SELECTOR},
            )
        )
    except Exception:
        return False


async def _click_export_menu_item_locator(page, *, prefer_forms: bool) -> bool:
    items = page.locator(_EXPORT_MENU_ITEM_SELECTOR)
    count = await items.count()
    target: tuple[Any, str, int] | None = None
    for idx in range(count):
        item = items.nth(idx)
        try:
            if not await item.is_visible():
                continue
            if await item.is_disabled():
                continue
        except Exception:
            continue
        text = (await item.inner_text()).strip()
        if not text:
            continue
        score = _export_menu_item_score(text, prefer_forms=prefer_forms)
        if score <= 0:
            continue
        if target is None or score > target[2]:
            target = (item, text, score)
    if target is None:
        try:
            menu_item = page.get_by_role(
                "menuitem",
                name=re.compile(r"Уведомление.*ОК\s*ТЭИ.*\(PDF\)", re.I),
            ).first
            if await menu_item.count() > 0 and await menu_item.is_visible():
                target = (menu_item, "Уведомление о кодах ОК ТЭИ (PDF)", 120)
        except Exception:
            pass
    if target is None:
        return False
    item, text, score = target
    logger.info("ФСГС export menu click=%r score=%s", text[:160], score)
    try:
        await item.click(timeout=5000, force=True)
        return True
    except Exception as exc:
        logger.info("ФСГС export menu locator click failed: %s", exc)
        return False


async def _wait_for_export_ready(page, *, timeout_ms: int = 15000) -> None:
    try:
        await page.wait_for_function(
            """() => {
                const text = (document.body?.innerText || '').toLowerCase();
                const hasForms =
                    text.includes('перечень форм') ||
                    text.includes('формы отчетности') ||
                    text.includes('формы отчётности') ||
                    text.includes('код формы');
                const hasCodes =
                    text.includes('данные о кодах статистики') ||
                    (text.includes('окпо') && text.includes('окато')) ||
                    text.includes('ок тэи');
                if (!hasForms && !hasCodes) return false;
                const exportBtn = [...document.querySelectorAll('button')].find((el) =>
                    /экспортировать/i.test((el.innerText || '').trim())
                );
                return !!exportBtn && !exportBtn.disabled;
            }""",
            timeout=timeout_ms,
        )
    except Exception:
        await _wait_after_org_pick(page, timeout_ms=timeout_ms)


async def _click_export_menu_item(page, *, prefer_forms: bool = False) -> bytes | None:
    await _log_open_export_menu_items(page)
    capture = _PdfCapture(page)
    capture.start()
    try:
        clicked = await _click_export_menu_item_js(page, prefer_forms=prefer_forms)
        if not clicked:
            clicked = await _click_export_menu_item_locator(page, prefer_forms=prefer_forms)
        if not clicked:
            logger.info("ФСГС export menu item not found")
            return None

        data = await capture.wait(timeout_ms=30000)
        if data:
            return data

        try:
            async with page.expect_download(timeout=10000) as dl_info:
                await _click_export_menu_item_js(page, prefer_forms=prefer_forms)
            download = await dl_info.value
            data = await _read_download(download)
            if data.startswith(b"%PDF"):
                return data
        except Exception as exc:
            logger.info("ФСГС export expect_download fallback failed: %s", exc)
    except Exception as exc:
        logger.info("ФСГС export menu click failed: %s", exc)
        data = await capture.wait(timeout_ms=3000)
        if data:
            return data
    finally:
        capture.stop()
    return None


async def _open_export_menu(page) -> bool:
    export_menu = page.get_by_role("button", name=re.compile(r"Экспортировать", re.I)).first
    if await export_menu.count() == 0:
        return False
    try:
        expanded = await export_menu.get_attribute("aria-expanded")
        if expanded == "true":
            await _log_open_export_menu_items(page)
            return True
        await dismiss_cookie_consent(page, site="fsgs")
        await _dismiss_cdk_overlays(page)
        await export_menu.scroll_into_view_if_needed()
        await export_menu.click(timeout=5000, force=True)
        await page.locator(_EXPORT_MENU_PANEL_SELECTOR).first.wait_for(
            state="visible", timeout=4000
        )
        await _log_open_export_menu_items(page)
        return True
    except Exception as exc:
        logger.info("ФСГС export menu open failed: %s", exc)
        return False


async def _export_menu_has_pdf_items(page) -> bool:
    try:
        return bool(
            await page.evaluate(
                """({ selector, preferForms }) => {
                    const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
                    const score = (t) => {
                        const lower = norm(t).toLowerCase();
                        if (/excel|xls/i.test(lower)) return 0;
                        if (/уведомление/i.test(lower) && /ок\\s*тэи/i.test(lower)) {
                            if (/\\(pdf\\)|\\.pdf\\b|\\bpdf\\b/i.test(lower)) return 120;
                            if (!preferForms) return 80;
                            return 0;
                        }
                        if (preferForms && /^pdf$/i.test(lower)) return 100;
                        if (/\\.pdf$/i.test(lower) || /\\(pdf\\)/i.test(lower)) return 90;
                        if (preferForms && /\\bpdf\\b/i.test(lower)) return 70;
                        return 0;
                    };
                    const items = [...document.querySelectorAll(selector)];
                    return items.some((el) => {
                        if (el.disabled || el.getAttribute('aria-disabled') === 'true') return false;
                        return score(norm(el.innerText)) > 0;
                    });
                }""",
                {"selector": _EXPORT_MENU_ITEM_SELECTOR, "preferForms": False},
            )
        )
    except Exception:
        return False


async def _export_pdf(page) -> bytes:
    await _wait_for_export_ready(page, timeout_ms=15000)
    await dismiss_cookie_consent(page, site="fsgs")
    await _dismiss_cdk_overlays(page)

    has_codes = await _page_has_org_codes_data(page)
    has_forms = await _page_has_forms_list(page)
    prefer_forms = has_forms and not has_codes
    logger.info("ФСГС export mode has_codes=%s has_forms=%s prefer_forms=%s", has_codes, has_forms, prefer_forms)
    if has_forms:
        selected = await _select_all_forms(page)
        if selected:
            logger.info("ФСГС selected forms count=%s", selected)
            await page.wait_for_timeout(300)

    last_menu_items: list[str] = []
    for attempt in range(4):
        await dismiss_cookie_consent(page, site="fsgs")
        await _dismiss_cdk_overlays(page)
        if not await _open_export_menu(page):
            await page.wait_for_timeout(400)
            continue

        last_menu_items = await _collect_export_menu_item_texts(page)
        if not last_menu_items:
            await page.wait_for_timeout(500)
            last_menu_items = await _collect_export_menu_item_texts(page)

        try:
            await page.wait_for_function(
                """({ selector, preferForms }) => {
                    const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
                    const score = (t) => {
                        const lower = norm(t).toLowerCase();
                        if (/excel|xls/i.test(lower)) return 0;
                        if (/уведомление/i.test(lower) && /ок\\s*тэи/i.test(lower)) {
                            if (/\\(pdf\\)|\\.pdf\\b|\\bpdf\\b/i.test(lower)) return 120;
                            if (!preferForms) return 80;
                            return 0;
                        }
                        if (preferForms && /^pdf$/i.test(lower)) return 100;
                        if (/\\.pdf$/i.test(lower) || /\\(pdf\\)/i.test(lower)) return 90;
                        if (preferForms && /\\bpdf\\b/i.test(lower)) return 70;
                        return 0;
                    };
                    const items = [...document.querySelectorAll(selector)];
                    return items.some((el) => {
                        if (el.disabled || el.getAttribute('aria-disabled') === 'true') return false;
                        return score(norm(el.innerText)) > 0;
                    });
                }""",
                arg={"selector": _EXPORT_MENU_ITEM_SELECTOR, "preferForms": prefer_forms},
                timeout=10000,
            )
        except Exception:
            if has_forms:
                await _select_all_forms(page)
            if not await _export_menu_has_pdf_items(page):
                await _dismiss_cdk_overlays(page)
                await page.wait_for_timeout(500)
                continue

        data = await _click_export_menu_item(page, prefer_forms=prefer_forms)
        if data:
            return data
        await _dismiss_cdk_overlays(page)
        await page.wait_for_timeout(400)

    page_text = ""
    try:
        page_text = (await page.inner_text("body"))[:500]
    except Exception:
        pass
    logger.warning(
        "ФСГС export failed url=%s menu=%r preview=%r",
        page.url,
        last_menu_items,
        page_text,
    )
    raise FsgsError(
        "Не удалось выгрузить PDF ФСГС: пункт «Уведомление о кодах ОК ТЭИ.pdf» недоступен. "
        "Проверьте, что выбрана нужная организация на сайте Росстата."
    )


async def _resolve_hints(
    hints: FsgsMatchHints | None,
    hints_task: asyncio.Task | None,
) -> FsgsMatchHints | None:
    if hints is not None:
        return hints
    if hints_task is not None:
        return await hints_task
    return None


async def _prepare_info_page(page) -> None:
    await _open_info_page(page)
    await dismiss_cookie_consent(page, site="fsgs")


async def download_fsgs_pdf(
    inn: str,
    *,
    hints: FsgsMatchHints | None = None,
    hints_task: asyncio.Task[FsgsMatchHints] | None = None,
) -> bytes:
    if not _playwright_available():
        raise FsgsError("Установите playwright: pip install playwright && playwright install chromium")

    cached = get_cached_fsgs_pdf(inn)
    if cached is not None:
        logger.info("ФСГС cache hit inn=%s", normalize_inn(inn))
        return cached

    async with _get_browser_lock():
        browser = await _ensure_browser()
        page = await _ensure_page(browser)
        try:
            page_task = asyncio.create_task(_prepare_info_page(page))
            resolved_hints = await _resolve_hints(hints, hints_task)
            await page_task
            await _fill_search_and_submit(page, inn, resolved_hints)
            await dismiss_cookie_consent(page, site="fsgs")
            await _select_branch(page, resolved_hints, inn=inn)
            pdf_data = await _export_pdf(page)
            _store_cached_pdf(inn, pdf_data)
            return pdf_data
        except FsgsError as exc:
            logger.warning("ФСГС failed inn=%s: %s", inn, exc)
            raise
        except Exception as exc:
            logger.exception("ФСГС download failed inn=%s: %s", inn, exc)
            raise FsgsError(f"Не удалось получить PDF ФСГС: {exc}") from exc
