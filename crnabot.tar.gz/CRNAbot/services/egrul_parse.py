from __future__ import annotations

import re
from io import BytesIO

from pypdf import PdfReader

CREATION_METHODS = {
    "Создание юридического лица",
    "Создание юридического лица до 01.07.2002",
}

TERMINATION_MARKER = "Сведения о прекращении юридического лица"


def extract_pdf_text(data: bytes) -> str:
    reader = PdfReader(BytesIO(data))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def _section_after(text: str, marker: str, length: int = 2500) -> str:
    lower = text.lower()
    idx = lower.find(marker.lower())
    if idx < 0:
        return ""
    return text[idx : idx + length]


def _find_okved_in_section(section: str) -> str | None:
    patterns = [
        r"(?:ОКВЭД|код)\s*[:\s]*(\d{2}\.\d{2}(?:\.\d{1,2})?)\s*[-–—]?\s*([^\n\r]{3,120})",
        r"(\d{2}\.\d{2}(?:\.\d{1,2})?)\s+([А-ЯЁA-Z][^\n\r]{3,120})",
    ]
    for pattern in patterns:
        match = re.search(pattern, section, re.IGNORECASE)
        if match:
            code = match.group(1).strip()
            name = re.sub(r"\s+", " ", match.group(2).strip(" .;,"))
            return f"{code} — {name}"
    return None


def _detect_activities_type(section: str) -> str | None:
    lower = section.lower()
    if "сведения отчетного типа" in lower or "сведения отчётного типа" in lower:
        return "reporting"
    if "сведения заявительного типа" in lower:
        return "applicant"
    return None


def _parse_formation_method(text: str) -> str | None:
    section = _section_after(text, "Сведения о регистрации")
    if not section:
        return None
    match = re.search(
        r"Способ\s+образования\s+(.+?)(?:\n|$)",
        section,
        re.IGNORECASE,
    )
    if not match:
        return None
    value = re.sub(r"\s+", " ", match.group(1).strip(" .;,"))
    return value or None


def _parse_predecessor(text: str) -> dict | None:
    section = _section_after(text, "Сведения о правопредшественнике")
    if not section:
        section = _section_after(text, "Сведения о правопредшественниках")
    if not section:
        return None

    inn_match = re.search(r"\bИНН\s*(\d{10})\b", section, re.IGNORECASE)
    if not inn_match:
        inn_match = re.search(r"\b(\d{10})\b", section)
    ogrn_match = re.search(r"\bОГРН\s*(\d{13})\b", section, re.IGNORECASE)
    if not ogrn_match:
        ogrn_match = re.search(r"\b(\d{13})\b", section)

    name = None
    name_match = re.search(
        r"(?:Полное\s+наименование|Наименование)\s+(.+?)(?:\n|$)",
        section,
        re.IGNORECASE,
    )
    if name_match:
        name = re.sub(r"\s+", " ", name_match.group(1).strip(" .;,"))

    if not inn_match and not ogrn_match and not name:
        return None

    return {
        "inn": inn_match.group(1) if inn_match else None,
        "name": name,
        "ogrn": ogrn_match.group(1) if ogrn_match else None,
    }


def _parse_company_info(text: str) -> dict[str, str | None]:
    name = None
    short_name = None
    for marker in (
        "Сведения о наименовании юридического лица",
        "Сведения о наименовании",
    ):
        name_section = _section_after(text, marker, 2200)
        if not name_section:
            continue
        short_match = re.search(
            r"Сокращ[её]нное\s+наименование(?:\s+на\s+русском\s+языке)?\s*:?\s*\n?\s*"
            r"(.+?)(?:\n\n|\n(?:ГРН|Дата\s+внесения|Полное)|$)",
            name_section,
            re.IGNORECASE | re.DOTALL,
        )
        if short_match:
            short_name = re.sub(r"\s+", " ", short_match.group(1).strip(" .;,"))
        full_match = re.search(
            r"Полное\s+наименование(?:\s+на\s+русском\s+языке)?\s*:?\s*\n?\s*"
            r"(.+?)(?:\n\n|\n(?:ГРН|Дата\s+внесения|Сокращ)|$)",
            name_section,
            re.IGNORECASE | re.DOTALL,
        )
        if full_match:
            name = re.sub(r"\s+", " ", full_match.group(1).strip(" .;,"))
            break
        if short_name and not name:
            name = short_name
            break

    header = text[:4000]
    inn_match = re.search(r"\bИНН\s*(\d{10,12})\b", header, re.IGNORECASE)
    ogrn_match = re.search(r"\bОГРН\s*(\d{13})\b", header, re.IGNORECASE)

    address = None
    addr_section = _section_after(text, "Сведения об адресе", 2200)
    if not addr_section:
        addr_section = _section_after(text, "Адрес (место нахождения)", 2200)
    if addr_section:
        for pattern in (
            r"(?:Адрес(?:\s+\(место\s+нахождения\))?|Место\s+нахождения)\s*\n?\s*(.+?)(?:\n\n|\n(?:ГРН|Дата|Сведения)|$)",
            r"(?:Адрес\s+юридического\s+лица|Адрес)\s*\n?\s*(.+?)(?:\n\n|\n(?:ГРН|Дата|Сведения)|$)",
            r"(\d{6}\s*,.+?)(?:\n\n|\n(?:ГРН|Дата|Сведения)|$)",
        ):
            addr_match = re.search(pattern, addr_section, re.IGNORECASE | re.DOTALL)
            if addr_match:
                address = re.sub(r"\s+", " ", addr_match.group(1).strip(" .;,"))
                if len(address) > 10:
                    break

    status = None
    status_section = _section_after(text, "Сведения о состоянии", 800)
    if status_section:
        status_match = re.search(
            r"(?:Состояние|Статус)\s*\n?\s*(.+?)(?:\n|$)",
            status_section,
            re.IGNORECASE,
        )
        if status_match:
            status = re.sub(r"\s+", " ", status_match.group(1).strip(" .;,"))

    return {
        "name": name,
        "short_name": short_name,
        "inn": inn_match.group(1) if inn_match else None,
        "ogrn": ogrn_match.group(1) if ogrn_match else None,
        "address": address,
        "status": status,
    }


def _build_alerts(termination_notice: bool, unreliability_notice: bool) -> list[str]:
    alerts: list[str] = []
    if termination_notice:
        alerts.append("Имеются сведения о прекращении деятельности")
    if unreliability_notice:
        alerts.append("Имеются данные о недостоверности сведений")
    return alerts


def parse_egrul_pdf(pdf_bytes: bytes) -> dict:
    text = extract_pdf_text(pdf_bytes)

    activities_section = _section_after(
        text,
        "Сведения о видах экономической деятельности по Общероссийскому классификатору",
    )
    if not activities_section:
        activities_section = _section_after(
            text, "Сведения о видах экономической деятельности"
        )

    main_section = _section_after(text, "Сведения об основном виде деятельности")

    activities_type = _detect_activities_type(activities_section)
    main_okved = _find_okved_in_section(main_section)

    termination_notice = TERMINATION_MARKER in text
    unreliability_notice = "недостов" in text.lower()
    alerts = _build_alerts(termination_notice, unreliability_notice)

    formation_method = _parse_formation_method(text)
    predecessor = _parse_predecessor(text)
    company = _parse_company_info(text)
    needs_predecessor_egrul = bool(
        formation_method
        and formation_method not in CREATION_METHODS
        and predecessor
        and predecessor.get("inn")
    )

    return {
        "main_okved": main_okved,
        "activities_type": activities_type,
        "termination_notice": termination_notice,
        "unreliability_notice": unreliability_notice,
        "alerts": alerts,
        "formation_method": formation_method,
        "predecessor": predecessor,
        "needs_predecessor_egrul": needs_predecessor_egrul,
        "name": company.get("name"),
        "short_name": company.get("short_name"),
        "inn": company.get("inn"),
        "ogrn": company.get("ogrn"),
        "address": company.get("address"),
        "status": company.get("status"),
    }


def parse_egrul_okved(pdf_bytes: bytes) -> dict:
    parsed = parse_egrul_pdf(pdf_bytes)
    return {
        "main_okved": parsed.get("main_okved"),
        "activities_type": parsed.get("activities_type"),
    }
