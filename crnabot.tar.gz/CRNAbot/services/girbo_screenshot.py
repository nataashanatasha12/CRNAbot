from __future__ import annotations

import asyncio
import logging

from services.cookie_consent import dismiss_cookie_consent
from services.girbo import cache_girbo_okved_from_page, parse_okved_from_card_text

logger = logging.getLogger("crnabot.girbo_screenshot")

BO_SITE = "https://bo.nalog.gov.ru"

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
)

_playwright_ref = None
_browser_ref = None
_browser_lock = None


def _get_browser_lock():
    global _browser_lock
    if _browser_lock is None:
        _browser_lock = asyncio.Lock()
    return _browser_lock


def _playwright_available() -> bool:
    try:
        import playwright  # noqa: F401

        return True
    except ImportError:
        return False


async def _reset_browser() -> None:
    global _playwright_ref, _browser_ref
    if _browser_ref is not None:
        try:
            await _browser_ref.close()
        except Exception:
            pass
    _browser_ref = None
    if _playwright_ref is not None:
        try:
            await _playwright_ref.stop()
        except Exception:
            pass
    _playwright_ref = None


async def _launch_browser(playwright):
    launch_kwargs = {
        "headless": True,
        "args": ["--disable-blink-features=AutomationControlled"],
    }
    for channel in ("chrome", "chromium"):
        try:
            if channel == "chrome":
                return await playwright.chromium.launch(channel="chrome", **launch_kwargs)
            return await playwright.chromium.launch(**launch_kwargs)
        except Exception as exc:
            logger.info("GIR BO Playwright launch via %s failed: %s", channel, exc)
    return None


async def _ensure_browser():
    global _playwright_ref, _browser_ref
    if _browser_ref is not None:
        try:
            if _browser_ref.is_connected():
                return _browser_ref
        except Exception:
            pass
        await _reset_browser()
    from playwright.async_api import async_playwright

    _playwright_ref = await async_playwright().start()
    _browser_ref = await _launch_browser(_playwright_ref)
    if _browser_ref is None:
        raise RuntimeError("Не удалось запустить браузер для скриншота ГИР БО.")
    return _browser_ref


def _page_blocked(text: str) -> bool:
    sample = (text or "").strip()
    if not sample:
        return True
    lower = sample.lower()
    if "403 forbidden" in lower:
        return True
    if lower.startswith("403") and "nginx" in lower and len(sample) < 400:
        return True
    return False


async def _wait_card_ready(page, timeout_ms: int = 30000) -> bool:
    try:
        await page.wait_for_function(
            """() => {
                const text = (document.body?.innerText || '').replace(/\\s+/g, ' ');
                if (/403 Forbidden/i.test(text)) return false;
                if (/ОКВЭД/i.test(text)) return true;
                if (/основной вид деятельности/i.test(text)) return true;
                if (/organizations-card/i.test(window.location.pathname)) {
                    return /ИНН/i.test(text) && /ОГРН/i.test(text);
                }
                return false;
            }""",
            timeout=timeout_ms,
        )
        await page.wait_for_timeout(1200)
        return True
    except Exception as exc:
        logger.info("GIR BO card wait timeout: %s", exc)
        return False


async def _open_card_page(page, org_id: str, period: str) -> str | None:
    url = f"{BO_SITE}/organizations-card/{org_id}?period={period}"
    try:
        await page.goto(url, wait_until="load", timeout=60000)
        await page.wait_for_timeout(1500)
    except Exception as exc:
        logger.info("GIR BO navigation failed org_id=%s period=%s: %s", org_id, period, exc)
        return None

    body = await page.inner_text("body")
    if _page_blocked(body):
        logger.info("GIR BO blocked org_id=%s period=%s", org_id, period)
        return None

    if not await _wait_card_ready(page):
        logger.info("GIR BO card content not ready org_id=%s period=%s", org_id, period)
        return None

    await dismiss_cookie_consent(page, site="girbo")
    body = await page.inner_text("body")
    if _page_blocked(body):
        return None
    return body


async def extract_girbo_okved_from_card(org_id: str, period: str = "2024") -> str | None:
    """ОКВЭД с живой карточки ГИР БО за период (как на скриншоте)."""
    org_id = (org_id or "").strip()
    period = (period or "2024").strip()
    if not org_id or not _playwright_available():
        return None

    async with _get_browser_lock():
        context = page = None
        try:
            browser = await _ensure_browser()
            context = await browser.new_context(
                user_agent=USER_AGENT,
                locale="ru-RU",
                viewport={"width": 1400, "height": 1800},
                device_scale_factor=2,
                extra_http_headers={"Accept-Language": "ru-RU,ru;q=0.9"},
            )
            page = await context.new_page()
            body = await _open_card_page(page, org_id, period)
            if not body:
                return None
            okved = parse_okved_from_card_text(body)
            if okved:
                cache_girbo_okved_from_page(org_id, period, okved)
            return okved
        except Exception as exc:
            logger.info("GIR BO okved extract error org_id=%s: %s", org_id, exc)
            await _reset_browser()
            return None
        finally:
            if page:
                try:
                    await page.close()
                except Exception:
                    pass
            if context:
                try:
                    await context.close()
                except Exception:
                    pass


async def _capture_live_card(page, org_id: str, period: str) -> bytes | None:
    body = await _open_card_page(page, org_id, period)
    if not body:
        return None
    okved = parse_okved_from_card_text(body)
    if okved:
        cache_girbo_okved_from_page(org_id, period, okved)
    await dismiss_cookie_consent(page, site="girbo")
    data = await page.screenshot(full_page=True, type="png", animations="disabled")
    if len(data) < 1000:
        logger.info("GIR BO screenshot too small org_id=%s size=%s", org_id, len(data))
        return None
    return data


async def capture_girbo_card_png(org_id: str, period: str = "2024") -> bytes | None:
    """Скриншот карточки ГИР БО с подтверждением ОКВЭД за указанный период."""
    org_id = (org_id or "").strip()
    period = (period or "2024").strip()
    if not org_id:
        return None
    if not _playwright_available():
        logger.info("Playwright не установлен — скриншот ГИР БО пропущен org_id=%s", org_id)
        return None

    async with _get_browser_lock():
        context = page = None
        try:
            browser = await _ensure_browser()
            context = await browser.new_context(
                user_agent=USER_AGENT,
                locale="ru-RU",
                viewport={"width": 1400, "height": 1800},
                device_scale_factor=2,
                extra_http_headers={"Accept-Language": "ru-RU,ru;q=0.9"},
            )
            page = await context.new_page()
            data = await _capture_live_card(page, org_id, period)
            if data:
                logger.info(
                    "GIR BO screenshot OK org_id=%s period=%s size=%s",
                    org_id,
                    period,
                    len(data),
                )
            else:
                logger.info("GIR BO screenshot unavailable org_id=%s period=%s", org_id, period)
            return data
        except Exception as exc:
            logger.info("GIR BO screenshot error org_id=%s: %s", org_id, exc)
            await _reset_browser()
            return None
        finally:
            if page:
                try:
                    await page.close()
                except Exception:
                    pass
            if context:
                try:
                    await context.close()
                except Exception:
                    pass
