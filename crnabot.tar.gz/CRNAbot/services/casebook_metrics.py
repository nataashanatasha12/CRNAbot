from __future__ import annotations

import json
import re
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from services.report_validation import _row_map

CACHE_DIR = Path(__file__).resolve().parent.parent / ".cache"
METRICS_MAX_AGE_SEC = 8 * 3600
# Строка 2110 в ГИР БО — в тысячах рублей; Casebook — в рублях.
REVENUE_2110_SCALE = 1000

CASES_CLAIM_LABEL = r"исковые требования в роли третьего и иного лица"
ENFORCEMENT_CLAIM_LABEL = r"взыскания по открытым производствам"


@dataclass
class CasebookClaimMetrics:
    inn: str
    cases_third_party_claims: float | None
    enforcement_open_claims: float | None
    fetched_at: float

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> CasebookClaimMetrics:
        return cls(
            inn=str(data.get("inn") or ""),
            cases_third_party_claims=_as_amount(data.get("cases_third_party_claims")),
            enforcement_open_claims=_as_amount(data.get("enforcement_open_claims")),
            fetched_at=float(data.get("fetched_at") or 0),
        )


def _metrics_path(inn: str) -> Path:
    return CACHE_DIR / f"casebook_metrics_{inn.strip()}.json"


def _as_amount(value) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def save_casebook_metrics(metrics: CasebookClaimMetrics) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    metrics.fetched_at = time.time()
    _metrics_path(metrics.inn).write_text(
        json.dumps(metrics.to_dict(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def merge_casebook_metrics(
    inn: str,
    *,
    cases_third_party_claims: float | None = None,
    enforcement_open_claims: float | None = None,
) -> CasebookClaimMetrics:
    existing = load_cached_casebook_metrics(inn, max_age_sec=10**9)
    metrics = existing or CasebookClaimMetrics(inn, None, None, 0.0)
    if cases_third_party_claims is not None:
        metrics.cases_third_party_claims = cases_third_party_claims
    if enforcement_open_claims is not None:
        metrics.enforcement_open_claims = enforcement_open_claims
    save_casebook_metrics(metrics)
    return metrics


def load_cached_casebook_metrics(inn: str, *, max_age_sec: int = METRICS_MAX_AGE_SEC) -> CasebookClaimMetrics | None:
    path = _metrics_path(inn)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        metrics = CasebookClaimMetrics.from_dict(data)
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        return None
    if time.time() - metrics.fetched_at > max_age_sec:
        return None
    return metrics


def revenue_from_financial_rows(financial_rows: list[dict] | None) -> int | None:
    financial = _row_map(financial_rows or [])
    value = financial.get("2110")
    if value is None or value.amount <= 0:
        return None
    return value.amount * REVENUE_2110_SCALE


def _metrics_incomplete(metrics: CasebookClaimMetrics) -> list[str]:
    missing: list[str] = []
    if metrics.cases_third_party_claims is None:
        missing.append("дела")
    if metrics.enforcement_open_claims is None:
        missing.append("исполнительные производства")
    return missing


def compute_claim_load(
    metrics: CasebookClaimMetrics | None,
    financial_rows: list[dict] | None,
) -> dict | None:
    if metrics is None:
        return None
    incomplete = _metrics_incomplete(metrics)
    if incomplete:
        return {
            "available": False,
            "label": (
                "Исковая нагрузка: не удалось получить данные Casebook "
                f"({', '.join(incomplete)})"
            ),
            "high": False,
            "cases_amount": metrics.cases_third_party_claims,
            "enforcement_amount": metrics.enforcement_open_claims,
            "total_claims": None,
            "revenue": revenue_from_financial_rows(financial_rows),
            "percent": None,
        }
    revenue = revenue_from_financial_rows(financial_rows)
    cases_amt = metrics.cases_third_party_claims or 0.0
    enforcement_amt = metrics.enforcement_open_claims or 0.0
    total = cases_amt + enforcement_amt

    if revenue is None:
        return {
            "available": False,
            "label": "Исковая нагрузка: нет выручки (строка 2110)",
            "high": False,
            "cases_amount": cases_amt,
            "enforcement_amount": enforcement_amt,
            "total_claims": total,
            "revenue": None,
            "percent": None,
        }

    percent = total / revenue * 100
    high = percent > 30
    return {
        "available": True,
        "label": f"Исковая нагрузка {percent:.1f}%",
        "high": high,
        "cases_amount": cases_amt,
        "enforcement_amount": enforcement_amt,
        "total_claims": total,
        "revenue": revenue,
        "percent": round(percent, 2),
    }


async def extract_labeled_amount(page, label_pattern: str) -> float | None:
    amount = await page.evaluate(
        """(labelPattern) => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const labelRe = new RegExp(labelPattern, 'i');
            const parseMoney = (text) => {
                const t = norm(text).replace(/\\u00a0/g, ' ');
                const m = t.match(/([\\d][\\d\\s]*(?:[.,]\\d+)?)/);
                if (!m) return null;
                const n = parseFloat(m[1].replace(/\\s/g, '').replace(',', '.'));
                return Number.isFinite(n) ? n : null;
            };
            const amountsIn = (root) => {
                const out = [];
                for (const node of root.querySelectorAll('*')) {
                    const t = norm(node.innerText);
                    if (!t || t.length > 60) continue;
                    if (!/[\\d]/.test(t)) continue;
                    if (!/(₽|руб|р\\.)/i.test(t) && !/^\\d[\\d\\s.,]+$/.test(t)) continue;
                    const v = parseMoney(t);
                    if (v !== null) out.push(v);
                }
                return out;
            };

            for (const th of document.querySelectorAll('th,td,[role=columnheader],div,span')) {
                const label = norm(th.innerText);
                if (!labelRe.test(label) || label.length > 160) continue;
                const table = th.closest('table');
                if (table) {
                    const headerRow = th.closest('tr');
                    if (!headerRow) continue;
                    const colIdx = [...headerRow.children].indexOf(th.closest('th,td') || th);
                    if (colIdx < 0) continue;
                    let sum = 0;
                    let found = false;
                    for (const row of table.querySelectorAll('tr')) {
                        if (row === headerRow) continue;
                        const cell = row.children[colIdx];
                        if (!cell) continue;
                        const v = parseMoney(cell.innerText);
                        if (v !== null) {
                            sum += v;
                            found = true;
                        }
                    }
                    if (found) return sum;
                }
                let box = th;
                for (let depth = 0; depth < 5 && box; depth++, box = box.parentElement) {
                    const amounts = amountsIn(box);
                    if (amounts.length) {
                        return Math.max(...amounts);
                    }
                }
            }
            return null;
        }""",
        label_pattern,
    )
    return _as_amount(amount)


async def extract_cases_third_party_claims(page) -> float | None:
    return await extract_labeled_amount(page, CASES_CLAIM_LABEL)


async def extract_enforcement_open_claims(page) -> float | None:
    return await extract_labeled_amount(page, ENFORCEMENT_CLAIM_LABEL)


async def extract_casebook_claim_metrics(page, inn: str) -> CasebookClaimMetrics:
    return CasebookClaimMetrics(
        inn=inn,
        cases_third_party_claims=await extract_cases_third_party_claims(page),
        enforcement_open_claims=await extract_enforcement_open_claims(page),
        fetched_at=time.time(),
    )
