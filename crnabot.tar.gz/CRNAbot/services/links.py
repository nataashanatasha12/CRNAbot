from __future__ import annotations

from dataclasses import dataclass

from services.casebook import casebook_configured

from services.bankruptcy import BANKRUPTCY_URL

SPARK_DASHBOARD_URL = "https://spark-interfax.ru/system/#/dashboard"
FSGS_INFO_URL = "https://websbor.rosstat.gov.ru/online/info"
CASEBOOK_FEED_URL = "https://casebook.ru/app/feed"


@dataclass
class PortalLinks:
    inn: str
    girbo_card: str | None
    spark_card: str | None
    fedresurs_card: str | None
    casebook_feed: str
    casebook_screenshot: str | None = None
    casebook_enforcement_screenshot: str | None = None
    bankruptcy_url: str = BANKRUPTCY_URL
    fsgs_info: str = FSGS_INFO_URL
    fsgs_download: str | None = None


async def build_links(
    inn: str,
    org_id: str | None = None,
    fedresurs_card: str | None = None,
) -> PortalLinks:
    inn = inn.strip()
    girbo_card = f"https://bo.nalog.gov.ru/organizations-card/{org_id}" if org_id else None
    return PortalLinks(
        inn=inn,
        girbo_card=girbo_card,
        spark_card=SPARK_DASHBOARD_URL,
        fedresurs_card=fedresurs_card,
        casebook_feed=CASEBOOK_FEED_URL,
        casebook_screenshot=f"/api/download/casebook?inn={inn}" if casebook_configured() else None,
        casebook_enforcement_screenshot=(
            f"/api/download/casebook-enforcement?inn={inn}" if casebook_configured() else None
        ),
        bankruptcy_url=BANKRUPTCY_URL,
        fsgs_info=FSGS_INFO_URL,
        fsgs_download=f"/api/download/fsgs?inn={inn}",
    )
