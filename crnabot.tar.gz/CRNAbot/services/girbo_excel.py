from __future__ import annotations

import io
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Font


def _row_values(row: dict[str, Any]) -> list[Any]:
    return [
        row.get("code"),
        row.get("name"),
        row.get("current"),
        row.get("previous"),
        row.get("before_previous") or row.get("beforePrevious"),
    ]


def form_rows_to_xlsx(
    rows: list[dict[str, Any]],
    *,
    form_title: str,
    period: str,
    sheet_name: str,
) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name[:31]

    ws.append([form_title])
    ws["A1"].font = Font(bold=True)
    ws.append([f"Отчётный период: {period}"])
    ws.append([])

    headers = ["Код", "Наименование", "Текущий", "Предыдущий", "Предпредыдущий"]
    ws.append(headers)
    for cell in ws[ws.max_row]:
        cell.font = Font(bold=True)

    for row in rows:
        ws.append(_row_values(row))
        for detail in row.get("details") or []:
            detail_row = _row_values(detail)
            if detail_row[1]:
                detail_row[1] = f"  {detail_row[1]}"
            ws.append(detail_row)

    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()
