from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any


@dataclass
class ParsedValue:
    amount: int
    in_parentheses: bool
    raw: Any
    invalid_format: bool = False


_INVALID_PAREN_MINUS_MESSAGE = "недопустимо отрицательное значение в скобках"
_FOOTNOTE_AFTER_PAREN = re.compile(r"^(\([^)]+\))\s*\d{1,2}$")
# Строки баланса, где положительное значение из API печатают в скобках (уменьшают итог).
_BALANCE_PARENS_IF_POSITIVE_CODES = frozenset({"1320"})


def _normalize_display_cell_text(text: str) -> str:
    """Убирает сноску после скобок: (1 531)6 → (1 531)."""
    text = text.strip()
    match = _FOOTNOTE_AFTER_PAREN.match(text)
    if match:
        return match.group(1).strip()
    return text


def _parse_cell_value(value: Any) -> ParsedValue | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        amount = int(round(value))
        # Число из API уже со знаком; скобки — только для строкового отображения.
        return ParsedValue(amount=amount, in_parentheses=False, raw=value)
    text = _normalize_display_cell_text(str(value).strip())
    if not text or text in {"-", "—", "–"}:
        return None
    in_parentheses = bool(re.fullmatch(r"\(.*\)", text))
    if in_parentheses:
        inner = text[1:-1].strip()
        inner_cleaned = (
            inner.replace("\u00a0", "")
            .replace(" ", "")
            .replace("−", "-")
        )
        if inner_cleaned.startswith("-"):
            return ParsedValue(
                amount=0,
                in_parentheses=True,
                raw=value,
                invalid_format=True,
            )
        text = inner
    cleaned = (
        text.replace("\u00a0", "")
        .replace(" ", "")
        .replace(",", ".")
        .replace("−", "-")
    )
    try:
        amount = int(round(float(cleaned)))
    except ValueError:
        return None
    if in_parentheses and amount > 0:
        amount = -amount
    return ParsedValue(amount=amount, in_parentheses=in_parentheses, raw=value)


def _parse_row_cell_value(row: dict[str, Any], column: str = "current") -> ParsedValue | None:
    parsed = _parse_cell_value(row.get(column))
    if parsed is None or parsed.invalid_format:
        return parsed
    code = str(row.get("code") or "").strip()
    if row.get(f"{column}_in_parentheses") and not parsed.in_parentheses and parsed.amount > 0:
        return ParsedValue(
            amount=-parsed.amount,
            in_parentheses=True,
            raw=parsed.raw,
            invalid_format=False,
        )
    if (
        column == "current"
        and code in _BALANCE_PARENS_IF_POSITIVE_CODES
        and not parsed.in_parentheses
        and parsed.amount > 0
    ):
        return ParsedValue(
            amount=-parsed.amount,
            in_parentheses=True,
            raw=parsed.raw,
            invalid_format=False,
        )
    return parsed


@dataclass
class ReportValidation:
    ok: bool
    status: str
    messages: list[str]
    flags: list[str]


def _signed_amount(value: ParsedValue) -> int:
    """Сумма со знаком для арифметики: (3062) = −3062; (-3062) — ошибка заполнения."""
    if value.invalid_format:
        return 0
    if value.in_parentheses and value.amount > 0:
        return -value.amount
    return value.amount


def _check_invalid_cell_formats(
    rows: list[dict[str, Any]],
    *columns: str,
) -> list[str]:
    errors: list[str] = []
    for row in rows:
        code = str(row.get("code") or "").strip()
        if not code:
            continue
        for column in columns:
            parsed = _parse_row_cell_value(row, column)
            if parsed and parsed.invalid_format:
                errors.append(f"строка {code}: {_INVALID_PAREN_MINUS_MESSAGE}")
                break
    return errors


def _row_map(rows: list[dict[str, Any]]) -> dict[str, ParsedValue]:
    mapped: dict[str, ParsedValue] = {}
    for row in rows:
        code = str(row.get("code") or "").strip()
        if not code:
            continue
        parsed = _parse_row_cell_value(row, "current")
        if parsed is not None and not parsed.invalid_format:
            mapped[code] = parsed
    return mapped


def _check_required(rows: dict[str, ParsedValue], code: str) -> str | None:
    if code not in rows:
        return f"строка {code}: нет данных"
    return None


def _check_positive_if_present(rows: dict[str, ParsedValue], code: str) -> str | None:
    value = rows.get(code)
    if value is None:
        return None
    if value.in_parentheses or value.amount <= 0:
        return f"строка {code}: должна быть больше 0 и не в скобках"
    return None


def _check_non_negative_if_present(rows: dict[str, ParsedValue], code: str) -> str | None:
    value = rows.get(code)
    if value is None:
        return None
    if value.in_parentheses or value.amount < 0:
        return f"строка {code}: не должна быть в скобках"
    return None


_CAPITAL_POSITIVE_MESSAGES = {
    "1310": "Уставный капитал отрицательный или равен 0",
    "1300": "Собственные средства отрицательные или равны 0",
}

_PREVIOUS_YEAR_ZERO_MESSAGE = (
    'Наличие нулевых значений в столбце "на 31 декабря предыдущего года"'
)


def _check_required_positive_message(
    rows: dict[str, ParsedValue],
    code: str,
    *,
    bad_value_message: str,
) -> str | None:
    err = _check_required(rows, code)
    if err:
        return err
    value = rows.get(code)
    if value and (value.in_parentheses or value.amount <= 0):
        return bad_value_message
    return None


def _check_required_positive(rows: dict[str, ParsedValue], code: str) -> str | None:
    err = _check_required(rows, code)
    if err:
        return err
    return _check_positive_if_present(rows, code)


def _is_negative_value(value: ParsedValue | None) -> bool:
    return value is not None and (value.in_parentheses or value.amount < 0)


def _has_negative_charter_capital(balance: dict[str, ParsedValue], section_total: ParsedValue | None) -> bool:
    if _is_negative_value(balance.get("1310")):
        return True
    return _is_negative_value(section_total)


def _check_equality(left: int, right: int, label: str) -> str | None:
    if left != right:
        return f"{label}: {left} ≠ {right}"
    return None


def _line_codes(start: int, end: int) -> list[str]:
    return [str(code) for code in range(start, end + 1, 10)]


_BALANCE_DETAIL_SUM_CHECKS = (
    ("1100", 1110, 1190, "сумма строк 1110–1190"),
    ("1200", 1210, 1260, "сумма строк 1210–1260"),
    ("1300", 1310, 1370, "сумма строк 1310–1370"),
    ("1400", 1410, 1450, "сумма строк 1410–1450"),
    ("1500", 1510, 1550, "сумма строк 1510–1550"),
)


_PREVIOUS_YEAR_KEY_CODES = frozenset({"1600", "1700", "1300", "1100", "1200", "2110", "2400"})


def _has_meaningful_amount(value: ParsedValue | None) -> bool:
    return value is not None and not (value.amount == 0 and not value.in_parentheses)


def _previous_year_column_effectively_empty(rows: list[dict[str, Any]]) -> bool:
    """Пустой прошлый год — только если по ключевым строкам нет данных, а текущий период заполнен."""
    saw_current = False
    saw_previous = False
    for row in rows:
        code = str(row.get("code") or "").strip()
        if code not in _PREVIOUS_YEAR_KEY_CODES:
            continue
        current = _parse_row_cell_value(row, "current")
        previous = _parse_row_cell_value(row, "previous")
        if _has_meaningful_amount(current):
            saw_current = True
        if _has_meaningful_amount(previous):
            saw_previous = True
    return saw_current and not saw_previous


def _check_zero_previous_year_column(
    balance_rows: list[dict[str, Any]],
    financial_rows: list[dict[str, Any]],
) -> str | None:
    if _previous_year_column_effectively_empty(balance_rows) or _previous_year_column_effectively_empty(
        financial_rows
    ):
        return _PREVIOUS_YEAR_ZERO_MESSAGE
    return None


def _check_balance_detail_sum(
    balance: dict[str, ParsedValue],
    parent_code: str,
    detail_start: int,
    detail_end: int,
    label: str,
) -> str | None:
    detail_codes = _line_codes(detail_start, detail_end)
    present = [code for code in detail_codes if code in balance]
    if not present:
        return None
    detail_sum = sum(_signed_amount(balance[code]) for code in present)
    parent = balance.get(parent_code)
    if parent is None:
        return f"{label}: нет строки {parent_code}"
    return _check_equality(detail_sum, _signed_amount(parent), f"{label} = {parent_code}")


def validate_reporting(
    balance_rows: list[dict[str, Any]],
    financial_rows: list[dict[str, Any]] | None = None,
) -> ReportValidation:
    messages: list[str] = []
    flags: list[str] = []
    errors: list[str] = []

    balance = _row_map(balance_rows)
    financial = _row_map(financial_rows or [])

    errors.extend(_check_invalid_cell_formats(balance_rows, "current", "previous"))
    errors.extend(_check_invalid_cell_formats(financial_rows or [], "current", "previous"))

    for code in ("1600", "1700"):
        err = _check_required(balance, code)
        if err:
            errors.append(err)

    for code in ("1300", "1310"):
        err = _check_required_positive_message(
            balance,
            code,
            bad_value_message=_CAPITAL_POSITIVE_MESSAGES[code],
        )
        if err:
            errors.append(err)

    for code in ("2110",):
        err = _check_required_positive(financial, code)
        if err:
            errors.append(err)

    v1100 = balance.get("1100")
    v1200 = balance.get("1200")
    v1300 = balance.get("1300")
    v1400 = balance.get("1400")
    v1500 = balance.get("1500")
    v1600 = balance.get("1600")
    v1700 = balance.get("1700")

    for parent_code, detail_start, detail_end, label in _BALANCE_DETAIL_SUM_CHECKS:
        err = _check_balance_detail_sum(balance, parent_code, detail_start, detail_end, label)
        if err:
            errors.append(err)

    if v1600 and v1700:
        err = _check_equality(_signed_amount(v1600), _signed_amount(v1700), "строка 1600 = 1700")
        if err:
            errors.append(err)

    if v1100 and v1200 and v1600:
        err = _check_equality(
            _signed_amount(v1100) + _signed_amount(v1200),
            _signed_amount(v1600),
            "строка 1100 + 1200 = 1600",
        )
        if err:
            errors.append(err)

    if v1300 and v1400 and v1500 and v1700:
        err = _check_equality(
            _signed_amount(v1300) + _signed_amount(v1400) + _signed_amount(v1500),
            _signed_amount(v1700),
            "строка 1300 + 1400 + 1500 = 1700",
        )
        if err:
            errors.append(err)

    for code in ("1400", "1500"):
        err = _check_non_negative_if_present(balance, code)
        if err:
            errors.append(err)

    for code in ("2340",):
        err = _check_positive_if_present(financial, code)
        if err:
            errors.append(err)

    err = _check_zero_previous_year_column(balance_rows, financial_rows or [])
    if err:
        errors.append(err)

    ok = not errors
    if ok and _has_negative_charter_capital(balance, v1300):
        flags.append("Компания имеет отрицательный Уставный капитал")
    if ok:
        status = "Отчетность сверена"
    else:
        detail = "; ".join(errors)
        status = f"Отчетность заполнена с ошибками ({detail})"
    return ReportValidation(ok=ok, status=status, messages=messages, flags=flags)
