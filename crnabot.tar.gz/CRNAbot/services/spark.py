from __future__ import annotations

import logging
import re
from xml.etree import ElementTree as ET

import aiohttp

logger = logging.getLogger("crnabot.spark")

SPARK_CARD_URL = "https://spark-interfax.ru/system/home/card#/company/{guid}/101"
SPARK_SEARCH_URL = "https://spark-interfax.ru/search?Query={inn}"
SPARK_SOAP_URLS = (
    "https://sparkgate.interfax.ru/iFaxWebService/iFaxWebService.asmx",
    "http://sparkgate.interfax.ru/iFaxWebService/iFaxWebService.asmx",
)
GUID_RE = re.compile(r"\b([0-9A-F]{32})\b", re.IGNORECASE)
GUID_TAGS = {
    "CompanyId",
    "companyId",
    "CompanyGUID",
    "companyGuid",
    "GUID",
    "Guid",
    "SparkGUID",
    "EntityId",
}
SPARK_ID_TAGS = {"SparkID", "sparkId", "SparkId", "sparkID"}

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/json,*/*",
    "Accept-Language": "ru-RU,ru;q=0.9",
}


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _xml_escape(value: str) -> str:
    return (
        value.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _extract_xml_datas(xml: str) -> list[str]:
    chunks: list[str] = []
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return [xml]

    for elem in root.iter():
        if _local_name(elem.tag).lower() == "xmldata" and elem.text and elem.text.strip():
            chunks.append(elem.text.strip())
    return chunks or [xml]


def _parse_company_ref(xml: str, inn: str) -> dict[str, str | None]:
    refs: dict[str, str | None] = {"guid": None, "spark_id": None}

    for chunk in _extract_xml_datas(xml):
        payloads = [chunk]
        if chunk.startswith("<"):
            try:
                payloads.append(ET.tostring(ET.fromstring(chunk), encoding="unicode"))
            except ET.ParseError:
                pass

        for payload in payloads:
            for guid in GUID_RE.findall(payload):
                upper = guid.upper()
                if upper != inn:
                    refs["guid"] = upper
                    break

            try:
                root = ET.fromstring(payload) if payload.startswith("<") else None
            except ET.ParseError:
                root = None

            if root is not None:
                for elem in root.iter():
                    name = _local_name(elem.tag)
                    text = (elem.text or "").strip()
                    if not text:
                        continue
                    if name in SPARK_ID_TAGS and text.isdigit():
                        refs["spark_id"] = text
                    if name in GUID_TAGS:
                        match = GUID_RE.fullmatch(text)
                        if match:
                            refs["guid"] = match.group(1).upper()

    return refs


async def _soap_call(
    session: aiohttp.ClientSession,
    soap_url: str,
    action: str,
    body: str,
) -> str:
    envelope = (
        '<?xml version="1.0" encoding="utf-8"?>'
        '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
        'xmlns:xsd="http://www.w3.org/2001/XMLSchema" '
        'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
        "<soap:Body>"
        f"{body}"
        "</soap:Body>"
        "</soap:Envelope>"
    )
    headers = {
        "Content-Type": "text/xml; charset=utf-8",
        "SOAPAction": f'"http://interfax.ru/webservices/{action}"',
    }
    async with session.post(soap_url, data=envelope.encode("utf-8"), headers=headers) as resp:
        text = await resp.text()
        if resp.status != 200:
            raise RuntimeError(f"SPARK SOAP HTTP {resp.status}")
        return text


async def _resolve_via_soap(inn: str) -> dict[str, str | None]:
    import os

    login = os.getenv("SPARK_LOGIN", "").strip()
    password = os.getenv("SPARK_PASSWORD", "").strip()
    if not login or not password:
        return {"guid": None, "spark_id": None}

    timeout = aiohttp.ClientTimeout(total=40)
    refs: dict[str, str | None] = {"guid": None, "spark_id": None}

    for soap_url in SPARK_SOAP_URLS:
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                auth_body = (
                    '<Authmethod xmlns="http://interfax.ru/webservices">'
                    f"<Login>{_xml_escape(login)}</Login>"
                    f"<Password>{_xml_escape(password)}</Password>"
                    "</Authmethod>"
                )
                try:
                    await _soap_call(session, soap_url, "Authmethod", auth_body)
                except Exception as exc:
                    logger.warning("SPARK auth failed (%s): %s", soap_url, exc)
                    continue

                requests = (
                    (
                        "FindCompanyByCode",
                        (
                            '<FindCompanyByCode xmlns="http://interfax.ru/webservices">'
                            f"<code>{inn}</code>"
                            "<codeType>Inn</codeType>"
                            "</FindCompanyByCode>"
                        ),
                    ),
                    (
                        "FindCompanyByCode",
                        (
                            '<FindCompanyByCode xmlns="http://interfax.ru/webservices">'
                            f"<code>{inn}</code>"
                            "<codeType>INN</codeType>"
                            "</FindCompanyByCode>"
                        ),
                    ),
                    (
                        "GetCompanyShortReport",
                        (
                            '<GetCompanyShortReport xmlns="http://interfax.ru/webservices">'
                            f"<inn>{inn}</inn>"
                            "</GetCompanyShortReport>"
                        ),
                    ),
                )

                for method, payload in requests:
                    try:
                        xml = await _soap_call(session, soap_url, method, payload)
                    except Exception as exc:
                        logger.warning("SPARK %s failed: %s", method, exc)
                        continue

                    parsed = _parse_company_ref(xml, inn)
                    refs["guid"] = refs["guid"] or parsed.get("guid")
                    refs["spark_id"] = refs["spark_id"] or parsed.get("spark_id")

                if refs["spark_id"] and not refs["guid"]:
                    try:
                        xml = await _soap_call(
                            session,
                            soap_url,
                            "GetCompanyShortReport",
                            (
                                '<GetCompanyShortReport xmlns="http://interfax.ru/webservices">'
                                f"<sparkId>{refs['spark_id']}</sparkId>"
                                "</GetCompanyShortReport>"
                            ),
                        )
                        parsed = _parse_company_ref(xml, inn)
                        refs["guid"] = parsed.get("guid") or refs["guid"]
                    except Exception as exc:
                        logger.warning("SPARK GetCompanyShortReport by sparkId failed: %s", exc)

                try:
                    await _soap_call(
                        session,
                        soap_url,
                        "End",
                        '<End xmlns="http://interfax.ru/webservices" />',
                    )
                except Exception:
                    pass

                if refs["guid"]:
                    return refs
        except Exception as exc:
            logger.warning("SPARK SOAP unavailable (%s): %s", soap_url, exc)

    return refs


def _extract_guid_from_html(html: str, inn: str) -> str | None:
    patterns = [
        r'companyId["\']\s*:\s*["\']([0-9A-F]{32})["\']',
        r'companyGuid["\']\s*:\s*["\']([0-9A-F]{32})["\']',
        r'entityId["\']\s*:\s*["\']([0-9A-F]{32})["\']',
        r'/company/([0-9A-F]{32})/',
        r'#/company/([0-9A-F]{32})',
        rf'inn-{re.escape(inn)}[^"\']*?([0-9A-F]{{32}})',
    ]
    for pattern in patterns:
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            return match.group(1).upper()
    return None


async def _resolve_via_public_search(inn: str) -> str | None:
    timeout = aiohttp.ClientTimeout(total=20)
    async with aiohttp.ClientSession(timeout=timeout, headers=HEADERS) as session:
        for url in (
            SPARK_SEARCH_URL.format(inn=inn),
            f"https://spark-interfax.ru/system/home/card#/textsearch/{inn}",
        ):
            try:
                async with session.get(url, allow_redirects=True) as resp:
                    if resp.status != 200:
                        continue
                    html = await resp.text()
                    final_url = str(resp.url)
            except Exception:
                continue

            for payload in (html, final_url):
                guid = _extract_guid_from_html(payload, inn)
                if guid:
                    return guid
    return None


async def resolve_spark_company_ref(inn: str) -> dict[str, str | None]:
    inn = inn.strip()
    refs = await _resolve_via_soap(inn)
    if not refs.get("guid"):
        public_guid = await _resolve_via_public_search(inn)
        if public_guid:
            refs["guid"] = public_guid
    return refs


async def build_spark_card_url(inn: str) -> str:
    inn = inn.strip()
    refs = await resolve_spark_company_ref(inn)
    guid = refs.get("guid")
    if guid:
        return SPARK_CARD_URL.format(guid=guid)

    return SPARK_SEARCH_URL.format(inn=inn)
