from __future__ import annotations

GIRBO_OKVED_PERIOD = "2024"


def needs_girbo_okved_screenshot(
    activities_type: str | None,
    okved_source: str | None,
) -> bool:
    """Скриншот карточки ГИР БО за 2024 — для заявительного ОКВЭД или если код взят из ГИР БО."""
    if activities_type == "applicant":
        return True
    return okved_source == "girbo"


def resolve_okved(
    *,
    egrul_main: str | None,
    activities_type: str | None,
    girbo_okved: str | None,
) -> dict:
    """
    - «Сведения отчетного типа» в ЕГРЮЛ → ОКВЭД из выписки ЕГРЮЛ (основной вид)
    - «Сведения заявительного типа» в ЕГРЮЛ → ОКВЭД из ГИР БО за 2024 год
    """
    if activities_type == "reporting":
        if egrul_main:
            return {
                "okved": egrul_main,
                "source": "egrul",
                "note": "Сведения отчетного типа — ОКВЭД из выписки ЕГРЮЛ",
            }
        return {
            "okved": girbo_okved,
            "source": "girbo",
            "note": "Сведения отчетного типа, но в ЕГРЮЛ нет кода — взят из ГИР БО",
        }

    if activities_type == "applicant":
        if girbo_okved:
            return {
                "okved": girbo_okved,
                "source": "girbo",
                "note": "Сведения заявительного типа — ОКВЭД из ГИР БО за 2024",
            }
        if egrul_main:
            return {
                "okved": egrul_main,
                "source": "egrul",
                "note": "Сведения заявительного типа, но в ГИР БО нет данных — взят из ЕГРЮЛ",
            }

    if egrul_main:
        return {
            "okved": egrul_main,
            "source": "egrul",
            "note": "ОКВЭД из выписки ЕГРЮЛ (основной вид деятельности)",
        }

    if girbo_okved:
        return {
            "okved": girbo_okved,
            "source": "girbo",
            "note": "ОКВЭД из ГИР БО (резервный источник)",
        }

    return {"okved": None, "source": None, "note": "ОКВЭД не определён"}
