from __future__ import annotations

import re
from typing import Any

_LINE_NAME: dict[str, str] = {
    "1100": "Итого по разделу I",
    "1110": "Нематериальные активы",
    "1150": "Основные средства",
    "1170": "Финансовые вложения",
    "1200": "Итого по разделу II",
    "1210": "Запасы",
    "1230": "Дебиторская задолженность",
    "1250": "Денежные средства и денежные эквиваленты",
    "1300": "Итого по разделу III",
    "1310": "Уставный капитал",
    "1320": "Собственные акции, выкупленные у акционеров",
    "1370": "Нераспределённая прибыль (непокрытый убыток)",
    "1400": "Итого по разделу IV",
    "1500": "Итого по разделу V",
    "1520": "Кредиторская задолженность",
    "1600": "БАЛАНС",
    "2110": "Выручка",
    "2120": "Себестоимость продаж",
    "2100": "Валовая прибыль (убыток)",
    "2200": "Прибыль (убыток) от продаж",
    "2300": "Прибыль (убыток) до налогообложения",
    "2400": "Чистая прибыль (убыток)",
}

_PERIOD_FIELDS = ("current", "previous", "before_previous", "beforePrevious")
_NEGATIVE_HINT_MARKERS = ("negative", "parenthes", "bracket", "скобк", "minus")
_NEGATIVE_TRUTHY = {True, "true", "True", "Y", "y", 1, "1", "-", "minus", "negative"}


def _negative_hint_truthy(value: Any) -> bool:
    return value in _NEGATIVE_TRUTHY


def _field_has_negative_hint(item: dict[str, Any], field: str) -> bool:
    field_l = field.lower()
    for key, value in item.items():
        key_l = str(key).lower()
        if field_l not in key_l:
            continue
        if any(marker in key_l for marker in _NEGATIVE_HINT_MARKERS):
            if _negative_hint_truthy(value):
                return True
    for key in ("negative", "isNegative", "inParentheses", "in_parentheses", "sign"):
        if key in item and _negative_hint_truthy(item.get(key)):
            return True
    return False


def _apply_negative_display(value: Any) -> tuple[Any, bool]:
    """Положительное значение из API, которое в балансе показывают в скобках."""
    if isinstance(value, (int, float)) and int(round(value)) > 0:
        return -int(round(value)), True
    text = str(value).strip()
    if text and not text.startswith("("):
        return f"({text})", True
    return value, True


def _normalize_period_value(item: dict[str, Any], field: str, value: Any) -> tuple[Any, bool]:
    if value is None:
        return None, False
    if _field_has_negative_hint(item, field):
        return _apply_negative_display(value)
    return value, False


def _rows_from_array(items: list[Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        code = item.get("code")
        if code is None:
            continue
        current, current_paren = _normalize_period_value(item, "current", item.get("current"))
        previous, previous_paren = _normalize_period_value(item, "previous", item.get("previous"))
        before_previous, before_previous_paren = _normalize_period_value(
            item,
            "before_previous",
            item.get("before_previous") or item.get("beforePrevious"),
        )
        rows.append(
            {
                "code": code,
                "name": item.get("name") or _LINE_NAME.get(str(code), ""),
                "current": current,
                "previous": previous,
                "before_previous": before_previous,
                "current_in_parentheses": current_paren,
                "previous_in_parentheses": previous_paren,
                "before_previous_in_parentheses": before_previous_paren,
                "details": item.get("details") or [],
            }
        )
    return rows


def _flat_period_key(period_key: str) -> str:
    if period_key == "beforePrevious":
        return "before_previous"
    return period_key


def _rows_from_flat(form: dict[str, Any]) -> list[dict[str, Any]]:
    codes: dict[str, dict[str, Any]] = {}
    negative_flags: dict[tuple[str, str], bool] = {}

    for key, value in form.items():
        key_str = str(key)
        neg_match = re.match(
            r"^(current|previous|beforePrevious|before_previous)(\d+)"
            r"(?:Negative|_negative|InParentheses|_in_parentheses)$",
            key_str,
            re.IGNORECASE,
        )
        if neg_match and _negative_hint_truthy(value):
            negative_flags[(_flat_period_key(neg_match.group(1)), neg_match.group(2))] = True
            continue

        match = re.match(r"^(current|previous|beforePrevious|before_previous)(\d+)$", key_str)
        if not match:
            continue
        period_key, code = _flat_period_key(match.group(1)), match.group(2)
        bucket = codes.setdefault(
            code,
            {
                "code": code,
                "name": _LINE_NAME.get(code, ""),
                "current": None,
                "previous": None,
                "before_previous": None,
                "current_in_parentheses": False,
                "previous_in_parentheses": False,
                "before_previous_in_parentheses": False,
            },
        )
        if period_key == "current":
            bucket["current"] = value
        elif period_key == "previous":
            bucket["previous"] = value
        else:
            bucket["before_previous"] = value

    for (period_key, code), flagged in negative_flags.items():
        if not flagged:
            continue
        bucket = codes.get(code)
        if not bucket:
            continue
        field = period_key
        paren_field = f"{field}_in_parentheses"
        raw = bucket.get(field)
        if raw is None:
            continue
        normalized, _ = _apply_negative_display(raw)
        bucket[field] = normalized
        bucket[paren_field] = True

    return [codes[k] for k in sorted(codes, key=lambda x: int(x))]


def extract_form_rows(correction: dict[str, Any], *keys: str) -> list[dict[str, Any]]:
    for key in keys:
        payload = correction.get(key)
        if isinstance(payload, list) and payload:
            rows = _rows_from_array(payload)
            if rows:
                return rows
        if isinstance(payload, dict) and payload:
            rows = _rows_from_flat(payload)
            if rows:
                return rows
    return []
