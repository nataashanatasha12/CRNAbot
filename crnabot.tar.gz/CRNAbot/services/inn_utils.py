from __future__ import annotations

import re
from typing import Any


def normalize_inn(value: Any) -> str:
    digits = re.sub(r"\D", "", str(value or "").strip())
    if not digits:
        return ""
    if len(digits) == 9:
        digits = f"0{digits}"
    return digits


def inn_equal(left: Any, right: Any) -> bool:
    a, b = normalize_inn(left), normalize_inn(right)
    if not a or not b:
        return False
    if len(a) <= 10 and len(b) <= 10:
        return a.zfill(10) == b.zfill(10)
    return a == b
