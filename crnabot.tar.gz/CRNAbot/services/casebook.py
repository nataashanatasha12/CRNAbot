from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path

from services.inn_utils import normalize_inn
from services.casebook_metrics import (
    extract_cases_third_party_claims,
    extract_enforcement_open_claims,
    load_cached_casebook_metrics,
    merge_casebook_metrics,
)

logger = logging.getLogger("crnabot.casebook")

CASEBOOK_SITE = "https://casebook.ru"
CASEBOOK_FEED_URL = f"{CASEBOOK_SITE}/app/feed"
CASEBOOK_LOGON_URL = f"{CASEBOOK_SITE}/Logon"
CACHE_DIR = Path(__file__).resolve().parent.parent / ".cache"
SESSION_FILE = CACHE_DIR / "casebook_session.json"
SESSION_MAX_AGE_SEC = 8 * 3600
ENFORCEMENT_TIMEOUT_SEC = 120
REGISTRIES_API_HINT = "License/GetLicenses"
ENFORCEMENT_API_HINT = "GetExecutoryProcesses"
CARD_TOP_TAB_MARKERS = ("Компания", "Дела", "Реестры", "Контракты")
REGISTRIES_URL_RE = re.compile(r"/card/company/(?:licenses|registr|reestr|registry)/", re.I)
ENFORCEMENT_URL_RE = re.compile(r"/card/company/(?:fssp|executory|enforcement|executions)/", re.I)

_browser_lock = asyncio.Lock()
_playwright_ref = None
_browser_ref = None
ORG_MARKERS = ("ооо", "ао", "пао", "зао", "оао", "компания", "организация", "огрн", "юридическ")
PERSON_MARKERS = ("физическ", "физ. лиц", "генеральный директор", "директор", "предприниматель", "гражданин")
BRANCH_MARKERS = (
    "филиал",
    "обособленное подразделение",
    "представительство",
    "структурное подразделение",
)
BRANCH_EXTRA_RE = re.compile(
    r"(?:^|[\s,])фл(?:[\s\"»]|$)|\bфл\.|каскад\s+\w+\s+гэс",
    re.IGNORECASE,
)
LEGAL_FORM_NORMALIZERS = (
    ("ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ", "ООО"),
    ("ПУБЛИЧНОЕ АКЦИОНЕРНОЕ ОБЩЕСТВО", "ПАО"),
    ("НЕПУБЛИЧНОЕ АКЦИОНЕРНОЕ ОБЩЕСТВО", "НАО"),
    ("АКЦИОНЕРНОЕ ОБЩЕСТВО", "АО"),
    ("ИНДИВИДУАЛЬНЫЙ ПРЕДПРИНИМАТЕЛЬ", "ИП"),
)
_NAME_STOP_TOKENS = frozenset(
    {
        "ООО",
        "АО",
        "ПАО",
        "ЗАО",
        "ОАО",
        "НАО",
        "ИП",
        "ОБЩЕСТВО",
        "ОТВЕТСТВЕННОСТЬЮ",
        "ОГРАНИЧЕННОЙ",
        "АКЦИОНЕРНОЕ",
        "ПУБЛИЧНОЕ",
        "НЕПУБЛИЧНОЕ",
        "КОМПАНИЯ",
        "ОРГАНИЗАЦИЯ",
    }
)
_ADDRESS_STOP_TOKENS = frozenset(
    {
        "РОССИЯ",
        "РФ",
        "РОССИЙСКАЯ",
        "ФЕДЕРАЦИЯ",
        "ОБЛ",
        "ОБЛАСТЬ",
        "КРАЙ",
        "РЕСП",
        "РЕСПУБЛИКА",
        "Г",
        "ГОРОД",
        "УЛ",
        "УЛИЦА",
        "Д",
        "ДОМ",
        "КОРП",
        "КОРПУС",
        "СТР",
        "СТРОЕНИЕ",
        "ЛИТ",
        "ЛИТЕРА",
        "КВ",
        "КВАРТИРА",
        "ПОМ",
        "ПОМЕЩЕНИЕ",
        "ОФ",
        "ОФИС",
    }
)


@dataclass(frozen=True)
class OrgIdentity:
    name: str | None = None
    short_name: str | None = None
    address: str | None = None
    ogrn: str | None = None

    @property
    def is_branch(self) -> bool:
        return _text_has_branch_marker(self.name or "")


def _text_has_branch_marker(text: str) -> bool:
    lower = (text or "").lower()
    if any(marker in lower for marker in BRANCH_MARKERS):
        return True
    return bool(BRANCH_EXTRA_RE.search(lower))


def _identity_name_aliases(identity: OrgIdentity) -> list[str]:
    names: list[str] = []
    for raw in (identity.short_name, identity.name):
        value = (raw or "").strip()
        if value and value not in names:
            names.append(value)
    for raw in list(names):
        for quoted in re.findall(r'[«"]([^»"]+)[»"]', raw):
            piece = quoted.strip()
            if piece and piece not in names:
                names.append(piece)
    return names


def _normalize_company_name(name: str | None) -> str:
    if not name:
        return ""
    result = str(name).upper().strip()
    result = re.sub(r"[«»\"'`]", "", result)
    for full, short in LEGAL_FORM_NORMALIZERS:
        if result.startswith(full):
            result = f"{short} {result[len(full):].strip()}"
            break
    result = re.sub(r"[^\w\s]", " ", result, flags=re.UNICODE)
    result = re.sub(r"\s+", " ", result).strip()
    return result


def _name_tokens(name: str | None) -> set[str]:
    norm = _normalize_company_name(name)
    return {token for token in norm.split() if len(token) > 1 and token not in _NAME_STOP_TOKENS}


def _normalize_address(address: str | None) -> str:
    if not address:
        return ""
    result = str(address).upper().strip()
    result = re.sub(r"[^\w\s]", " ", result, flags=re.UNICODE)
    result = re.sub(r"\b\d{6}\b", " ", result)
    result = re.sub(r"\s+", " ", result).strip()
    return result


def _address_tokens(address: str | None) -> set[str]:
    norm = _normalize_address(address)
    return {
        token
        for token in norm.split()
        if len(token) > 2 and token not in _ADDRESS_STOP_TOKENS and not token.isdigit()
    }


def _candidate_display_name(item: dict) -> str:
    for key in ("parsedName", "linkText"):
        value = str(item.get(key) or "").strip()
        if value:
            return value
    preview = str(item.get("preview") or "").strip()
    return preview.split("\n", 1)[0][:120]


def _name_match_score(target_name: str | None, candidate_name: str, candidate_text: str) -> tuple[int, list[str]]:
    target_norm = _normalize_company_name(target_name)
    if not target_norm:
        return 0, []

    reasons: list[str] = []
    score = 0
    names_to_check = [candidate_name, candidate_text.split("\n", 1)[0]]
    for raw_name in names_to_check:
        cand_norm = _normalize_company_name(raw_name)
        if not cand_norm:
            continue
        if cand_norm == target_norm:
            return 55, ["name:exact"]
        if target_norm in cand_norm or cand_norm in target_norm:
            score = max(score, 42)
            reasons.append("name:contains")
        target_tokens = _name_tokens(target_name)
        cand_tokens = _name_tokens(raw_name) or _name_tokens(candidate_text)
        if target_tokens and cand_tokens:
            overlap = target_tokens & cand_tokens
            ratio = len(overlap) / max(len(target_tokens), 1)
            if ratio >= 0.95 and len(overlap) >= 2:
                score = max(score, 38)
                reasons.append(f"name:tokens:{len(overlap)}")
            elif ratio >= 0.7 and len(overlap) >= 2:
                score = max(score, 24)
                reasons.append(f"name:partial:{len(overlap)}")
    return score, reasons


def _identity_name_match_score(
    identity: OrgIdentity, candidate_name: str, candidate_text: str
) -> tuple[int, list[str]]:
    aliases = _identity_name_aliases(identity)
    if not aliases and identity.name:
        aliases = [identity.name]
    best = 0
    reasons: list[str] = []
    for target in aliases:
        score, part = _name_match_score(target, candidate_name, candidate_text)
        if score > best:
            best, reasons = score, part
    return best, reasons


def _region_conflict_penalty(identity: OrgIdentity, candidate_text: str) -> tuple[int, list[str]]:
    target = _normalize_address(identity.address or "")
    cand = _normalize_address(candidate_text)
    if not target or not cand:
        return 0, []
    target_compact = target.replace(" ", "")
    if "САНКТПЕТЕРБУРГ" in target_compact or target_compact.startswith("СПБ"):
        if any(marker in cand for marker in ("КАРЕЛ", "ПЕТРОЗАВОДСК", "КОНДОПОГА", "СУНА", "СОРТАВАЛА")):
            return -60, ["region:conflict"]
    if "МОСКВА" in target_compact and "САНКТПЕТЕРБУРГ" in cand:
        return -40, ["region:conflict"]
    return 0, []


def _address_match_score(target_address: str | None, candidate_text: str) -> tuple[int, list[str]]:
    target_tokens = _address_tokens(target_address)
    if not target_tokens:
        return 0, []

    cand_norm = _normalize_address(candidate_text)
    cand_tokens = _address_tokens(candidate_text)
    if not cand_tokens:
        return 0, []

    overlap = target_tokens & cand_tokens
    reasons: list[str] = []
    score = 0
    if overlap:
        ratio = len(overlap) / max(len(target_tokens), 1)
        token_score = int(min(28, ratio * 28))
        score += token_score
        reasons.append(f"address:tokens:{len(overlap)}")

    for marker, bonus, label in (
        ("САНКТ ПЕТЕРБУРГ", 12, "city:spb"),
        ("МОСКВА", 12, "city:msk"),
        ("СЕВАСТОПОЛЬ", 10, "city:sev"),
    ):
        if marker.replace(" ", "") in cand_norm.replace(" ", "") and marker.replace(" ", "") in _normalize_address(
            target_address
        ).replace(" ", ""):
            score += bonus
            reasons.append(label)

    street_match = re.search(r"(?:УЛ|УЛИЦА)\s+([А-ЯЁ0-9\-]+)", _normalize_address(target_address))
    if street_match:
        street = street_match.group(1)
        if street in cand_norm:
            score += 12
            reasons.append(f"street:{street[:12]}")

    building_match = re.search(r"(?:ДОМ|Д)\s*(\d+[А-ЯЁ0-9\-]*)", _normalize_address(target_address))
    if building_match:
        building = building_match.group(1)
        if re.search(rf"\b{re.escape(building)}\b", cand_norm):
            score += 8
            reasons.append(f"building:{building}")

    return score, reasons


def _ogrn_digits(value: str | None) -> str:
    return re.sub(r"\D", "", value or "")


def _ogrn_match_score(target_ogrn: str | None, candidate: dict) -> tuple[int, list[str]]:
    target = _ogrn_digits(target_ogrn)
    if len(target) < 13:
        return 0, []

    parsed = _ogrn_digits(str(candidate.get("parsedOgrn") or ""))
    if parsed and parsed == target:
        return 45, ["ogrn:exact-json"]

    combined = str(candidate.get("preview") or "") + " " + str(candidate.get("parsedName") or "")
    if target in re.sub(r"\D", "", combined):
        return 40, ["ogrn:exact-text"]

    return 0, []


def _branch_adjustment(identity: OrgIdentity, candidate: dict) -> tuple[int, list[str]]:
    text = " ".join(
        str(candidate.get(key) or "")
        for key in ("parsedName", "linkText", "preview")
    )
    candidate_is_branch = _text_has_branch_marker(text)
    if identity.is_branch:
        if candidate_is_branch:
            return 8, ["branch:expected"]
        return -6, ["branch:expected-miss"]
    if candidate_is_branch:
        return -80, ["branch:penalty"]
    return 4, ["branch:main"]


def _score_candidate(item: dict, identity: OrgIdentity) -> tuple[int, list[str]]:
    score = int(item.get("score") or 0)
    reasons = [f"base:{score}"]
    candidate_name = _candidate_display_name(item)
    candidate_text = str(item.get("preview") or "")

    name_score, name_reasons = _identity_name_match_score(identity, candidate_name, candidate_text)
    if name_score:
        score += name_score
        reasons.extend(name_reasons)

    addr_score, addr_reasons = _address_match_score(identity.address, candidate_text)
    if addr_score:
        score += addr_score
        reasons.extend(addr_reasons)

    ogrn_score, ogrn_reasons = _ogrn_match_score(identity.ogrn, item)
    if ogrn_score:
        score += ogrn_score
        reasons.extend(ogrn_reasons)

    region_score, region_reasons = _region_conflict_penalty(identity, candidate_text)
    if region_score:
        score += region_score
        reasons.extend(region_reasons)

    branch_score, branch_reasons = _branch_adjustment(identity, item)
    score += branch_score
    reasons.extend(branch_reasons)

    return score, reasons


async def _resolve_org_identity(
    inn: str,
    *,
    company_name: str | None = None,
    company_short_name: str | None = None,
    company_address: str | None = None,
    company_ogrn: str | None = None,
) -> OrgIdentity:
    name = (company_name or "").strip() or None
    short_name = (company_short_name or "").strip() or None
    address = (company_address or "").strip() or None
    ogrn = (company_ogrn or "").strip() or None
    if name and address and ogrn:
        return OrgIdentity(name=name, short_name=short_name, address=address, ogrn=ogrn)

    try:
        from services.description import shorten_company_name
        from services.egrul import EgrulError, search_egrul
        from services.egrul_parse import parse_egrul_pdf
        from services.egrul import download_egrul_pdf
    except ImportError:
        return OrgIdentity(name=name, short_name=short_name, address=address, ogrn=ogrn)

    if not name or not address or not ogrn or not short_name:
        try:
            pdf = await download_egrul_pdf(inn)
            parsed = parse_egrul_pdf(pdf)
            name = name or (parsed.get("name") or "").strip() or None
            short_name = short_name or (parsed.get("short_name") or "").strip() or None
            address = address or (parsed.get("address") or "").strip() or None
            ogrn = ogrn or (parsed.get("ogrn") or "").strip() or None
        except Exception as exc:
            logger.info("Casebook EGRUL pdf identity fallback inn=%s: %s", inn, exc)

    if not name or not address or not ogrn:
        try:
            rows = await search_egrul(inn)
            if rows:
                row = rows[0]
                name = name or (row.name or "").strip() or None
                address = address or (row.address or "").strip() or None
                ogrn = ogrn or (row.ogrn or "").strip() or None
        except EgrulError as exc:
            logger.info("Casebook EGRUL search identity fallback inn=%s: %s", inn, exc)
        except Exception as exc:
            logger.info("Casebook EGRUL search identity error inn=%s: %s", inn, exc)

    if not short_name and name:
        try:
            short_name = shorten_company_name(name)
        except Exception:
            short_name = None

    return OrgIdentity(name=name, short_name=short_name, address=address, ogrn=ogrn)


class CasebookError(Exception):
    pass


def casebook_configured() -> bool:
    login = os.getenv("CASEBOOK_EMAIL", "").strip() or os.getenv("CASEBOOK_LOGIN", "").strip()
    password = os.getenv("CASEBOOK_PASSWORD", "").strip()
    return bool(login and password)


def _casebook_credentials() -> tuple[str, str]:
    login = os.getenv("CASEBOOK_EMAIL", "").strip() or os.getenv("CASEBOOK_LOGIN", "").strip()
    password = os.getenv("CASEBOOK_PASSWORD", "").strip()
    if not login or not password:
        raise CasebookError("Задайте CASEBOOK_EMAIL (или CASEBOOK_LOGIN) и CASEBOOK_PASSWORD в .env")
    return login, password


def _playwright_available() -> bool:
    try:
        import playwright  # noqa: F401

        return True
    except ImportError:
        return False


async def _launch_browser(playwright):
    launch_kwargs = {
        "headless": True,
        "args": ["--disable-blink-features=AutomationControlled"],
    }
    for channel in ("chrome", "chromium"):
        try:
            if channel == "chrome":
                return await playwright.chromium.launch(channel="chrome", **launch_kwargs)
            return await playwright.chromium.launch(**launch_kwargs)
        except Exception as exc:
            logger.info("Playwright launch via %s failed: %s", channel, exc)
    raise CasebookError(
        "Не удалось запустить браузер. Выполните: .venv/bin/playwright install chromium"
    )


def _abs_url(href: str) -> str:
    return href if href.startswith("http") else f"{CASEBOOK_SITE}{href}"


def _company_section_urls(company_id: str, section: str, subsection: str | None = None) -> list[str]:
    base = f"{CASEBOOK_SITE}/card/company"
    urls = [
        f"{base}/{section}/{company_id}",
        f"{base}/{company_id}/{section}",
    ]
    if subsection:
        urls.extend(
            [
                f"{base}/{section}/{subsection}/{company_id}",
                f"{base}/{subsection}/{company_id}",
                f"{base}/{company_id}/{section}/{subsection}",
                f"{base}/{company_id}/{subsection}",
            ]
        )
    return urls


def _url_on_company_card(page, company_id: str) -> bool:
    url = page.url.lower()
    if re.search(r"/app/feed|/logon|/login", url):
        return False
    return company_id in page.url


async def _goto_company_section(page, url: str, company_id: str, ready_check) -> bool:
    try:
        await page.goto(url, wait_until="load", timeout=45000)
        await _pause(page, 2000)
        if not _url_on_company_card(page, company_id):
            logger.info("Casebook redirect away from company card url=%s target=%s", page.url, url)
            return False
        if await ready_check(page, 10000):
            if _url_on_company_card(page, company_id):
                return True
    except Exception as exc:
        logger.info("Casebook goto failed target=%s: %s", url, exc)
    return False


def _registry_ready_fn(company_id: str):
    async def check(page, timeout_ms: int = 10000) -> bool:
        return await _reestr_menu_ready(page, company_id, timeout_ms)

    return check


def _enforcement_ready_fn(company_id: str):
    async def check(page, timeout_ms: int = 10000) -> bool:
        return await _enforcement_ui_ready(page, company_id, timeout_ms)

    return check


def _session_usable() -> bool:
    if not SESSION_FILE.exists():
        return False
    return time.time() - SESSION_FILE.stat().st_mtime < SESSION_MAX_AGE_SEC


async def _pause(page, ms: int = 350) -> None:
    await page.wait_for_timeout(ms)


async def _reset_browser() -> None:
    global _playwright_ref, _browser_ref
    if _browser_ref is not None:
        try:
            await _browser_ref.close()
        except Exception:
            pass
    _browser_ref = None
    if _playwright_ref is not None:
        try:
            await _playwright_ref.stop()
        except Exception:
            pass
    _playwright_ref = None


async def _ensure_browser(playwright):
    global _browser_ref
    if _browser_ref is not None:
        try:
            if _browser_ref.is_connected():
                return _browser_ref
        except Exception:
            pass
        await _reset_browser()
    _browser_ref = await _launch_browser(playwright)
    return _browser_ref


async def _create_authenticated_context(browser, login: str, password: str):
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    storage = str(SESSION_FILE) if _session_usable() else None
    context = await browser.new_context(
        viewport={"width": 1440, "height": 1200},
        locale="ru-RU",
        storage_state=storage,
    )
    page = await context.new_page()
    try:
        await _ensure_feed_page(page, login, password)
    except CasebookError:
        await page.close()
        await context.close()
        context = await browser.new_context(
            viewport={"width": 1440, "height": 1200},
            locale="ru-RU",
        )
        page = await context.new_page()
        await _login(page, login, password)
        await context.storage_state(path=str(SESSION_FILE))
        await _ensure_feed_page(page, login, password)
    return context, page


async def _get_search_input(page, timeout_ms: int = 12000):
    locators = (
        page.get_by_placeholder(re.compile(r"поиск", re.I)),
        page.get_by_role("searchbox"),
        page.locator('input[placeholder*="оиск" i], input[placeholder*="Search" i]'),
        page.locator('input[type="search"]'),
        page.locator('input[aria-label*="оиск" i], input[aria-label*="Поиск" i]'),
        page.locator('[class*="search" i] input, [class*="Search" i] input'),
        page.locator("header input[type='text'], header input:not([type='hidden'])"),
    )
    deadline = time.time() + timeout_ms / 1000
    while time.time() < deadline:
        for locator in locators:
            try:
                if await locator.count() == 0:
                    continue
                item = locator.first
                if await item.is_visible():
                    return item
            except Exception:
                continue
        await _pause(page, 400)
    return None


async def _ensure_feed_page(
    page,
    login: str | None = None,
    password: str | None = None,
    *,
    allow_relogin: bool = True,
) -> None:
    if not re.search(r"/app/feed", page.url, re.I):
        await page.goto(CASEBOOK_FEED_URL, wait_until="domcontentloaded", timeout=45000)
        await _pause(page, 1000)

    if await _get_search_input(page, timeout_ms=6000):
        return

    if re.search(r"/logon", page.url, re.I):
        if login and password:
            await _login(page, login, password)
            if await _get_search_input(page, timeout_ms=12000):
                return
        raise CasebookError("Сессия Casebook истекла — не удалось открыть ленту.")

    await page.goto(CASEBOOK_FEED_URL, wait_until="load", timeout=45000)
    await _pause(page, 1200)
    if await _get_search_input(page, timeout_ms=8000):
        return

    if login and password and allow_relogin:
        logger.info("Casebook feed without search input, re-login url=%s", page.url)
        SESSION_FILE.unlink(missing_ok=True)
        await _login(page, login, password)
        if await _get_search_input(page, timeout_ms=12000):
            return

    raise CasebookError("Не найдено поле поиска на главной Casebook.")


async def _submit_login(page, password_field) -> None:
    await password_field.press("Enter")
    await _pause(page, 800)
    if not re.search(r"/logon", page.url, re.I):
        return

    candidates = [
        page.get_by_role("button", name=re.compile(r"войти", re.I)),
        page.locator("button").filter(has_text=re.compile(r"войти", re.I)),
        page.get_by_text(re.compile(r"^войти$", re.I)),
        page.locator('[role="button"]').filter(has_text=re.compile(r"войти", re.I)),
        page.locator('button[type="submit"], input[type="submit"]'),
        page.locator("form button"),
    ]
    for locator in candidates:
        count = await locator.count()
        if not count:
            continue
        for i in range(min(count, 5)):
            item = locator.nth(i)
            try:
                if not await item.is_visible():
                    continue
                await item.click(timeout=4000)
                await _pause(page, 800)
                if not re.search(r"/logon", page.url, re.I):
                    return
            except Exception:
                continue

    form = page.locator("form").first
    if await form.count():
        try:
            await form.evaluate("form => form.submit()")
            await _pause(page, 800)
            if not re.search(r"/logon", page.url, re.I):
                return
        except Exception:
            pass

    raise CasebookError("Не найдена кнопка входа на странице Casebook.")


async def _login(page, email: str, password: str) -> None:
    await page.goto(CASEBOOK_LOGON_URL, wait_until="domcontentloaded", timeout=45000)
    await _pause(page, 300)

    login_input = page.get_by_label(re.compile(r"логин", re.I))
    if not await login_input.count():
        login_input = page.locator(
            'input[name="login"], input[name="username"], input[name="userName"], '
            'input[autocomplete="username"], form input[type="text"]'
        )
    password_input = page.get_by_label(re.compile(r"пароль", re.I))
    if not await password_input.count():
        password_input = page.locator('input[type="password"]')

    login_field = login_input.first
    password_field = password_input.first
    await login_field.wait_for(state="visible", timeout=45000)
    await password_field.wait_for(state="visible", timeout=45000)
    await login_field.fill(email)
    await password_field.fill(password)
    await _submit_login(page, password_field)

    try:
        await page.wait_for_url(re.compile(r".*casebook\.ru/(app|login).*"), timeout=45000)
    except Exception as exc:
        if re.search(r"/logon", page.url, re.I):
            raise CasebookError(
                "Не удалось войти в Casebook — проверьте CASEBOOK_EMAIL и CASEBOOK_PASSWORD в .env"
            ) from exc
        logger.info("Casebook login redirect non-standard url=%s", page.url)
    await page.goto(CASEBOOK_FEED_URL, wait_until="load", timeout=45000)
    await _pause(page, 1200)
    await _ensure_feed_page(page, email, password, allow_relogin=False)


def _inn_digits(inn: str) -> str:
    return re.sub(r"\D", "", normalize_inn(inn) or inn or "")


async def _verify_company_card(page, inn: str, identity: OrgIdentity) -> bool:
    inn_digits = _inn_digits(inn)
    try:
        body_text = str(await page.evaluate("() => document.body?.innerText || ''"))
    except Exception:
        return False

    body_digits = re.sub(r"\D", "", body_text)
    if inn_digits not in body_digits:
        return False

    head = body_text[:1200]
    if not identity.is_branch and _text_has_branch_marker(head):
        logger.info("Casebook verify rejected branch marker inn=%s url=%s", inn, page.url)
        return False

    target_ogrn = _ogrn_digits(identity.ogrn)
    if len(target_ogrn) >= 13 and target_ogrn in body_digits:
        return True

    for alias in _identity_name_aliases(identity):
        alias_norm = _normalize_company_name(alias)
        if alias_norm and alias_norm in _normalize_company_name(body_text):
            return True
        alias_tokens = _name_tokens(alias)
        if alias_tokens:
            body_tokens = set(re.findall(r"\w+", body_text.upper(), flags=re.UNICODE))
            overlap = alias_tokens & body_tokens
            if len(overlap) >= min(2, len(alias_tokens)):
                return True

    address_tokens = _address_tokens(identity.address)
    if address_tokens:
        body_addr_tokens = _address_tokens(body_text)
        if len(address_tokens & body_addr_tokens) >= 2:
            return True

    if not identity.name and not identity.address and not identity.ogrn:
        return True
    return False


async def _open_company_by_ogrn(page, inn: str, identity: OrgIdentity) -> str | None:
    ogrn = _ogrn_digits(identity.ogrn)
    if len(ogrn) < 13:
        return None

    logger.info("Casebook direct OGRN start inn=%s ogrn=%s", inn, ogrn)
    card_url = f"{CASEBOOK_SITE}/card/company/{ogrn}"
    try:
        await page.goto(card_url, wait_until="load", timeout=60000)
        await _wait_for_company_card(page, ogrn)
        if await _verify_company_card(page, inn, identity):
            logger.info("Casebook open by OGRN inn=%s ogrn=%s url=%s", inn, ogrn, page.url)
            return card_url
        logger.info(
            "Casebook direct OGRN verify failed inn=%s ogrn=%s url=%s",
            inn,
            ogrn,
            page.url,
        )
    except Exception as exc:
        logger.info("Casebook direct OGRN failed inn=%s ogrn=%s: %s", inn, ogrn, exc)
    return None


async def _wait_search_results(page, inn: str, timeout_ms: int = 18000) -> None:
    inn_digits = _inn_digits(inn)
    try:
        await page.wait_for_function(
            """(innDigits) => {
                const norm = (s) => (s || '').replace(/\\D/g, '');
                const body = norm(document.body?.innerText || '');
                if (!body.includes(innDigits)) return false;
                return !!document.querySelector('a[href*="/card/company/"]');
            }""",
            inn_digits,
            timeout=timeout_ms,
        )
    except Exception:
        logger.info("Casebook search results slow inn=%s url=%s", inn, page.url)
    await _pause(page, 1000)


async def _collect_company_candidates(
    page, inn: str, *, identity: OrgIdentity | None = None
) -> list[dict]:
    inn_digits = _inn_digits(inn)
    target_ogrn = _ogrn_digits(identity.ogrn if identity else None)
    try:
        raw = await asyncio.wait_for(
            page.evaluate(
                """({innDigits, targetOgrn, orgMarkers, personMarkers, maxLinks, maxTextLen}) => {
            const normDigits = (s) => (s || '').replace(/\\D/g, '');
            const out = [];
            const seen = new Set();
            const maxLinksNum = maxLinks || 80;
            const textCap = maxTextLen || 500;
            for (const link of document.querySelectorAll('a[href*="/card/company/"]')) {
                if (seen.size >= maxLinksNum) break;
                const href = (link.href || link.getAttribute('href') || '').split('?')[0];
                if (!href || seen.has(href)) continue;
                seen.add(href);
                const dataItem = link.getAttribute('data-item') || '';
                const chunks = [dataItem, (link.innerText || '').trim()];
                let el = link.parentElement;
                for (let depth = 0; depth < 4 && el; depth++) {
                    const text = (el.innerText || '').trim();
                    if (text) chunks.push(text.slice(0, 180));
                    el = el.parentElement;
                }
                let combined = chunks.join(' ');
                if (combined.length > textCap) combined = combined.slice(0, textCap);
                if (!normDigits(combined).includes(innDigits)) continue;
                let score = 0;
                const compact = dataItem.replace(/\\s+/g, '');
                if (compact.includes('"type":"Side"') || compact.includes('"type": "Side"')) score += 8;
                if (href.includes('/card/company/')) score += 4;
                if (/\\d{13}/.test(combined)) score += 3;
                const lower = combined.toLowerCase();
                if (orgMarkers.some((m) => lower.includes(m))) score += 2;
                if (personMarkers.some((m) => lower.includes(m)) && !lower.includes('огрн')) score -= 5;
                let parsedName = '';
                let parsedOgrn = '';
                let parsedAddress = '';
                let parsedInn = '';
                try {
                    const parsed = JSON.parse(dataItem);
                    parsedName = parsed.name || parsed.fullName || parsed.shortName || parsed.title || '';
                    parsedOgrn = String(parsed.ogrn || parsed.OGRN || '');
                    parsedAddress = parsed.address || parsed.legalAddress || parsed.location || '';
                    parsedInn = normDigits(parsed.inn || parsed.INN || '');
                    if (normDigits(parsed.inn) === innDigits) score += 12;
                    const ptype = String(parsed.type || '').toLowerCase();
                    if (ptype === 'side' || ptype === 'organization' || ptype === 'company') score += 6;
                    if (parsed.ogrn && String(parsed.ogrn).length >= 13) score += 4;
                    if (targetOgrn && normDigits(parsedOgrn) === targetOgrn) score += 50;
                } catch (_) {}
                if (targetOgrn && parsedOgrn && normDigits(parsedOgrn) !== targetOgrn) {
                    score -= 20;
                }
                if (/фл\\s*[\"«]|каскад\\s+\\w+\\s+гэс/i.test(combined)) score -= 40;
                out.push({
                    href,
                    score,
                    preview: combined.slice(0, 220),
                    parsedName,
                    parsedOgrn,
                    parsedAddress,
                    parsedInn,
                    linkText: (link.innerText || '').trim().slice(0, 160),
                });
            }
            return out;
        }""",
                {
                    "innDigits": inn_digits,
                    "targetOgrn": target_ogrn if len(target_ogrn) >= 13 else "",
                    "orgMarkers": list(ORG_MARKERS),
                    "personMarkers": list(PERSON_MARKERS),
                    "maxLinks": 80,
                    "maxTextLen": 500,
                },
            ),
            timeout=15.0,
        )
    except (asyncio.TimeoutError, TimeoutError):
        logger.info("Casebook collect candidates timeout inn=%s url=%s", inn, page.url)
        return []
    return raw if isinstance(raw, list) else []


async def _search_inn(page, inn: str, login: str | None = None, password: str | None = None) -> None:
    logger.info("Casebook search start inn=%s", inn)
    await _ensure_feed_page(page, login, password)
    search = await _get_search_input(page, timeout_ms=12000)
    if not search:
        raise CasebookError("Не найдено поле поиска на главной Casebook.")
    inn = normalize_inn(inn)
    await search.click(click_count=3)
    await search.press("Backspace")
    await search.press_sequentially(inn, delay=40)
    await search.press("Enter")
    await _wait_search_results(page, inn)


async def _pick_organization(page, inn: str, identity: OrgIdentity) -> str:
    logger.info("Casebook pick start inn=%s ogrn=%s", inn, identity.ogrn)
    inn = normalize_inn(inn)
    candidates = await _collect_company_candidates(page, inn, identity=identity)
    if not candidates:
        await _pause(page, 1500)
        candidates = await _collect_company_candidates(page, inn, identity=identity)

    target_ogrn = _ogrn_digits(identity.ogrn)
    if len(target_ogrn) >= 13:
        ogrn_matches = [
            item
            for item in candidates
            if _ogrn_digits(str(item.get("parsedOgrn") or "")) == target_ogrn
            or str(item.get("href") or "").rstrip("/").endswith(f"/{target_ogrn}")
        ]
        if ogrn_matches:
            logger.info(
                "Casebook pick OGRN filter inn=%s ogrn=%s matches=%s total=%s",
                inn,
                target_ogrn,
                len(ogrn_matches),
                len(candidates),
            )
            candidates = ogrn_matches
        elif candidates:
            logger.info(
                "Casebook pick OGRN no exact match inn=%s ogrn=%s total=%s",
                inn,
                target_ogrn,
                len(candidates),
            )
            raise CasebookError(
                f"В Casebook не найдена организация с ОГРН {target_ogrn}. Откройте карточку вручную."
            )

    scored: list[dict] = []
    for item in candidates:
        href = str(item.get("href") or "").split("?")[0]
        if not href:
            continue
        total, reasons = _score_candidate(item, identity)
        scored.append(
            {
                "href": href,
                "total": total,
                "base": int(item.get("score") or 0),
                "reasons": reasons,
                "preview": str(item.get("preview") or "")[:120],
                "name": _candidate_display_name(item)[:80],
            }
        )

    if not scored:
        link_count = await page.locator('a[href*="/card/company/"]').count()
        logger.info(
            "Casebook pick failed inn=%s links=%s url=%s identity=%s",
            inn,
            link_count,
            page.url,
            {
                "name": (identity.name or "")[:60],
                "address": (identity.address or "")[:60],
                "ogrn": identity.ogrn,
                "is_branch": identity.is_branch,
            },
        )
        raise CasebookError("Организация по ИНН не найдена в результатах Casebook.")

    scored.sort(key=lambda row: row["total"], reverse=True)
    best = scored[0]
    if len(scored) > 1:
        logger.info(
            "Casebook pick candidates inn=%s count=%s identity_name=%s top=%s winner=%s reasons=%s",
            inn,
            len(scored),
            (identity.name or "")[:80],
            [
                {
                    "score": row["total"],
                    "base": row["base"],
                    "name": row["name"],
                    "reasons": row["reasons"][:6],
                }
                for row in scored[:5]
            ],
            best["name"],
            best["reasons"],
        )

    if best["total"] < 1:
        link_count = await page.locator('a[href*="/card/company/"]').count()
        logger.info(
            "Casebook pick low score inn=%s links=%s url=%s preview=%s",
            inn,
            link_count,
            page.url,
            best["preview"][:120],
        )
        raise CasebookError("Организация по ИНН не найдена в результатах Casebook.")

    card_url = _abs_url(best["href"])
    logger.info(
        "Casebook open company card inn=%s url=%s score=%s preview=%s reasons=%s",
        inn,
        card_url,
        best["total"],
        best["preview"][:120],
        best["reasons"],
    )
    await page.goto(card_url, wait_until="load", timeout=60000)
    await _wait_for_company_card(page, card_url.rstrip("/").split("/")[-1])
    return card_url


async def _wait_for_company_card(page, company_id: str, timeout_ms: int = 25000) -> None:
    try:
        await page.wait_for_function(
            """(companyId) => {
                const text = document.body?.innerText || '';
                if (/\\bДела\\b|\\bРеестры\\b|Арбитраж|тип участия|вид спора|исполнительн/i.test(text)) return true;
                for (const el of document.querySelectorAll('a[href], button, [role=tab]')) {
                    const label = (el.innerText || '').replace(/\\s+/g, ' ').trim();
                    const href = el.href || '';
                    if (label === 'Дела' || label === 'Реестры') return true;
                    if (href.includes(companyId) && /dispute|case|arbitr|delo/i.test(href + label)) return true;
                }
                return document.querySelectorAll('nav a, aside a, [class*="sidebar" i] a').length >= 2;
            }""",
            company_id,
            timeout=timeout_ms,
        )
    except Exception:
        logger.info("Casebook company card slow load url=%s", page.url)
    await _pause(page, 1200)


async def _cases_list_ui_ready(page, timeout_ms: int = 12000) -> bool:
    try:
        await page.wait_for_function(
            """() => {
                const text = document.body?.innerText || '';
                const hasType = /тип участия/i.test(text);
                const hasSpore = /вид спора/i.test(text);
                const hasFilter = /фильтр/i.test(text);
                const hasList = [...document.querySelectorAll('a,button,[role=tab]')]
                    .some((el) => (el.innerText || '').trim() === 'Список');
                return hasType && hasSpore && (hasFilter || hasList);
            }""",
            timeout=timeout_ms,
        )
        return True
    except Exception:
        return False


async def _find_dela_url(page, company_id: str) -> str | None:
    href = await page.evaluate(
        """(companyId) => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const scopes = ['aside', 'nav', '[class*="sidebar" i]', '[class*="menu" i]'];
            const candidates = [];
            const collect = (root) => {
                for (const el of root.querySelectorAll('a[href], [role=link]')) {
                    const text = norm(el.innerText);
                    const href = el.href || '';
                    if (!href) continue;
                    if (text === 'Дела') candidates.push(href);
                    if (href.includes(companyId) && /dispute|case|arbitr|delo|litig/i.test(href + ' ' + text)) {
                        candidates.push(href);
                    }
                }
            };
            for (const sel of scopes) {
                for (const root of document.querySelectorAll(sel)) collect(root);
            }
            const scored = candidates.map((href) => {
                let score = 0;
                if (/\\/card\\/company\\/cases\\//i.test(href)) score += 10;
                if (/\\/disputes\\/list|\\/cases\\/list/i.test(href)) score += 8;
                if (/\\/disputes|\\/cases/i.test(href)) score += 5;
                if (href.includes(companyId)) score += 3;
                return {href, score};
            }).sort((a, b) => b.score - a.score);
            return scored[0]?.href || null;
        }""",
        company_id,
    )
    return href or None


async def _open_dela_section(page, company_id: str, company_card_url: str) -> bool:
    dela_url = await _find_dela_url(page, company_id)
    if dela_url:
        try:
            await page.goto(dela_url, wait_until="load", timeout=45000)
            await _pause(page, 1500)
            if await _cases_list_ui_ready(page, 8000):
                return True
        except Exception as exc:
            logger.info("Casebook goto Дела href failed: %s", exc)

    for scope in (
        page.locator("aside, nav").get_by_text(re.compile(r"^Дела$", re.I)),
        page.locator('[class*="sidebar" i], [class*="menu" i]').get_by_text(
            re.compile(r"^Дела$", re.I)
        ),
        page.get_by_role("link", name=re.compile(r"^Дела$", re.I)),
        page.get_by_role("tab", name=re.compile(r"^Дела$", re.I)),
    ):
        try:
            if await scope.count() == 0:
                continue
            item = scope.first
            await item.scroll_into_view_if_needed(timeout=5000)
            try:
                await item.click(timeout=5000)
            except Exception:
                await item.click(timeout=5000, force=True)
            await _pause(page, 4000)
            if await _cases_list_ui_ready(page, 10000):
                return True
        except Exception:
            continue

    sidebar = await _click_sidebar_section(page, "Дела")
    if sidebar.get("ok"):
        await _pause(page, 4000)
        if await _cases_list_ui_ready(page, 10000):
            return True

    for suffix in (
        f"/cases/{company_id}",
        "/disputes/list",
        "/disputes/arbitrage/list",
        "/disputes/arbitrage",
        "/disputes",
        "/cases/list",
        "/cases/arbitrage",
        "/cases",
    ):
        url = (
            f"{CASEBOOK_SITE}/card/company{suffix}"
            if suffix.startswith("/cases/")
            else f"{company_card_url.rstrip('/')}{suffix}"
        )
        try:
            await page.goto(url, wait_until="load", timeout=45000)
            await _pause(page, 1500)
            if await _cases_list_ui_ready(page, 8000):
                logger.info("Casebook cases section url=%s", url)
                return True
        except Exception:
            continue
    return False


async def _page_looks_like_cases(page) -> bool:
    return await _cases_list_ui_ready(page, timeout_ms=1500)


async def _click_sidebar_section(
    page,
    title: str,
    *,
    pattern: str | None = None,
    skip_app_links: bool = False,
) -> dict:
    return await page.evaluate(
        """({title, pattern, skipAppLinks}) => {
            const scopes = [
                'aside', 'nav',
                '[class*="sidebar" i]', '[class*="Sidebar" i]',
                '[class*="menu" i]', '[class*="Menu" i]',
                '[class*="navigation" i]'
            ];
            const re = pattern ? new RegExp(pattern, 'i') : null;
            const isGlobalAppLink = (href) =>
                /\\/app\\//i.test(href) && !/\\/card\\/company\\//i.test(href);
            const tryClick = (root) => {
                for (const el of root.querySelectorAll('a,button,[role=tab],li,span,div')) {
                    const text = (el.innerText || '').replace(/\\s+/g, ' ').trim();
                    if (!text || text.length > 60) continue;
                    const matched = re ? re.test(text) : text === title;
                    if (!matched) continue;
                    const target = el.closest('a,button,[role=tab]') || el;
                    const href = target.href || target.closest('a')?.href || '';
                    if (skipAppLinks && href && isGlobalAppLink(href)) continue;
                    target.scrollIntoView({block: 'center'});
                    target.click();
                    return {ok: true, text, href};
                }
                return null;
            };
            for (const sel of scopes) {
                for (const root of document.querySelectorAll(sel)) {
                    const res = tryClick(root);
                    if (res) return res;
                }
            }
            return {ok: false};
        }""",
        {"title": title, "pattern": pattern, "skipAppLinks": skip_app_links},
    )


async def _list_sidebar_labels(page) -> list[str]:
    labels = await page.evaluate(
        """() => {
            const out = [];
            for (const root of document.querySelectorAll('aside, nav, [class*="sidebar" i], [class*="menu" i]')) {
                for (const el of root.querySelectorAll('a,button,[role=tab],li,span,div')) {
                    const text = (el.innerText || '').replace(/\\s+/g, ' ').trim();
                    if (text && text.length < 50) out.push(text);
                }
            }
            return [...new Set(out)];
        }"""
    )
    return labels or []


def _registry_click_ok(page, company_id: str) -> bool:
    if re.search(r"/app/feed|/logon|/login", page.url, re.I):
        return False
    return company_id in page.url


async def _click_subtab_list(page) -> None:
    for locator in (
        page.get_by_role("tab", name=re.compile(r"^Список$", re.I)),
        page.get_by_text(re.compile(r"^Список$", re.I)),
    ):
        try:
            if await locator.count() == 0:
                continue
            await locator.first.click(timeout=4000)
            await _pause(page, 1500)
            return
        except Exception:
            continue
    await page.evaluate(
        """() => {
            for (const el of document.querySelectorAll('a,button,[role=tab]')) {
                const text = (el.innerText || '').trim();
                if (text === 'Список') {
                    el.click();
                    return;
                }
            }
        }"""
    )
    await _pause(page, 1500)


async def _open_cases_via_url(page, company_id: str) -> bool:
    url = f"{CASEBOOK_SITE}/card/company/cases/{company_id}"
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        await _pause(page, 1000)
        await _ensure_list_tab(page)
        return await _cases_list_ui_ready(page, 8000)
    except Exception as exc:
        logger.info("Casebook cases url failed: %s", exc)
        return False


async def _open_cases_tab(page, company_card_url: str) -> None:
    company_id = company_card_url.rstrip("/").split("/")[-1]
    if await _open_cases_via_url(page, company_id):
        logger.info("Casebook Дела opened url=%s", page.url)
        return

    card_base = company_card_url.rstrip("/")
    if card_base not in page.url.rstrip("/"):
        await page.goto(company_card_url, wait_until="load", timeout=60000)
    await _wait_for_company_card(page, company_id)

    if not await _open_dela_section(page, company_id, company_card_url):
        await page.goto(company_card_url, wait_until="load", timeout=60000)
        await _wait_for_company_card(page, company_id)
        if not await _open_dela_section(page, company_id, company_card_url):
            raise CasebookError("Не удалось открыть раздел «Дела» в карточке Casebook.")

    logger.info("Casebook Дела opened url=%s", page.url)
    await _ensure_list_tab(page)
    if not await _cases_list_ui_ready(page, 10000):
        raise CasebookError("Раздел «Дела» открыт, но вкладка «Список» с фильтрами не загрузилась.")


_FILTER_OPTIONS = ("Ответчик", "Должник", "В производстве", "Гражданский")
_FILTER_SECTIONS = ("Тип участия", "Статус", "Вид спора")


async def _ensure_list_tab(page) -> None:
    await page.evaluate(
        """() => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            for (const el of document.querySelectorAll('a,button,[role=tab]')) {
                if (norm(el.innerText) === 'Список') {
                    el.click();
                    return;
                }
            }
        }"""
    )
    await _pause(page, 600)


async def _open_filter_panel(page) -> bool:
    result = await page.evaluate(
        """() => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            for (const el of document.querySelectorAll('button,a,[role=button],span,div')) {
                const t = norm(el.innerText);
                if ((/^фильтр/i.test(t) || t === 'Фильтры' || t === 'Все фильтры') && t.length < 30) {
                    el.click();
                    return {opened: true, via: t};
                }
            }
            for (const el of document.querySelectorAll('[class*="filter" i], [data-test*="filter" i]')) {
                if (typeof el.click === 'function') {
                    el.click();
                    return {opened: true, via: 'class'};
                }
            }
            return {opened: false};
        }"""
    )
    await _pause(page, 500)
    return bool(result.get("opened"))


async def _expand_filter_sections(page) -> None:
    for section in _FILTER_SECTIONS:
        await page.evaluate(
            """(sectionName) => {
                const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
                for (const el of document.querySelectorAll('button,div,span,h3,h4,label,[role=button]')) {
                    const t = norm(el.innerText);
                    if (t === sectionName || t.startsWith(sectionName + ' ')) {
                        const box = el.closest('[class*="filter"],[class*="group"],[class*="section"],[class*="accordion"],[class*="panel"]') || el;
                        box.click();
                        return;
                    }
                }
            }""",
            section,
        )
        await _pause(page, 200)


async def _select_filter_option(page, label: str) -> bool:
    for variant in (label, "Гражданские" if label == "Гражданский" else label):
        playwright_ok = False
        try:
            checkbox = page.get_by_role("checkbox", name=re.compile(rf"^{re.escape(variant)}$", re.I))
            if await checkbox.count():
                await checkbox.first.check(timeout=3000)
                playwright_ok = True
        except Exception:
            playwright_ok = False

        js_ok = await page.evaluate(
            """(label) => {
                const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
                const match = (text, label) => {
                    const t = norm(text);
                    return t === label || t.startsWith(label + ' ') || (t.includes(label) && t.length <= label.length + 24);
                };
                const clickTarget = (el) => {
                    if (!el) return false;
                    el.scrollIntoView({block: 'center'});
                    const cb = el.matches?.('input[type=checkbox]') ? el
                        : el.querySelector?.('input[type=checkbox]')
                        || el.closest?.('label')?.querySelector('input[type=checkbox]');
                    if (cb) {
                        if (!cb.checked) cb.click();
                        return true;
                    }
                    if (el.getAttribute?.('role') === 'checkbox') {
                        if (el.getAttribute('aria-checked') !== 'true') el.click();
                        return true;
                    }
                    if (el.getAttribute?.('role') === 'option') {
                        el.click();
                        return true;
                    }
                    el.click();
                    return true;
                };
                for (const labelEl of document.querySelectorAll('label')) {
                    if (match(labelEl.innerText, label)) return clickTarget(labelEl);
                }
                for (const el of document.querySelectorAll('[role=checkbox],[role=option],li,div,span,button')) {
                    if (match(el.innerText, label)) {
                        if (clickTarget(el)) return true;
                    }
                }
                return false;
            }""",
            variant,
        )
        if playwright_ok or js_ok:
            logger.info("Casebook filter set: %s (variant=%s)", label, variant)
            await _pause(page, 250)
            return True
    return False


async def _confirm_filters(page) -> None:
    for locator in (
        page.get_by_role("button", name=re.compile(r"^Применить$", re.I)),
        page.get_by_role("button", name=re.compile(r"^Показать$", re.I)),
        page.get_by_role("button", name=re.compile(r"^Найти$", re.I)),
    ):
        if await locator.count():
            try:
                await locator.first.click(timeout=3000)
                await _pause(page, 800)
                return
            except Exception:
                continue

    await page.evaluate(
        """() => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            for (const el of document.querySelectorAll('button,a,[role=button]')) {
                const t = norm(el.innerText);
                if (/^(Применить|Показать|Найти)$/i.test(t)) {
                    el.click();
                    return;
                }
            }
        }"""
    )
    await _pause(page, 800)


async def _close_filter_panel(page) -> None:
    await page.keyboard.press("Escape")
    await _pause(page, 200)
    await page.keyboard.press("Escape")
    await _pause(page, 200)

    await page.evaluate(
        """() => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            for (const el of document.querySelectorAll('button,[role=button],[aria-label],[title]')) {
                const t = norm(el.innerText);
                const hint = norm(el.getAttribute('aria-label') || el.getAttribute('title') || '');
                if (
                    t === '×' || t === '✕' || /^закрыть$/i.test(t) || /^свернуть$/i.test(t)
                    || /^закрыть$/i.test(hint) || /^свернуть$/i.test(hint) || /^close$/i.test(hint)
                ) {
                    const rect = el.getBoundingClientRect();
                    if (rect.width > 0 && rect.height > 0) {
                        el.click();
                        return;
                    }
                }
            }
            for (const el of document.querySelectorAll('[class*="overlay"],[class*="backdrop"],[class*="mask"]')) {
                const rect = el.getBoundingClientRect();
                if (rect.width > 200 && rect.height > 200) {
                    el.click();
                    break;
                }
            }
        }"""
    )
    await _pause(page, 500)

    viewport = page.viewport_size or {"width": 1440, "height": 1200}
    await page.mouse.click(int(viewport["width"] * 0.7), int(viewport["height"] * 0.4))
    await _pause(page, 400)

    await page.evaluate(
        """() => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            for (const el of document.querySelectorAll('button,a,[role=button]')) {
                const t = norm(el.innerText);
                if ((/^фильтр/i.test(t) || t === 'Фильтры') && t.length < 30) {
                    el.click();
                    return;
                }
            }
        }"""
    )
    await _pause(page, 400)

    await page.evaluate(
        """() => {
            for (const el of document.querySelectorAll('table,[class*="table"],[class*="list"],[class*="grid"]')) {
                if (el.offsetHeight > 80) {
                    el.scrollIntoView({block: 'start'});
                    break;
                }
            }
            window.scrollTo(0, 0);
        }"""
    )
    await _pause(page, 400)


async def _open_filter_dropdown(page, section_name: str) -> None:
    try:
        trigger = page.get_by_text(re.compile(rf"^{re.escape(section_name)}$", re.I))
        if await trigger.count():
            await trigger.first.click(timeout=3000)
            await _pause(page, 350)
            return
    except Exception:
        pass
    await page.evaluate(
        """(sectionName) => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            for (const el of document.querySelectorAll('div,span,button,label,[role=button]')) {
                if (norm(el.innerText) === sectionName) {
                    el.click();
                    return;
                }
            }
        }""",
        section_name,
    )
    await _pause(page, 350)


async def _apply_case_filters(page) -> None:
    if not await _cases_list_ui_ready(page, timeout_ms=5000):
        raise CasebookError("Фильтры дел недоступны — открыта не та страница Casebook.")
    await _ensure_list_tab(page)
    opened = await _open_filter_panel(page)
    if not opened:
        logger.info("Casebook filter panel not found, trying inline filters")

    await _expand_filter_sections(page)

    section_options = (
        ("Тип участия", ("Ответчик", "Должник")),
        ("Статус", ("В производстве",)),
        ("Вид спора", ("Гражданский",)),
    )
    selected: list[str] = []
    missing: list[str] = []
    for section_name, options in section_options:
        await _open_filter_dropdown(page, section_name)
        for option in options:
            if await _select_filter_option(page, option):
                selected.append(option)
            else:
                missing.append(option)

    await _confirm_filters(page)
    await _close_filter_panel(page)

    if missing:
        logger.warning("Casebook filters not toggled: %s (selected: %s)", ", ".join(missing), ", ".join(selected))
    else:
        logger.info("Casebook filters applied: %s", ", ".join(selected))

    if not selected:
        raise CasebookError("Не удалось применить фильтры в разделе «Дела» Casebook.")

    await _pause(page, 1200)


async def _click_tab_by_title(page, title: str, *, partial: bool = False) -> bool:
    pattern = re.compile(re.escape(title), re.I) if not partial else re.compile(title, re.I)
    for locator in (
        page.get_by_role("tab", name=pattern),
        page.get_by_role("link", name=pattern),
        page.get_by_text(pattern),
    ):
        try:
            if await locator.count() == 0:
                continue
            item = locator.first
            await item.scroll_into_view_if_needed(timeout=5000)
            try:
                await item.click(timeout=5000)
            except Exception:
                await item.click(timeout=5000, force=True)
            await _pause(page, 2000)
            return True
        except Exception:
            continue

    clicked = await page.evaluate(
        """({title, partial}) => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const match = (text) => partial
                ? text.toLowerCase().includes(title.toLowerCase())
                : text === title;
            for (const el of document.querySelectorAll('a,button,[role=tab],li,span,div')) {
                const text = norm(el.innerText);
                if (!text || text.length > 80) continue;
                if (!match(text)) continue;
                const target = el.closest('a,button,[role=tab]') || el;
                target.scrollIntoView({block: 'center'});
                target.click();
                return true;
            }
            return false;
        }""",
        {"title": title, "partial": partial},
    )
    if clicked:
        await _pause(page, 2000)
    return bool(clicked)


async def _find_sidebar_link_url(
    page,
    company_id: str,
    link_text: str,
    href_hints: tuple[str, ...],
) -> str | None:
    href = await page.evaluate(
        """({companyId, linkText, hrefHints}) => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const scopes = ['aside', 'nav', '[class*="sidebar" i]', '[class*="menu" i]'];
            const candidates = [];
            const hintRe = new RegExp(hrefHints.join('|'), 'i');
            const collect = (root) => {
                for (const el of root.querySelectorAll('a[href], [role=link]')) {
                    const text = norm(el.innerText);
                    const href = el.href || '';
                    if (!href) continue;
                    if (text === linkText || text.startsWith(linkText + ' ') || text.startsWith(linkText)) {
                        candidates.push(href);
                    }
                    if (href.includes(companyId) && hintRe.test(href + ' ' + text)) {
                        candidates.push(href);
                    }
                }
            };
            for (const sel of scopes) {
                for (const root of document.querySelectorAll(sel)) collect(root);
            }
            const scored = candidates.map((href) => {
                let score = 0;
                if (/\\/card\\/company\\/cases\\//i.test(href)) score += 10;
                if (/\\/card\\/company\\/registr|\\/card\\/company\\/reestr/i.test(href)) score += 10;
                if (/registry|reestr|register|registr/i.test(href)) score += 5;
                if (href.includes(companyId)) score += 3;
                return {href, score};
            }).sort((a, b) => b.score - a.score);
            return scored[0]?.href || null;
        }""",
        {"companyId": company_id, "linkText": link_text, "hrefHints": list(href_hints)},
    )
    return href or None


async def _reestr_menu_ready(page, company_id: str, timeout_ms: int = 10000) -> bool:
    if re.search(r"/app/feed|/logon|/login", page.url, re.I):
        return False
    if company_id in page.url and REGISTRIES_URL_RE.search(page.url):
        return True
    try:
        await page.wait_for_function(
            """(companyId) => {
                const url = location.href.toLowerCase();
                if (/\\/app\\/feed|\\/logon|\\/login/.test(url)) return false;
                if (!url.includes(companyId)) return false;
                if (/\\/card\\/company\\/(licenses|registr|reestr|registry)\\//i.test(url)) return true;
                const tabs = [...document.querySelectorAll('a,button,[role=tab],div,span,li')]
                    .map((el) => (el.innerText || '').replace(/\\s+/g, ' ').trim())
                    .filter((t) => t && t.length < 50);
                return tabs.some((t) => /исполнительн|банкрот|залог|лиценз/i.test(t));
            }""",
            company_id,
            timeout=timeout_ms,
        )
        return not re.search(r"/app/feed|/logon|/login", page.url, re.I)
    except Exception:
        return False


def _url_on_registries_section(page, company_id: str) -> bool:
    return company_id in page.url and bool(REGISTRIES_URL_RE.search(page.url))


def _url_on_enforcement_section(page, company_id: str) -> bool:
    return company_id in page.url and bool(ENFORCEMENT_URL_RE.search(page.url))


_CARD_TAB_MIN_X = 0


async def _wait_for_card_top_tab_labels(page, timeout_ms: int = 20000) -> None:
    try:
        await page.wait_for_function(
            """() => {
                const t = document.body?.innerText || '';
                return /\\bРеестры\\b/.test(t) && /\\bДела\\b/.test(t);
            }""",
            timeout=timeout_ms,
        )
    except Exception:
        logger.info("Casebook top tabs slow url=%s", page.url)
    await _pause(page, 1000)


async def _debug_tab_scan(page) -> dict:
    return await page.evaluate(
        """() => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const isAside = (el) =>
                !!el.closest('aside, [class*="sidebar" i], [class*="Sidebar" i]');
            const out = [];
            for (const el of document.querySelectorAll('a, button, [role=tab], div, span, li')) {
                const text = norm(el.innerText);
                if (!/^(Дела|Реестры|Компания|Контракты)$/i.test(text)
                    && !/^Реестры(\\s|$|\\d)/i.test(text)) continue;
                if (text.length > 30) continue;
                const rect = el.getBoundingClientRect();
                if (rect.width < 5 || rect.height < 5) continue;
                out.push({
                    text,
                    x: Math.round(rect.x),
                    y: Math.round(rect.y),
                    tag: el.tagName,
                    aside: isAside(el),
                });
            }
            return {hits: out.slice(0, 40), bodyHasReestr: /\\bРеестры\\b/.test(document.body?.innerText || '')};
        }"""
    )


async def _click_registries_near_dela(page) -> dict:
    return await page.evaluate(
        """() => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const isAside = (el) =>
                !!el.closest('aside, [class*="sidebar" i], [class*="Sidebar" i], [class*="leftMenu" i]');
            const isGlobalApp = (href) =>
                /\\/app\\//i.test(href) && !/\\/card\\/company\\//i.test(href);
            const collect = (re) => {
                const out = [];
                for (const el of document.querySelectorAll('a, button, [role=tab], div, span, li')) {
                    if (isAside(el)) continue;
                    const text = norm(el.innerText);
                    if (!re.test(text) || text.length > 30) continue;
                    const rect = el.getBoundingClientRect();
                    if (rect.width < 8 || rect.height < 8) continue;
                    const href = el.href || el.closest('a')?.href || '';
                    if (href && isGlobalApp(href)) continue;
                    out.push({el, text, rect, area: rect.width * rect.height});
                }
                out.sort((a, b) => a.area - b.area);
                return out;
            };
            const clickEl = (item, via) => {
                const target = item.el.closest('a,button,[role=tab]') || item.el;
                target.scrollIntoView({block: 'center'});
                target.click();
                return {
                    ok: true,
                    text: item.text,
                    via,
                    x: Math.round(item.rect.x),
                    y: Math.round(item.rect.y),
                };
            };
            const delas = collect(/^Дела$/i);
            const reestrs = collect(/^Реестры(\\s|$|\\d)/i);
            for (const r of reestrs) {
                for (const d of delas) {
                    if (Math.abs(r.rect.y - d.rect.y) < 35 && r.rect.x < d.rect.x + 80) {
                        return clickEl(r, 'near-dela');
                    }
                }
            }
            for (const r of reestrs) {
                if (r.rect.y < 280 && r.rect.x > 80) {
                    return clickEl(r, 'top-strip');
                }
            }
            if (reestrs.length) {
                return clickEl(reestrs[0], 'smallest');
            }
            return {ok: false, delas: delas.length, reestrs: reestrs.length};
        }"""
    )


async def _click_registries_playwright(page) -> dict:
    pattern = re.compile(r"^Реестры(\s|$|\d)", re.I)
    locator = page.locator("a, button, [role=tab], div, span, li").filter(has_text=pattern)
    try:
        count = await locator.count()
        for i in range(min(count, 12)):
            item = locator.nth(i)
            in_aside = await item.evaluate(
                "el => !!el.closest('aside,[class*=\"sidebar\" i],[class*=\"Sidebar\" i]')"
            )
            if in_aside:
                continue
            box = await item.bounding_box()
            if not box or box.get("width", 0) < 8:
                continue
            await item.scroll_into_view_if_needed(timeout=3000)
            try:
                await item.click(timeout=4000)
            except Exception:
                await item.click(timeout=4000, force=True)
            return {
                "ok": True,
                "via": "playwright",
                "text": "Реестры",
                "x": int(box.get("x", 0)),
                "y": int(box.get("y", 0)),
            }
    except Exception:
        pass
    return {"ok": False}


async def _click_company_card_top_tab(page, tab_name: str) -> dict:
    """Клик по вкладке в верхней панели карточки (Компания / Реестры / Дела …)."""
    return await page.evaluate(
        """({tabName, markers}) => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const isGlobalAppLink = (href) =>
                /\\/app\\//i.test(href) && !/\\/card\\/company\\//i.test(href);
            const tryClick = (container) => {
                for (const el of container.querySelectorAll('a, button, [role=tab], [role=link], div, span, li')) {
                    const text = norm(el.innerText);
                    const tabRe = tabName === 'Реестры'
                        ? /^Реестры(\\s|$|\\d)/i
                        : new RegExp('^' + tabName + '$', 'i');
                    if (!tabRe.test(text) || text.length > 30) continue;
                    const href = el.href || el.closest('a')?.href || '';
                    if (href && isGlobalAppLink(href)) continue;
                    const target = el.closest('a,button,[role=tab]') || el;
                    const rect = target.getBoundingClientRect();
                    if (rect.width <= 0 || rect.height <= 0) continue;
                    target.scrollIntoView({block: 'center'});
                    target.click();
                    return {ok: true, text, via: 'top-tab-bar', href, x: Math.round(rect.x)};
                }
                return null;
            };
            for (const anchor of document.querySelectorAll('a, button, [role=tab]')) {
                const anchorText = norm(anchor.innerText);
                if (!markers.includes(anchorText)) continue;
                let node = anchor.parentElement;
                for (let depth = 0; depth < 8 && node; depth++, node = node.parentElement) {
                    const labels = [...node.querySelectorAll('a,button,[role=tab]')]
                        .map((el) => norm(el.innerText))
                        .filter(Boolean);
                    if (markers.filter((m) => labels.includes(m)).length >= 3) {
                        const res = tryClick(node);
                        if (res) return res;
                    }
                }
            }
            return {ok: false};
        }""",
        {"tabName": tab_name, "markers": list(CARD_TOP_TAB_MARKERS)},
    )


async def _click_registries_tab_candidates(page, company_id: str) -> dict:
    for click_fn in (
        lambda: _click_registries_near_dela(page),
        lambda: _click_registries_playwright(page),
        lambda: _click_company_card_top_tab(page, "Реестры"),
        lambda: _click_registries_sibling_of_dela(page, company_id),
        lambda: _click_registries_main_content(page, company_id),
    ):
        clicked = await click_fn()
        if clicked.get("ok"):
            return clicked
    return {"ok": False}


async def _company_card_nav_labels(page, company_id: str) -> list[str]:
    labels = await page.evaluate(
        """({companyId, minX}) => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const isGlobalAppLink = (href) =>
                /\\/app\\//i.test(href) && !/\\/card\\/company\\//i.test(href);
            const out = [];
            const push = (text, href, rect, tag, role) => {
                if (!text || text.length >= 60) return;
                if (href && isGlobalAppLink(href)) return;
                const pos = rect ? '@' + Math.round(rect.x) + ',' + Math.round(rect.y) : '';
                const hrefPart = href ? ' -> ' + href : ' (no href)';
                out.push(text + hrefPart + pos + ' [' + tag + (role ? '/' + role : '') + ']');
            };
            for (const el of document.querySelectorAll('a, button, [role=tab], [role=link], div, span, li')) {
                const text = norm(el.innerText);
                if (!/^(Дела|Реестры|Компания|Контракты|События|Риски|Финансы|исполнительн)/i.test(text)
                    && !/^Реестры(\\s|$|\\d)/i.test(text)) continue;
                if (text.length > 30) continue;
                const href = el.href || el.closest('a')?.href || '';
                const rect = el.getBoundingClientRect();
                if (rect.width <= 0 || rect.height <= 0) continue;
                if (!!el.closest('aside, [class*="sidebar" i], [class*="Sidebar" i]')) continue;
                if (href && href.includes(companyId)) {
                    push(text, href, rect, el.tagName, el.getAttribute('role'));
                } else if (/^(Дела|Реестры|Компания|Контракты|События)/i.test(text)) {
                    push(text, href, rect, el.tagName, el.getAttribute('role'));
                }
            }
            return [...new Set(out)];
        }""",
        {"companyId": company_id, "minX": _CARD_TAB_MIN_X},
    )
    return labels or []


async def _prime_company_card_tabs(page, company_id: str, company_card_url: str) -> None:
    cases_url = f"{CASEBOOK_SITE}/card/company/cases/{company_id}"
    try:
        await page.goto(cases_url, wait_until="domcontentloaded", timeout=30000)
        await _pause(page, 1500)
        if company_id in page.url and not re.search(r"/app/feed|/logon|/login", page.url, re.I):
            logger.info("Casebook primed card tabs via cases url=%s", page.url)
            await _cases_list_ui_ready(page, 15000)
            await _wait_for_card_top_tab_labels(page)
            return
    except Exception as exc:
        logger.info("Casebook cases prime failed: %s", exc)
    await page.goto(company_card_url, wait_until="load", timeout=60000)
    await _wait_for_company_card(page, company_id, timeout_ms=30000)
    await _pause(page, 2000)


async def _registries_section_open(page, company_id: str) -> bool:
    if re.search(r"/app/feed|/app/registries|/logon|/login", page.url, re.I):
        return False
    if company_id not in page.url:
        return False
    if _url_on_registries_section(page, company_id):
        return True
    if await _reestr_menu_ready(page, company_id, 6000):
        return True
    return await page.evaluate(
        """() => {
            for (const el of document.querySelectorAll('a,button,[role=tab],[role=link],div,span,li')) {
                const text = (el.innerText || '').replace(/\\s+/g, ' ').trim();
                if (text.length > 50) continue;
                if (/исполнительн|банкрот|залог|лиценз/i.test(text)) return true;
            }
            return false;
        }"""
    )


async def _wait_for_registries_in_card(page, company_id: str, timeout_ms: int = 15000) -> None:
    try:
        await page.wait_for_function(
            """() => {
                const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
                const isAside = (el) =>
                    !!el.closest('aside, [class*="sidebar" i], [class*="Sidebar" i]');
                const isGlobalAppLink = (href) =>
                    /\\/app\\//i.test(href) && !/\\/card\\/company\\//i.test(href);
                for (const el of document.querySelectorAll('a, button, [role=tab], [role=link], div, span, li')) {
                    if (isAside(el)) continue;
                    const text = norm(el.innerText);
                    if (!/^Реестры(\\s|$|\\d)/i.test(text) || text.length > 30) continue;
                    const rect = el.getBoundingClientRect();
                    if (rect.width <= 0 || rect.height <= 0) continue;
                    const href = el.href || el.closest('a')?.href || '';
                    if (href && isGlobalAppLink(href)) continue;
                    return true;
                }
                return /\\bРеестры\\b/.test(document.body?.innerText || '');
            }""",
            timeout=timeout_ms,
        )
    except Exception:
        debug = await _debug_tab_scan(page)
        logger.info(
            "Casebook Реестры not in company card nav url=%s card_tabs=%s debug=%s",
            page.url,
            await _company_card_nav_labels(page, company_id),
            debug,
        )
    await _pause(page, 1000)


async def _find_registries_url(page, company_id: str) -> str | None:
    href = await page.evaluate(
        """(companyId) => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const scopes = ['aside', 'nav', '[class*="sidebar" i]', '[class*="menu" i]', '[class*="tabs" i]'];
            const candidates = [];
            const isGlobalAppLink = (href) =>
                /\\/app\\//i.test(href) && !/\\/card\\/company\\//i.test(href);
            const collect = (root) => {
                for (const el of root.querySelectorAll('a[href], [role=link], button, [role=tab]')) {
                    const text = norm(el.innerText);
                    const href = el.href || el.closest('a')?.href || '';
                    if (href && isGlobalAppLink(href)) continue;
                    if (/^Реестры(\\s|$|\\d)/i.test(text) && href) candidates.push(href);
                    if (href && href.includes(companyId) && /registr|reestr|registry|register/i.test(href + ' ' + text)) {
                        candidates.push(href);
                    }
                }
            };
            for (const sel of scopes) {
                for (const root of document.querySelectorAll(sel)) collect(root);
            }
            const scored = candidates.map((href) => {
                let score = 0;
                if (/\\/card\\/company\\/registr/i.test(href)) score += 10;
                if (/\\/card\\/company\\/reestr/i.test(href)) score += 10;
                if (/registry|reestr|register|registr/i.test(href)) score += 5;
                if (href.includes(companyId)) score += 3;
                return {href, score};
            }).sort((a, b) => b.score - a.score);
            return scored[0]?.href || null;
        }""",
        company_id,
    )
    return href or None


async def _click_registries_main_content(page, company_id: str) -> dict:
    return await page.evaluate(
        """() => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const isAside = (el) =>
                !!el.closest('aside, [class*="sidebar" i], [class*="Sidebar" i]');
            const isGlobalAppLink = (href) =>
                /\\/app\\//i.test(href) && !/\\/card\\/company\\//i.test(href);
            for (const el of document.querySelectorAll('a, button, [role=tab], [role=link], div, span, li')) {
                if (isAside(el)) continue;
                const text = norm(el.innerText);
                if (!/^Реестры(\\s|$|\\d)/i.test(text) || text.length > 30) continue;
                const rect = el.getBoundingClientRect();
                if (rect.width <= 0 || rect.height <= 0) continue;
                const href = el.href || el.closest('a')?.href || '';
                if (href && isGlobalAppLink(href)) continue;
                const target = el.closest('a,button,[role=tab]') || el;
                target.scrollIntoView({block: 'center'});
                target.click();
                return {ok: true, text, via: 'main-content', href, x: Math.round(rect.x)};
            }
            return {ok: false};
        }"""
    )


async def _click_registries_sibling_of_dela(page, company_id: str) -> dict:
    return await page.evaluate(
        """() => {
            const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
            const isAside = (el) =>
                !!el.closest('aside, [class*="sidebar" i], [class*="Sidebar" i]');
            const isGlobalAppLink = (href) =>
                /\\/app\\//i.test(href) && !/\\/card\\/company\\//i.test(href);
            for (const dela of document.querySelectorAll('a, button, [role=tab], [role=link], div, span, li')) {
                if (isAside(dela)) continue;
                const delaText = norm(dela.innerText);
                if (delaText !== 'Дела') continue;
                const delaRect = dela.getBoundingClientRect();
                if (delaRect.width <= 0 || delaRect.height <= 0) continue;
                const delaHref = dela.href || dela.closest('a')?.href || '';
                if (delaHref && isGlobalAppLink(delaHref)) continue;
                let nav = dela.parentElement;
                for (let depth = 0; depth < 6 && nav; depth++, nav = nav.parentElement) {
                    for (const el of nav.querySelectorAll('a, button, [role=tab], [role=link], div, span, li')) {
                        const text = norm(el.innerText);
                        if (!/^Реестры(\\s|$|\\d)/i.test(text) || text.length > 30) continue;
                        const href = el.href || el.closest('a')?.href || '';
                        if (href && isGlobalAppLink(href)) continue;
                        const target = el.closest('a,button,[role=tab]') || el;
                        target.scrollIntoView({block: 'center'});
                        target.click();
                        return {ok: true, text, via: 'sibling-dela', href, x: Math.round(target.getBoundingClientRect().x)};
                    }
                }
            }
            return {ok: false};
        }"""
    )


async def _goto_registries_section(
    page, url: str, company_id: str, company_card_url: str
) -> bool:
    try:
        await page.goto(url, wait_until="load", timeout=45000)
        await _pause(page, 1500)
        if re.search(r"/app/feed", page.url, re.I):
            logger.info(
                "Casebook registries redirect to feed, recover card url=%s target=%s",
                page.url,
                url,
            )
            await page.goto(company_card_url, wait_until="load", timeout=60000)
            await _pause(page, 1500)
            return False
        if not _url_on_company_card(page, company_id):
            logger.info("Casebook redirect away from company card url=%s target=%s", page.url, url)
            return False
        if await _reestr_menu_ready(page, company_id, 8000):
            logger.info("Casebook registries section url=%s", url)
            return True
    except Exception as exc:
        logger.info("Casebook goto registries failed target=%s: %s", url, exc)
    return False


async def _open_registries_section(
    page, company_id: str, company_card_url: str, *, skip_prime: bool = False
) -> bool:
    if not skip_prime:
        await _prime_company_card_tabs(page, company_id, company_card_url)
    await _wait_for_registries_in_card(page, company_id)

    async def _registries_ready() -> bool:
        await _pause(page, 1000)
        if re.search(r"/app/registries|/app/feed|/logon|/login", page.url, re.I):
            return False
        if _url_on_registries_section(page, company_id):
            return True
        return await _registries_section_open(page, company_id)

    clicked: dict = {"ok": False}
    try:
        async with page.expect_response(
            lambda r: REGISTRIES_API_HINT in r.url and r.status < 500,
            timeout=20000,
        ):
            clicked = await _click_registries_tab_candidates(page, company_id)
    except Exception as exc:
        logger.info("Casebook Реестры API/click: %s", exc)
        if not clicked.get("ok"):
            clicked = await _click_registries_tab_candidates(page, company_id)

    if not clicked.get("ok"):
        debug = await _debug_tab_scan(page)
        logger.info(
            "Casebook Реестры tab not found url=%s card_tabs=%s debug=%s",
            page.url,
            await _company_card_nav_labels(page, company_id),
            debug,
        )
        return False

    logger.info(
        "Casebook Реестры via=%s api=%s url=%s",
        clicked.get("via"),
        REGISTRIES_API_HINT,
        page.url,
    )
    if await _registries_ready():
        return True

    clicked = await _click_registries_tab_candidates(page, company_id)
    if clicked.get("ok"):
        await _pause(page, 4000)
        if re.search(r"/app/registries|/app/feed", page.url, re.I):
            logger.info("Casebook Реестры wrong nav url=%s", page.url)
        elif await _registries_ready():
            logger.info(
                "Casebook Реестры via=%s text=%s url=%s",
                clicked.get("via"),
                clicked.get("text"),
                page.url,
            )
            return True

    reg_pattern = re.compile(r"^Реестры(\s|$|\d)", re.I)
    for scope in (
        page.get_by_role("tab", name=reg_pattern),
        page.locator('[class*="tabs" i], [class*="Tab" i]').get_by_text(reg_pattern),
    ):
        try:
            count = await scope.count()
            for i in range(min(count, 5)):
                item = scope.nth(i)
                box = await item.bounding_box()
                if not box or box.get("x", 0) < _CARD_TAB_MIN_X:
                    continue
                await item.click(timeout=5000)
                await _pause(page, 4000)
                if await _registries_ready():
                    return True
        except Exception:
            continue
    return False


async def _open_enforcement_via_url(page, company_id: str) -> bool:
    url = f"{CASEBOOK_SITE}/card/company/executions/{company_id}"
    try:
        await page.goto(url, wait_until="load", timeout=45000)
        return _url_on_enforcement_section(page, company_id)
    except Exception as exc:
        logger.info("Casebook executions url failed: %s", exc)
        return False


async def _open_reestr_enforcement_tab(page, company_card_url: str) -> None:
    company_id = company_card_url.rstrip("/").split("/")[-1]
    if await _open_enforcement_via_url(page, company_id):
        logger.info("Casebook enforcement fast path url=%s", page.url)
        return

    card_base = company_card_url.rstrip("/")
    if card_base not in page.url.rstrip("/") and not _url_on_registries_section(page, company_id):
        await page.goto(company_card_url, wait_until="load", timeout=60000)
    await _wait_for_company_card(page, company_id, timeout_ms=30000)

    registries_open = await _open_registries_section(page, company_id, company_card_url)
    if not registries_open and _url_on_registries_section(page, company_id):
        logger.info("Casebook Реестры on licenses url=%s (validation catch-up)", page.url)
        registries_open = True

    if not registries_open:
        logger.info(
            "Casebook Реестры first attempt failed url=%s card_tabs=%s",
            page.url,
            await _company_card_nav_labels(page, company_id),
        )
        if not _url_on_registries_section(page, company_id):
            await page.goto(company_card_url, wait_until="load", timeout=30000)
            await _wait_for_company_card(page, company_id, timeout_ms=12000)
        registries_open = await _open_registries_section(
            page, company_id, company_card_url, skip_prime=_url_on_registries_section(page, company_id)
        )
        if not registries_open and _url_on_registries_section(page, company_id):
            registries_open = True

    if not registries_open:
        logger.info(
            "Casebook Реестры retry failed url=%s card_tabs=%s",
            page.url,
            await _company_card_nav_labels(page, company_id),
        )
        raise CasebookError("Не удалось открыть раздел «Реестры» в карточке Casebook.")

    logger.info("Casebook Реестры opened url=%s", page.url)
    if not await _open_enforcement_subtab(page, company_id, company_card_url):
        raise CasebookError(
            "Раздел «Реестры» открыт, но вкладка «Исполнительные производства» не загрузилась."
        )
    logger.info("Casebook исполнительные производства opened url=%s", page.url)


async def _enforcement_ui_ready(page, company_id: str, timeout_ms: int = 12000) -> bool:
    if re.search(r"/app/feed|/logon|/login", page.url, re.I):
        return False
    try:
        await page.wait_for_function(
            """(companyId) => {
                const url = location.href.toLowerCase();
                if (/\\/app\\/feed|\\/logon|\\/login/.test(url)) return false;
                if (!url.includes(companyId)) return false;
                const text = document.body?.innerText || '';
                const loading = /загрузк|loading|подождите/i.test(text);
                const hasSpinner = !!document.querySelector(
                    '[class*="loader" i],[class*="spinner" i],[class*="skeleton" i],[class*="Skeleton" i],[class*="progress" i]'
                );
                if (hasSpinner || loading) return false;
                const hasTitle = /исполнительн/i.test(text) && /производств/i.test(text);
                const hasDetails = /ФССП|предмет исполнения|сумма|номер|пристав|не найдено|нет данных|отсутств|не выявлен/i.test(text);
                const hasRows = document.querySelectorAll(
                    'table tr,[class*="table"] [class*="row"],[class*="list"] > *,[class*="grid"] > *'
                ).length > 2;
                const emptyState = /не найдено|нет данных|отсутств|не выявлен|0 исполнительн/i.test(text);
                return hasTitle && (hasDetails || hasRows || emptyState);
            }""",
            company_id,
            timeout=timeout_ms,
        )
        return not re.search(r"/app/feed|/logon|/login", page.url, re.I)
    except Exception:
        return False


async def _wait_for_enforcement_content(page, company_id: str, timeout_ms: int = 30000) -> bool:
    deadline = time.time() + timeout_ms / 1000

    if await _enforcement_ui_ready(page, company_id, 5000):
        await _pause(page, 1200)
        return True

    try:
        await page.wait_for_response(
            lambda r: ENFORCEMENT_API_HINT in r.url and r.status < 500,
            timeout=max(1000, int((deadline - time.time()) * 1000)),
        )
        logger.info("Casebook enforcement API loaded url=%s", page.url)
    except Exception:
        logger.info("Casebook enforcement API wait skipped url=%s", page.url)

    remaining_ms = max(1000, int((deadline - time.time()) * 1000))
    if await _enforcement_ui_ready(page, company_id, remaining_ms):
        await _pause(page, 1200)
        return True

    if await _click_enforcement_subtab(page):
        try:
            await page.wait_for_response(
                lambda r: ENFORCEMENT_API_HINT in r.url and r.status < 500,
                timeout=max(1000, int((deadline - time.time()) * 1000)),
            )
        except Exception:
            pass
        remaining_ms = max(1000, int((deadline - time.time()) * 1000))
        if await _enforcement_ui_ready(page, company_id, remaining_ms):
            await _pause(page, 800)
            return True

    await _pause(page, 3000)
    return await _enforcement_ui_ready(page, company_id, 5000)


async def _prepare_enforcement_page(page, company_card_url: str) -> None:
    company_id = company_card_url.rstrip("/").split("/")[-1]
    logger.info("Casebook enforcement start company_id=%s url=%s", company_id, page.url)
    opened = await _open_enforcement_via_url(page, company_id)
    if not opened:
        await _open_reestr_enforcement_tab(page, company_card_url)
    if not await _wait_for_enforcement_content(page, company_id):
        logger.info("Casebook enforcement content not confirmed url=%s", page.url)
        await _pause(page, 4000)


async def _click_enforcement_subtab(page) -> bool:
    enforcement_re = re.compile(r"исполнительн.{0,30}производств", re.I)
    for locator in (
        page.get_by_role("tab", name=enforcement_re),
        page.get_by_role("link", name=enforcement_re),
        page.locator("div, span, a, button, li").filter(has_text=enforcement_re),
    ):
        try:
            count = await locator.count()
            for i in range(min(count, 8)):
                item = locator.nth(i)
                in_aside = await item.evaluate(
                    "el => !!el.closest('aside,[class*=\"sidebar\" i]')"
                )
                if in_aside:
                    continue
                text = (await item.inner_text()).strip()
                if len(text) > 60:
                    continue
                await item.scroll_into_view_if_needed(timeout=5000)
                try:
                    await item.click(timeout=5000)
                except Exception:
                    await item.click(timeout=5000, force=True)
                return True
        except Exception:
            continue
    return await _click_tab_by_title(page, "Исполнительные производства", partial=True)


async def _open_enforcement_subtab(page, company_id: str, company_card_url: str) -> bool:
    clicked = False
    try:
        async with page.expect_response(
            lambda r: ENFORCEMENT_API_HINT in r.url and r.status < 500,
            timeout=20000,
        ):
            clicked = await _click_enforcement_subtab(page)
    except Exception as exc:
        logger.info("Casebook enforcement API/click: %s", exc)
        if not clicked:
            clicked = await _click_enforcement_subtab(page)

    if not clicked:
        return False

    logger.info("Casebook enforcement api=%s url=%s", ENFORCEMENT_API_HINT, page.url)
    return await _wait_for_enforcement_content(page, company_id)


async def _casebook_start(
    inn: str,
    *,
    company_name: str | None = None,
    company_short_name: str | None = None,
    company_address: str | None = None,
    company_ogrn: str | None = None,
):
    if not casebook_configured():
        raise CasebookError("Задайте CASEBOOK_EMAIL и CASEBOOK_PASSWORD в .env")
    if not _playwright_available():
        raise CasebookError("Установите playwright: pip install playwright && playwright install chromium")

    identity = await _resolve_org_identity(
        inn,
        company_name=company_name,
        company_short_name=company_short_name,
        company_address=company_address,
        company_ogrn=company_ogrn,
    )
    if identity.name or identity.address or identity.ogrn:
        logger.info(
            "Casebook identity inn=%s name=%s short=%s ogrn=%s address=%s is_branch=%s",
            inn,
            (identity.name or "")[:80],
            (identity.short_name or "")[:40],
            identity.ogrn,
            (identity.address or "")[:80],
            identity.is_branch,
        )

    login, password = _casebook_credentials()
    from playwright.async_api import async_playwright

    global _playwright_ref
    if _playwright_ref is None:
        _playwright_ref = await async_playwright().start()
    browser = await _ensure_browser(_playwright_ref)
    context, page = await _create_authenticated_context(browser, login, password)
    card_url = await _open_company_by_ogrn(page, inn, identity)
    if not card_url:
        await _search_inn(page, inn, login, password)
        card_url = await _pick_organization(page, inn, identity)
    return context, page, card_url, login, password


async def _casebook_finish(context, page, *, inn: str, exc: Exception | None = None) -> None:
    if exc is not None:
        if isinstance(exc, CasebookError) and re.search(
            r"войти|CASEBOOK_EMAIL|CASEBOOK_PASSWORD|Logon", str(exc), re.I
        ):
            SESSION_FILE.unlink(missing_ok=True)
        else:
            try:
                if re.search(r"/logon", page.url, re.I):
                    SESSION_FILE.unlink(missing_ok=True)
            except Exception:
                pass
    try:
        await context.storage_state(path=str(SESSION_FILE))
    except Exception:
        pass
    await page.close()
    await context.close()


async def _wait_for_case_summary_stats(page, timeout_ms: int = 20000) -> bool:
    try:
        await page.wait_for_function(
            """() => {
                const text = document.body?.innerText || '';
                return /исковые требования/i.test(text) && /третьего/i.test(text);
            }""",
            timeout=timeout_ms,
        )
        return True
    except Exception:
        logger.info("Casebook cases summary stats not visible url=%s", page.url)
        return False


async def _wait_for_enforcement_summary_stats(page, timeout_ms: int = 20000) -> bool:
    try:
        await page.wait_for_function(
            """() => {
                const text = document.body?.innerText || '';
                return /взыскания по открытым производствам/i.test(text);
            }""",
            timeout=timeout_ms,
        )
        return True
    except Exception:
        logger.info("Casebook enforcement summary stats not visible url=%s", page.url)
        return False


async def _casebook_screenshot(page) -> bytes:
    return await page.screenshot(full_page=True, type="png", animations="disabled")


async def _capture_casebook_in_session(
    inn: str,
    *,
    cases: bool = True,
    enforcement: bool = False,
    company_name: str | None = None,
    company_short_name: str | None = None,
    company_address: str | None = None,
    company_ogrn: str | None = None,
) -> tuple[bytes | None, bytes | None]:
    context = page = None
    cases_png: bytes | None = None
    enforcement_png: bytes | None = None
    cases_claims: float | None = None
    enforcement_claims: float | None = None
    try:
        context, page, card_url, _login, _password = await _casebook_start(
            inn,
            company_name=company_name,
            company_short_name=company_short_name,
            company_address=company_address,
            company_ogrn=company_ogrn,
        )
        company_id = card_url.rstrip("/").split("/")[-1]
        if cases:
            await _open_cases_tab(page, card_url)
            await _apply_case_filters(page)
            await _wait_for_case_summary_stats(page)
            await _pause(page, 2000)
            cases_claims = await extract_cases_third_party_claims(page)
            cases_png = await _casebook_screenshot(page)
        if enforcement:
            await _prepare_enforcement_page(page, card_url)
            await _wait_for_enforcement_summary_stats(page)
            await _pause(page, 1500)
            enforcement_claims = await extract_enforcement_open_claims(page)
            enforcement_png = await _casebook_screenshot(page)
        merge_kwargs: dict[str, float | None] = {}
        if cases and cases_claims is not None:
            merge_kwargs["cases_third_party_claims"] = cases_claims
        if enforcement and enforcement_claims is not None:
            merge_kwargs["enforcement_open_claims"] = enforcement_claims
        if merge_kwargs:
            merge_casebook_metrics(inn, **merge_kwargs)
        return cases_png, enforcement_png
    except CasebookError:
        raise
    except Exception as exc:
        await _reset_browser()
        logger.exception("Casebook screenshot failed inn=%s", inn)
        raise CasebookError(f"Не удалось получить скриншот Casebook: {exc}") from exc
    finally:
        if page and context:
            await _casebook_finish(context, page, inn=inn)


async def capture_casebook_cases_screenshot(
    inn: str,
    *,
    company_name: str | None = None,
    company_short_name: str | None = None,
    company_address: str | None = None,
    company_ogrn: str | None = None,
) -> bytes:
    async with _browser_lock:
        try:
            cases_png, _ = await _capture_casebook_in_session(
                inn,
                cases=True,
                enforcement=False,
                company_name=company_name,
                company_short_name=company_short_name,
                company_address=company_address,
                company_ogrn=company_ogrn,
            )
            if not cases_png:
                raise CasebookError("Не удалось получить скриншот Casebook.")
            return cases_png
        except CasebookError as exc:
            logger.info("Casebook error inn=%s: %s", inn, exc)
            raise


async def capture_casebook_enforcement_screenshot(
    inn: str,
    *,
    company_name: str | None = None,
    company_short_name: str | None = None,
    company_address: str | None = None,
    company_ogrn: str | None = None,
) -> bytes:
    async with _browser_lock:
        try:
            _, enforcement_png = await asyncio.wait_for(
                _capture_casebook_in_session(
                    inn,
                    cases=False,
                    enforcement=True,
                    company_name=company_name,
                    company_short_name=company_short_name,
                    company_address=company_address,
                    company_ogrn=company_ogrn,
                ),
                timeout=ENFORCEMENT_TIMEOUT_SEC,
            )
            if not enforcement_png:
                raise CasebookError("Не удалось получить скриншот исполнительных производств Casebook.")
            return enforcement_png
        except (asyncio.TimeoutError, TimeoutError) as exc:
            logger.info("Casebook enforcement timeout inn=%s", inn)
            raise CasebookError(
                "Casebook исп. производства: превышено время ожидания (~120 с). "
                "Повторите позже."
            ) from exc
        except CasebookError as exc:
            logger.info("Casebook enforcement error inn=%s: %s", inn, exc)
            raise


async def capture_casebook_both_screenshots(
    inn: str,
    *,
    company_name: str | None = None,
    company_short_name: str | None = None,
    company_address: str | None = None,
    company_ogrn: str | None = None,
) -> tuple[bytes | None, bytes | None]:
    """Один вход в Casebook — оба скриншота (быстрее ZIP и пары запросов)."""
    async with _browser_lock:
        try:
            cases_png, enforcement_png = await asyncio.wait_for(
                _capture_casebook_in_session(
                    inn,
                    cases=True,
                    enforcement=True,
                    company_name=company_name,
                    company_short_name=company_short_name,
                    company_address=company_address,
                    company_ogrn=company_ogrn,
                ),
                timeout=ENFORCEMENT_TIMEOUT_SEC + 90,
            )
        except (asyncio.TimeoutError, TimeoutError) as exc:
            logger.info("Casebook both screenshots timeout inn=%s", inn)
            raise CasebookError(
                "Casebook: превышено время ожидания. Повторите выгрузку позже."
            ) from exc
        if not cases_png and not enforcement_png:
            raise CasebookError("Не удалось получить скриншоты Casebook.")
        if not cases_png:
            logger.warning("Casebook cases screenshot missing inn=%s", inn)
        if not enforcement_png:
            logger.warning("Casebook enforcement screenshot missing inn=%s", inn)
        return cases_png, enforcement_png


async def fetch_casebook_claim_metrics(
    inn: str,
    *,
    company_name: str | None = None,
    company_short_name: str | None = None,
    company_address: str | None = None,
    company_ogrn: str | None = None,
):
    """Суммы исков из Casebook без скриншотов (кэш 8 ч)."""
    cached = load_cached_casebook_metrics(inn)
    if cached:
        return cached
    async with _browser_lock:
        cached = load_cached_casebook_metrics(inn)
        if cached:
            return cached
        context = page = None
        try:
            context, page, card_url, _login, _password = await _casebook_start(
                inn,
                company_name=company_name,
                company_short_name=company_short_name,
                company_address=company_address,
                company_ogrn=company_ogrn,
            )
            await _open_cases_tab(page, card_url)
            await _apply_case_filters(page)
            await _wait_for_case_summary_stats(page)
            await _pause(page, 2000)
            cases_claims = await extract_cases_third_party_claims(page)
            await _prepare_enforcement_page(page, card_url)
            await _wait_for_enforcement_summary_stats(page)
            await _pause(page, 1500)
            enforcement_claims = await extract_enforcement_open_claims(page)
            merge_kwargs: dict[str, float | None] = {}
            if cases_claims is not None:
                merge_kwargs["cases_third_party_claims"] = cases_claims
            if enforcement_claims is not None:
                merge_kwargs["enforcement_open_claims"] = enforcement_claims
            if not merge_kwargs:
                raise CasebookError("Не удалось прочитать суммы исков в Casebook.")
            return merge_casebook_metrics(inn, **merge_kwargs)
        except CasebookError:
            raise
        except Exception as exc:
            raise CasebookError(f"Не удалось получить суммы Casebook: {exc}") from exc
        finally:
            if page and context:
                await _casebook_finish(context, page, inn=inn)
