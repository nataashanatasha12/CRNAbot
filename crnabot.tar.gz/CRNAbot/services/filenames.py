from __future__ import annotations

import re
from urllib.parse import quote


def safe_name_part(text: str | None) -> str:
    cleaned = re.sub(r'[«»"\'\\/:*?<>|]', "", (text or "").strip())
    return re.sub(r"\s+", " ", cleaned)


def join_filename_parts(*parts: str) -> str:
    cleaned = [safe_name_part(part) for part in parts if safe_name_part(part)]
    return " ".join(cleaned)


def organization_folder_name(ogrn: str, short_name: str) -> str:
    """Имя папки в ZIP и база для имени архива — краткое наименование."""
    name = safe_name_part(short_name)
    return name or safe_name_part(ogrn) or "Документы"


def documents_zip_filename(ogrn: str, short_name: str) -> str:
    return f"{organization_folder_name(ogrn, short_name)}.zip"


def zip_entry_path(folder: str, filename: str) -> str:
    folder = safe_name_part(folder) or "Документы"
    return f"{folder}/{filename}"


def egrul_filename(ogrn: str, short_name: str) -> str:
    return f"{join_filename_parts(ogrn, 'Выписка ЕГРЮЛ', short_name)}.pdf"


def egrul_predecessor_filename(ogrn: str, short_name: str) -> str:
    return f"{join_filename_parts(ogrn, 'Выписка ЕГРЮЛ', short_name, 'предшественник')}.pdf"


def reporting_filename(ogrn: str, short_name: str, year: str, ext: str = "pdf") -> str:
    return f"{join_filename_parts(ogrn, 'Отчетность', short_name, year)}.{ext}"


def audit_filename(ogrn: str, short_name: str, year: str) -> str:
    return f"{join_filename_parts(ogrn, 'АЗ', short_name, year)}.pdf"


def rmsp_filename(ogrn: str, short_name: str) -> str:
    return f"{join_filename_parts(ogrn, 'Выписка МСП', short_name)}.xlsx"


def fsgs_filename(ogrn: str, short_name: str) -> str:
    return f"{join_filename_parts(ogrn, 'ФСГС', short_name)}.pdf"


def girbo_okved_screenshot_filename(ogrn: str, short_name: str, year: str) -> str:
    return f"{join_filename_parts(ogrn, 'ОКВЭД ГИР БО', short_name, year)}.png"


def casebook_screenshot_filename(ogrn: str, short_name: str) -> str:
    return f"{join_filename_parts(ogrn, 'Casebook дела', short_name)}.png"


def casebook_enforcement_screenshot_filename(ogrn: str, short_name: str) -> str:
    return f"{join_filename_parts(ogrn, 'Casebook исп. производства', short_name)}.png"


def fedresurs_publications_screenshot_filename(ogrn: str, short_name: str) -> str:
    return f"{join_filename_parts(ogrn, 'Федресурс публикации', short_name)}.png"


def fedresurs_audit_screenshot_filename(ogrn: str, short_name: str) -> str:
    return f"{join_filename_parts(ogrn, 'Выдержка из Федресурса', short_name)}.png"


def content_disposition_attachment(filename: str) -> dict[str, str]:
    """RFC 5987: кириллица в имени файла через filename*."""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else "bin"
    match = re.match(r"^(\d+)", filename)
    fallback = f"{match.group(1)}.{ext}" if match else f"download.{ext}"
    encoded = quote(filename, safe="")
    return {
        "Content-Disposition": f"attachment; filename=\"{fallback}\"; filename*=UTF-8''{encoded}"
    }
