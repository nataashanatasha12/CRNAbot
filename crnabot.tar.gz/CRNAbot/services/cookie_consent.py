from __future__ import annotations

import logging
import re

logger = logging.getLogger("crnabot.cookie_consent")

_COMMON_CLICK_SELECTORS = [
    "button[aria-label*='Accept' i]",
    "button[aria-label*='Принять' i]",
    "#cookiesjsr button.cookiesjsr-btn-accept",
    "#cookiesjsr button.accept",
    ".cookie-accept",
    ".cookies-accept",
    "[data-testid='accept-all-cookies']",
    ".js-cookie-accept",
    ".cookie-disclaimer button",
    ".cookie-banner button",
    ".cookies-policy button",
    ".cookie-notice button",
    ".cookie-panel button",
    "[class*='cookie'] button",
    "[id*='cookie'] button",
]

_SITE_SELECTORS: dict[str, list[str]] = {
    "fedresurs": [
        ".interfax-cookie button",
        ".cookie-disclaimer button",
        ".cookies-policy button",
    ],
    "girbo": [
        ".nalog-cookie button",
        ".cookie-panel button",
    ],
    "fsgs": [
        ".cookie-panel button",
        ".cookies-policy button",
        "[class*='cookie'] button",
    ],
}

_ACCEPT_TEXTS = (
    "Принять",
    "Согласен",
    "Согласна",
    "OK",
    "ОК",
    "Понятно",
    "Хорошо",
    "Принимаю",
    "Продолжить",
    "Закрыть",
    "Accept all",
    "Accept All",
)

_PRESET_CONSENT_JS = """() => {
    const keys = [
        'cookieConsent', 'cookies_accepted', 'cookie_notice_accepted',
        'cookiesConsent', 'cookie_agreed', 'isCookieAccepted', 'cookieconsent_status',
    ];
    for (const k of keys) {
        try { localStorage.setItem(k, 'true'); } catch {}
        try { localStorage.setItem(k, '1'); } catch {}
        try { localStorage.setItem(k, 'accepted'); } catch {}
    }
    try {
        document.cookie = 'cookie_consent=true; path=/; max-age=31536000';
        document.cookie = 'cookies_accepted=1; path=/; max-age=31536000';
        document.cookie = 'cookie_notice_accepted=1; path=/; max-age=31536000';
    } catch {}
}"""

_DISMISS_JS = """() => {
    const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
    const acceptRe = /^(принять|согласен|согласна|ok|ок|понятно|хорошо|принимаю|продолжить|закрыть|accept all|принять все)$/i;
    let action = null;
    for (const el of document.querySelectorAll('button,a,[role=button],input[type=button],label')) {
        const t = norm(el.innerText);
        const hint = norm(el.getAttribute('aria-label') || el.getAttribute('title') || '');
        const label = t || hint;
        if (!label || label.length > 60) continue;
        if (acceptRe.test(label)) {
            const rect = el.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0) {
                el.click();
                action = 'clicked:' + label;
                break;
            }
        }
    }
    const hideSelectors = [
        '#cookiesjsr', '.cookiesjsr',
        '[class*="cookie" i]', '[id*="cookie" i]',
        '[class*="consent" i]', '[id*="consent" i]',
        '[class*="gdpr" i]',
        '[class*="cookie-banner" i]', '[class*="cookie-notice" i]',
        '[class*="cookie-panel" i]', '[class*="cookieBar" i]',
        '[class*="Cookie" i]', '[id*="Cookie" i]',
        '[role="dialog"][class*="cookie" i]',
        '[class*="cookies-message" i]', '[class*="cookies-info" i]',
    ];
    let hidden = 0;
    for (const sel of hideSelectors) {
        for (const el of document.querySelectorAll(sel)) {
            const rect = el.getBoundingClientRect();
            const style = window.getComputedStyle(el);
            if (rect.width > 80 && rect.height > 20 && style.display !== 'none') {
                el.style.setProperty('display', 'none', 'important');
                el.style.setProperty('visibility', 'hidden', 'important');
                el.style.setProperty('opacity', '0', 'important');
                el.style.setProperty('pointer-events', 'none', 'important');
                hidden += 1;
            }
        }
    }
    document.body?.classList.remove('cookie-open', 'cookies-open', 'cookie-visible', 'no-scroll');
    document.documentElement?.classList.remove('cookie-open', 'cookies-open', 'no-scroll');
    return { action, hidden };
}"""


async def _click_selector_buttons(page, selectors: list[str]) -> int:
    clicked = 0
    for selector in selectors:
        try:
            locator = page.locator(selector).first
            if await locator.count() == 0:
                continue
            if not await locator.is_visible():
                continue
            await locator.click(timeout=2000)
            clicked += 1
        except Exception:
            continue
    return clicked


async def _click_text_buttons(page) -> int:
    clicked = 0
    for text in _ACCEPT_TEXTS:
        pattern = re.compile(rf"^{re.escape(text)}$", re.I)
        for getter in (
            lambda p=pattern: page.get_by_role("button", name=p),
            lambda p=pattern: page.get_by_role("link", name=p),
            lambda p=pattern: page.get_by_text(p, exact=True),
        ):
            try:
                locator = getter().first
                if await locator.count() == 0:
                    continue
                if not await locator.is_visible():
                    continue
                await locator.click(timeout=2000)
                clicked += 1
                break
            except Exception:
                continue
    return clicked


async def dismiss_cookie_consent(page, *, site: str = "") -> None:
    """Dismiss or hide cookie consent banners before taking a screenshot."""
    site_key = (site or "").strip().lower()
    selectors = list(_COMMON_CLICK_SELECTORS)
    selectors.extend(_SITE_SELECTORS.get(site_key, []))

    try:
        await page.evaluate(_PRESET_CONSENT_JS)
    except Exception:
        pass

    clicked = await _click_selector_buttons(page, selectors)
    if not clicked:
        clicked = await _click_text_buttons(page)

    try:
        result = await page.evaluate(_DISMISS_JS)
        logger.info(
            "Cookie consent dismiss site=%s clicked=%s js=%s",
            site_key or "?",
            clicked,
            result,
        )
    except Exception as exc:
        logger.info("Cookie consent dismiss JS failed site=%s: %s", site_key or "?", exc)
        return

    if clicked:
        try:
            await page.wait_for_timeout(400)
            await page.evaluate(_DISMISS_JS)
        except Exception:
            pass
