from __future__ import annotations

import hashlib
import os
import re
import sys
import tempfile
import time
import zlib
from dataclasses import dataclass, field

from io import BytesIO

from pypdf import PdfReader

AUDIT_ANALYSIS_NOT_DONE = "Анализ АЗ не проведен"

_AUDIT_OPINION_CACHE: dict[str, tuple[float, str]] = {}
_AUDIT_OPINION_CACHE_TTL = 6 * 3600
_AUDIT_OPINION_CACHE_VERSION = "v4-opinion"


def _audit_opinion_cache_key(data: bytes, cache_key: str | None = None) -> str:
    if cache_key:
        return f"{_AUDIT_OPINION_CACHE_VERSION}:{cache_key}"
    digest = hashlib.sha256(data[:512_000]).hexdigest()[:24]
    return f"{_AUDIT_OPINION_CACHE_VERSION}:{len(data)}:{digest}"


@dataclass
class AuditAnalysis:
    is_audit_report: bool
    year_ok: bool
    org_ok: bool
    opinion: str
    status: str
    details: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.is_audit_report and self.year_ok and self.org_ok and self.opinion == "unqualified"


_AUDIT_MARKERS = (
    "аудиторское заключение",
    "мнение аудитора",
    "независимого аудитора",
    "аудиторская организация",
    "аудиторской организации",
)

_FEDRESURS_EXCERPT_MARKERS = (
    "выдержка словами из аудиторского",
    "выдержка из аудиторского заключения",
    "выдержка из аудиторского",
    "результаты обязательного аудита",
    "обязательный аудит",
)

_ORG_NOISE = (
    "общество с ограниченной ответственностью",
    "публичное акционерное общество",
    "акционерное общество",
    "ооо",
    "оао",
    "зао",
    "пао",
    "ао",
)


def _pdf_embedded_strings(data: bytes) -> str:
    """Fallback: pull readable Cyrillic/Latin runs from PDF byte streams."""
    chunks: list[str] = []
    seen: set[str] = set()

    def add(text: str) -> None:
        cleaned = _squash(text)
        if len(cleaned) < 8:
            return
        key = cleaned.casefold()
        if key in seen:
            return
        seen.add(key)
        chunks.append(cleaned)

    for raw in re.findall(rb"\(([^()\\]{3,500})\)", data):
        for encoding in ("utf-8", "cp1251", "latin-1"):
            try:
                text = raw.decode(encoding)
            except Exception:
                continue
            if re.search(r"[а-яА-ЯёЁ]", text):
                add(text)
                break

    for encoding in ("utf-8", "cp1251", "latin-1"):
        try:
            decoded = data.decode(encoding, errors="ignore")
        except Exception:
            continue
        for match in re.finditer(
            r"[А-Яа-яЁё][А-Яа-яЁё0-9 «»\"'.,;:!?()\-]{20,}",
            decoded,
        ):
            add(match.group(0))

    return "\n".join(chunks)


def _extract_page_text(page) -> str:
    best = ""
    for mode in ("layout", None):
        try:
            if mode:
                chunk = page.extract_text(extraction_mode=mode) or ""
            else:
                chunk = page.extract_text() or ""
        except Exception:
            chunk = ""
        if len(chunk.strip()) > len(best.strip()):
            best = chunk
    return best


def _extract_pypdf_text(data: bytes, *, max_pages: int | None = None) -> str:
    reader = PdfReader(BytesIO(data))
    pages = reader.pages[:max_pages] if max_pages else reader.pages
    parts: list[str] = []
    for page in pages:
        chunk = _extract_page_text(page)
        if chunk.strip():
            parts.append(chunk)
    return "\n".join(parts)


def _extract_early_pages_text(data: bytes, *, pages: int = 12) -> str:
    """Первые страницы АЗ — там заголовок мнения и «Основание для выражения мнения»."""
    if not data.startswith(b"%PDF"):
        return ""
    reader = PdfReader(BytesIO(data))
    parts: list[str] = []
    for page in reader.pages[:pages]:
        chunk = _extract_page_text(page)
        if chunk.strip():
            parts.append(chunk)
    return "\n".join(parts)


def _text_has_audit_markers(text: str) -> bool:
    lower = _lower(text)
    return any(
        marker in lower
        for marker in (
            "аудиторское заключение",
            "мнение аудитора",
            "мнение с оговоркой",
            "мнение без оговорки",
            "по нашему мнению",
            "основание для выражения мнения",
            "выражаем мнение",
            "немодифицированное мнение",
        )
    )


def _pymupdf_page_text_fast(page) -> str:
    try:
        import fitz
    except ImportError:
        return ""
    flags = fitz.TEXTFLAGS_TEXT | fitz.TEXT_PRESERVE_LIGATURES | fitz.TEXT_PRESERVE_WHITESPACE
    try:
        return page.get_text("text", flags=flags, sort=True) or ""
    except Exception:
        try:
            return page.get_text("text", sort=True) or ""
        except Exception:
            return ""


def _pymupdf_page_text(page) -> str:
    try:
        import fitz
    except ImportError:
        return ""
    candidates: list[str] = []
    text_flags = (
        fitz.TEXTFLAGS_TEXT,
        fitz.TEXTFLAGS_TEXT | fitz.TEXT_PRESERVE_LIGATURES | fitz.TEXT_PRESERVE_WHITESPACE,
        fitz.TEXTFLAGS_TEXT
        | fitz.TEXT_PRESERVE_LIGATURES
        | fitz.TEXT_PRESERVE_WHITESPACE
        | fitz.TEXT_CID_FOR_UNKNOWN_UNICODE,
    )
    for flags in text_flags:
        for sort in (True, False):
            try:
                candidates.append(page.get_text("text", flags=flags, sort=sort) or "")
            except Exception:
                pass
    for mode in ("blocks", "xhtml", "words"):
        try:
            if mode == "blocks":
                blocks = page.get_text("blocks", sort=True) or []
                candidates.append("\n".join(str(block[4]) for block in blocks if len(block) > 4))
            elif mode == "words":
                words = page.get_text("words", sort=True) or []
                candidates.append(" ".join(str(word[4]) for word in words if len(word) > 4))
            else:
                candidates.append(page.get_text(mode, sort=True) or "")
        except Exception:
            pass
    try:
        payload = page.get_text("dict", sort=True) or {}
        spans: list[str] = []
        for block in payload.get("blocks", []):
            if not isinstance(block, dict):
                continue
            for line in block.get("lines", []):
                if not isinstance(line, dict):
                    continue
                for span in line.get("spans", []):
                    if isinstance(span, dict):
                        spans.append(str(span.get("text") or ""))
        candidates.append(" ".join(spans))
    except Exception:
        pass
    return max(candidates, key=lambda item: len(item.strip()), default="")


def _iter_nested_pdf_bytes(data: bytes) -> list[bytes]:
    """ГИР БО иногда кладёт АЗ во вложенный PDF внутри большого файла."""
    seen: set[bytes] = set()
    ordered: list[bytes] = []

    def add(blob: bytes) -> None:
        if not blob.startswith(b"%PDF"):
            return
        key = blob[:200_000]
        if key in seen:
            return
        seen.add(key)
        ordered.append(blob)

    add(data)
    try:
        import fitz

        doc = fitz.open(stream=data, filetype="pdf")
        try:
            for name in doc.embfile_names()[:3]:
                try:
                    embedded = doc.embfile_get(name)
                except Exception:
                    continue
                if isinstance(embedded, (bytes, bytearray)):
                    add(bytes(embedded))
        finally:
            doc.close()
    except Exception:
        pass
    return ordered


def _best_audit_text_from_pdf_blob(data: bytes, *, max_pages: int = 8) -> str | None:
    pymupdf_text = _extract_pymupdf_text(data, max_pages=max_pages, fast=True)
    if pymupdf_text.strip() and (
        _text_has_audit_markers(pymupdf_text)
        or _blob_has_qualified_opinion(pymupdf_text)
        or _blob_has_unqualified_opinion(pymupdf_text)
    ):
        return pymupdf_text
    if len(data) <= 3_000_000:
        pypdf_text = _extract_pypdf_text(data, max_pages=max_pages)
        if pypdf_text.strip() and (
            _text_has_audit_markers(pypdf_text)
            or _blob_has_qualified_opinion(pypdf_text)
            or _blob_has_unqualified_opinion(pypdf_text)
        ):
            return pypdf_text
    return None


def _extract_pymupdf_text(data: bytes, *, max_pages: int | None = None, fast: bool = False) -> str:
    try:
        import fitz
    except ImportError:
        return ""
    try:
        doc = fitz.open(stream=data, filetype="pdf")
    except Exception:
        return ""
    try:
        limit = min(len(doc), max_pages or len(doc))
        parts: list[str] = []
        for index in range(limit):
            chunk = _pymupdf_page_text_fast(doc[index]) if fast else _pymupdf_page_text(doc[index])
            if chunk.strip():
                parts.append(chunk)
        return "\n".join(parts)
    finally:
        doc.close()


def _pdf_parenthesis_blob(data: bytes) -> str:
    chunks: list[str] = []
    for raw in re.findall(rb"\(([^()\\]{2,800})\)", data):
        for encoding in ("utf-8", "cp1251", "latin-1"):
            try:
                text = raw.decode(encoding)
            except Exception:
                continue
            if re.search(r"[а-яА-ЯёЁ]", text):
                chunks.append(text)
                break
    return _squash(" ".join(chunks))


def _pdf_hex_blob(data: bytes) -> str:
    chunks: list[str] = []
    for match in re.finditer(rb"<([0-9A-Fa-f]{8,})>", data):
        try:
            raw = bytes.fromhex(match.group(1).decode("ascii"))
        except Exception:
            continue
        for encoding in ("utf-16-be", "utf-16-le", "utf-8", "cp1251"):
            try:
                text = raw.decode(encoding)
            except Exception:
                continue
            if re.search(r"[а-яА-ЯёЁ]", text):
                chunks.append(text)
                break
    return _squash(" ".join(chunks))


def _pdf_decompressed_blobs(data: bytes) -> list[str]:
    blobs: list[str] = []
    for match in re.finditer(rb"stream\r?\n(.*?)\r?\nendstream", data, re.DOTALL):
        raw = match.group(1)
        decoded: bytes | None = None
        for wbits in (zlib.MAX_WBITS, -zlib.MAX_WBITS):
            try:
                decoded = zlib.decompress(raw, wbits)
                break
            except Exception:
                continue
        if not decoded:
            continue
        for encoding in ("utf-8", "cp1251", "utf-16-be", "utf-16-le", "latin-1"):
            try:
                text = decoded.decode(encoding, errors="ignore")
            except Exception:
                continue
            if re.search(r"[а-яА-ЯёЁ]", text):
                blobs.append(_squash(text))
    return blobs


def _blob_has_qualified_opinion(blob: str) -> bool:
    lower = _squash(blob).lower()
    if any(
        phrase in lower
        for phrase in (
            "мнение с оговоркой",
            "основание для выражения мнения с оговоркой",
            "за исключением влияния",
        )
    ):
        return True
    return "мнени" in lower and "оговорк" in lower and lower.find("оговорк") - lower.find("мнени") < 500


def _blob_has_unqualified_opinion(blob: str) -> bool:
    lower = _squash(blob).lower()
    if "оговорк" in lower:
        return False
    return any(
        phrase in lower
        for phrase in (
            "мнение без оговорки",
            "немодифицированное мнение",
        )
    )


def _opinion_from_raw_pdf_bytes(data: bytes) -> str | None:
    """Fallback: ключевые фразы в байтах PDF, hex-строках и сжатых stream."""
    qualified_phrases = (
        "мнение с оговоркой",
        "основание для выражения мнения с оговоркой",
        "за исключением влияния",
    )
    unqualified_phrases = (
        "мнение без оговорки",
        "немодифицированное мнение",
    )

    blobs: list[str] = []
    for encoding in ("utf-8", "cp1251", "utf-16-le", "utf-16-be", "latin-1"):
        try:
            blobs.append(data.decode(encoding, errors="ignore").lower())
        except Exception:
            continue

    blobs.append(_pdf_parenthesis_blob(data).lower())
    blobs.append(_pdf_hex_blob(data).lower())
    blobs.extend(blob.lower() for blob in _pdf_decompressed_blobs(data))

    for blob in blobs:
        if _blob_has_qualified_opinion(blob):
            return "qualified"
    for blob in blobs:
        if _blob_has_unqualified_opinion(blob):
            return "unqualified"

    for phrase in qualified_phrases:
        for encoding in ("utf-8", "cp1251", "utf-16-le", "utf-16-be"):
            try:
                if phrase.encode(encoding) in data:
                    return "qualified"
            except Exception:
                continue
    for phrase in unqualified_phrases:
        for encoding in ("utf-8", "cp1251", "utf-16-le", "utf-16-be"):
            try:
                if phrase.encode(encoding) in data:
                    return "unqualified"
            except Exception:
                continue
    return None


def _ocr_image_macos(image_path: str) -> str:
    if sys.platform != "darwin":
        return ""
    try:
        from ocrmac import ocrmac
    except ImportError:
        return ""
    try:
        annotations = ocrmac.OCR(
            image_path,
            framework="vision",
            recognition_level="accurate",
            language_preference=["ru-RU", "en-US"],
        ).recognize()
    except Exception:
        return ""
    lines = [str(item[0]).strip() for item in annotations if item and str(item[0]).strip()]
    return "\n".join(lines)


def _ocr_early_pages_text(data: bytes, *, pages: int = 1, dpi: int = 170) -> str:
    """Запасной способ, если автоматическое чтение PDF не собрало текст мнения."""
    try:
        import fitz
    except ImportError:
        return ""
    try:
        doc = fitz.open(stream=data, filetype="pdf")
    except Exception:
        return ""
    parts: list[str] = []
    try:
        for index in range(min(pages, len(doc))):
            page = doc[index]
            text = ""
            pix = page.get_pixmap(dpi=dpi)
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                tmp_path = tmp.name
            try:
                pix.save(tmp_path)
                text = _ocr_image_macos(tmp_path)
            finally:
                if os.path.exists(tmp_path):
                    os.unlink(tmp_path)
            if text.strip():
                parts.append(text)
    finally:
        doc.close()
    return "\n".join(parts)


def _pick_best_pdf_text(pypdf_text: str, embedded_text: str) -> str:
    """Embedded byte-scrape can dwarf pypdf with table noise; prefer readable pypdf for АЗ."""
    pypdf_clean = pypdf_text.strip()
    embedded_clean = embedded_text.strip()
    if not pypdf_clean and not embedded_clean:
        return ""
    if not embedded_clean:
        return pypdf_text
    if not pypdf_clean:
        return embedded_text
    pypdf_markers = _text_has_audit_markers(pypdf_text)
    embedded_markers = _text_has_audit_markers(embedded_text)
    if pypdf_markers and not embedded_markers:
        return pypdf_text
    if embedded_markers and not pypdf_markers:
        return embedded_text
    if pypdf_markers and embedded_markers:
        if len(pypdf_clean) >= 800:
            return pypdf_text
        return embedded_text if len(embedded_clean) > len(pypdf_clean) * 3 else pypdf_text
    if len(pypdf_clean) >= 1500:
        return pypdf_text
    return embedded_text if len(embedded_clean) > len(pypdf_clean) else pypdf_text


def audit_text_from_pdf(data: bytes, *, max_pages: int | None = None) -> str:
    if not data.startswith(b"%PDF"):
        return ""

    pymupdf_text = _extract_pymupdf_text(data, max_pages=max_pages)
    pypdf_text = _extract_pypdf_text(data, max_pages=max_pages)
    embedded = _pdf_embedded_strings(data)

    if _text_has_audit_markers(pymupdf_text) and len(pymupdf_text.strip()) >= 200:
        return pymupdf_text
    return _pick_best_pdf_text(
        _pick_best_pdf_text(pypdf_text, pymupdf_text),
        embedded,
    )


def _extract_opinion_sections(full_text: str, *, window: int = 20_000) -> list[str]:
    if not full_text.strip():
        return []
    lower = _lower(full_text)
    sections: list[str] = []
    markers = (
        "аудиторское заключение",
        "мнение с оговоркой",
        "заключение независимых аудиторов",
        "заключение независимого аудитора",
        "независимых аудиторов",
        "мнение аудитора",
        "по нашему мнению",
        "выражаем мнение",
        "основание для выражения мнения",
        "результаты аудита",
        "положительное мнение",
    )
    for marker in markers:
        idx = 0
        while True:
            pos = lower.find(marker, idx)
            if pos < 0:
                break
            sections.append(full_text[pos : pos + window])
            idx = pos + len(marker)
    if len(full_text) > 80_000:
        sections.append(full_text[-150_000:])
    sections.append(full_text[:60_000])
    uniq: list[str] = []
    seen: set[str] = set()
    for section in sections:
        key = section[:160]
        if key in seen:
            continue
        seen.add(key)
        uniq.append(section)
    return uniq


def _audit_opinion_text_uncached(data: bytes) -> str:
    audit_hits: list[tuple[int, str]] = []
    for pdf_blob in _iter_nested_pdf_bytes(data):
        found = _best_audit_text_from_pdf_blob(pdf_blob, max_pages=8)
        if found:
            audit_hits.append((len(pdf_blob), found))
    if audit_hits:
        audit_hits.sort(key=lambda item: item[0])
        return audit_hits[0][1]

    ocr_text = _ocr_early_pages_text(data, pages=1, dpi=170)
    return ocr_text


def audit_opinion_text_from_pdf(data: bytes, *, cache_key: str | None = None) -> str:
    """Текст мнения из первых страниц АЗ; результат кэшируется."""
    if not data.startswith(b"%PDF"):
        return ""

    key = _audit_opinion_cache_key(data, cache_key)
    cached = _AUDIT_OPINION_CACHE.get(key)
    if cached and time.monotonic() - cached[0] < _AUDIT_OPINION_CACHE_TTL:
        return cached[1]

    text = _audit_opinion_text_uncached(data)
    _AUDIT_OPINION_CACHE[key] = (time.monotonic(), text)
    return text


def _squash(text: str) -> str:
    cleaned = re.sub(r"[\u00ad\u200b\u200c\u200d\ufeff]", "", text or "")
    cleaned = re.sub(r"-\s*\n\s*", "", cleaned)
    return re.sub(r"\s+", " ", cleaned).strip()


def _lower(text: str) -> str:
    return _squash(text).lower()


def _normalize_org_key(name: str) -> str:
    key = _lower(name)
    key = re.sub(r"[«»\"'()\[\]{}]", " ", key)
    for token in _ORG_NOISE:
        key = key.replace(token, " ")
    key = re.sub(r"[^0-9a-zа-яё]+", "", key)
    return key


def _quoted_names(text: str) -> list[str]:
    return [_squash(match) for match in re.findall(r"[«\"]([^»\"]+)[»\"]", text) if match.strip()]


def _is_audit_report(text: str, *, trusted: bool = False) -> bool:
    lower = _lower(text)
    if trusted:
        return True
    if "аудиторское заключение" in lower:
        return True
    if any(marker in lower for marker in _FEDRESURS_EXCERPT_MARKERS):
        return True
    if "мнение аудитора" in lower and (
        "основание для выражения мнения" in lower or "по нашему мнению" in lower
    ):
        return True
    hits = sum(1 for marker in _AUDIT_MARKERS if marker in lower)
    return hits >= 2


def _has_qualified_basis(lower: str) -> bool:
    return "основание для выражения мнения с оговоркой" in lower


def _has_unqualified_basis(lower: str) -> bool:
    if _has_qualified_basis(lower):
        return False
    for match in re.finditer(r"основание для выражения мнения", lower):
        tail = lower[match.end() : match.end() + 30]
        if not re.match(r"\s*с\s+оговорк", tail):
            return True
    return False


def _report_years(text: str) -> set[str]:
    lower = _lower(text)
    years: set[str] = set()
    patterns = (
        r"за\s+(\d{4})\s+г",
        r"31\s+декабря\s+(\d{4})",
        r"на\s+31\s+декабря\s+(\d{4})",
        r"отчетный\s+период[^0-9]{0,40}(\d{4})",
        r"отчётный\s+период[^0-9]{0,40}(\d{4})",
        r"бухгалтерск[а-яё\s]{0,20}отчетност[а-яё\s]{0,20}за\s+(\d{4})",
        r"бухгалтерск[а-яё\s]{0,20}отчётност[а-яё\s]{0,20}за\s+(\d{4})",
    )
    for pattern in patterns:
        for match in re.finditer(pattern, lower):
            years.add(match.group(1))
    return years


def _opinion_fragments(text: str, *, window: int = 10_000) -> list[str]:
    lower = _lower(text)
    fragments: list[str] = []
    for marker in (
        "мнение аудитора",
        "по нашему мнению",
        "выражаем мнение",
        "аудиторское мнение",
        "выводы",
        "аудиторское заключение",
        "выдержка словами",
        "основание для выражения мнения",
    ):
        start = 0
        while True:
            idx = lower.find(marker, start)
            if idx < 0:
                break
            fragments.append(lower[idx : idx + window])
            start = idx + len(marker)
    if fragments:
        return fragments
    return [lower[:window]] if lower else []


_QUALIFIED_WINDOW_MARKERS = (
    r"кроме",
    r"модифицирован",
    r"за\s+исключением\s+влияни",
    r"мнени[ея]\s+с\s+оговорк",
    r"основани[ея]\s+для\s+выражени[яе]\s+мнени[яe]\s+с\s+оговорк",
)


def _window_has_qualified_opinion(window: str) -> bool:
    if re.search(r"без\s+оговор", window):
        return False
    if re.search(r"немодифицирован", window):
        return False
    return any(re.search(pattern, window) for pattern in _QUALIFIED_WINDOW_MARKERS)


def _detect_opinion_by_context(lower: str) -> str | None:
    fragments = _opinion_fragments(lower)
    search_spaces = fragments if fragments else [lower[:25_000]]

    for chunk in search_spaces:
        if re.search(
            r"отражает\s+достоверно\s+во\s+всех\s+существенных\s+отношениях",
            chunk,
        ) and not _window_has_qualified_opinion(chunk):
            return "unqualified"
        if re.search(
            r"прилагаем[а-яё\s]{0,40}бухгалтерск[а-яё\s]{0,40}отч[её]тност[^.]{0,1200}?"
            r"(?:отражает|представляет)\s+достоверно",
            chunk,
            re.DOTALL,
        ) and not _window_has_qualified_opinion(chunk):
            return "unqualified"

    for chunk in search_spaces:
        if re.search(r"мнени[ея]\s+с\s+оговорк", chunk):
            return "qualified"
        if "основание для выражения мнения с оговоркой" in chunk:
            return "qualified"

        for match in re.finditer(r"по\s+нашему\s+мнению", chunk):
            window = chunk[match.start() : match.end() + 3500]
            if re.search(r"достоверн|правдив|существенных\s+искажений\s+не", window):
                if not _window_has_qualified_opinion(window):
                    return "unqualified"
            if _window_has_qualified_opinion(window):
                return "qualified"

        for match in re.finditer(r"выражаем\s+мнение", chunk):
            window = chunk[match.start() : match.end() + 2500]
            if re.search(r"немодифицирован|без\s+оговор|достоверн|правдив", window):
                if not _window_has_qualified_opinion(window):
                    return "unqualified"
            if _window_has_qualified_opinion(window):
                return "qualified"

        if re.search(r"положительн[оеа]+\s+мнени", chunk) and not re.search(r"оговорк", chunk):
            return "unqualified"
        if re.search(r"не\s+содержит\s+существенных\s+искажений", chunk):
            return "unqualified"
        if re.search(r"существенных\s+искажений\s+не\s+(?:выявлен|обнаружен|имеется)", chunk):
            return "unqualified"
    return None


def _detect_opinion_in_text(text: str) -> str:
    lower = _lower(text)
    fragments = _opinion_fragments(text)

    context = _detect_opinion_by_context(lower)
    if context:
        return context

    if _has_qualified_basis(lower):
        return "qualified"
    if _has_unqualified_basis(lower):
        return "unqualified"

    qualified_patterns = (
        r"мнени[ея]\s+с\s+оговорк",
        r"модифицированн[ое]+\s+мнени",
        r"основани[ея]\s+для\s+выражени[яе]\s+мнени[яе]\s+с\s+оговорк",
        r"оговорочн[а-яё]{0,12}\s+мнени",
        r"выражаем\s+мнение\s+с\s+оговорк",
        r"за\s+исключением\s+влияни[яе]",
    )
    for pattern in qualified_patterns:
        if re.search(pattern, lower):
            return "qualified"

    qualified_fragment_patterns = (
        r"по нашему мнению[^.]{0,2500}?за\s+исключением",
        r"по нашему мнению[^.]{0,2000}?кроме",
        r"отражает достоверно[^.]{0,2000}?кроме",
        r"представляет достоверно[^.]{0,2000}?кроме",
        r"во всех существенных отношениях[^.]{0,600}?кроме",
        r"да[её]т\s+правдив[^.]{0,2000}?кроме",
        r"да[её]т\s+достоверн[^.]{0,2000}?кроме",
    )
    for fragment in fragments:
        for pattern in qualified_fragment_patterns:
            if re.search(pattern, fragment, re.DOTALL):
                return "qualified"

    unqualified_patterns = (
        r"отражает достоверно во всех существенных отношениях",
        r"представляет достоверно во всех существенных отношениях",
        r"да[её]т\s+правдивое\s+и\s+достоверное\s+представление",
        r"да[её]т\s+правдивое\s+представление",
        r"да[её]т\s+достоверное\s+представление",
        r"существенных\s+искажений\s+не\s+(?:выявлен|обнаружен|имеет)",
        r"немодифицированн[ое]+\s+мнени",
        r"выражаем\s+немодифицированн[ое]+\s+мнени",
        r"выражаем\s+мнение[^.]{0,400}?без\s+оговор",
        r"мнение\s+без\s+оговор",
    )
    for fragment in fragments:
        for pattern in unqualified_patterns:
            if re.search(pattern, fragment, re.DOTALL):
                return "unqualified"

    for fragment in fragments:
        if "по нашему мнению" in fragment and "кроме" not in fragment and "исключением" not in fragment:
            if re.search(r"(?:отражает|представляет)\s+достоверно", fragment):
                return "unqualified"
            if re.search(r"да[её]т\s+(?:правдив|достоверн)", fragment):
                return "unqualified"
        if re.search(
            r"прилагаем[а-яё\s]{0,40}бухгалтерск[а-яё\s]{0,40}отч[её]тност",
            fragment,
        ) and re.search(r"(?:отражает|представляет)\s+достоверно", fragment):
            if "кроме" not in fragment and "исключением" not in fragment and "оговорк" not in fragment:
                return "unqualified"

    return "unknown"


def _detect_opinion(text: str, *, opinion_text: str | None = None, pdf_bytes: bytes | None = None) -> str:
    sources: list[str] = []
    if opinion_text and opinion_text.strip():
        sources.append(opinion_text)
    if text.strip() and text not in sources:
        sources.append(text)
    for source in sources:
        result = _detect_opinion_in_text(source)
        if result != "unknown":
            return result
    if pdf_bytes:
        raw_hit = _opinion_from_raw_pdf_bytes(pdf_bytes)
        if raw_hit:
            return raw_hit
    return "unknown"


def detect_opinion_in_text(text: str) -> str:
    """Быстрое определение мнения только по уже извлечённому тексту."""
    return _detect_opinion_in_text(text)


def opinion_marker_hits(text: str, *, pdf_bytes: bytes | None = None) -> dict[str, bool]:
    """Отладочные маркеры по тексту; pdf_bytes игнорируется (без OCR и mining)."""
    del pdf_bytes
    lower = _lower(text)
    tail = lower[-150_000:] if len(lower) > 150_000 else lower
    return {
        "po_nashemu_mneniyu": "по нашему мнению" in lower,
        "osnovanie": "основание для выражения мнения" in lower,
        "dostoverno": "достоверно" in lower,
        "krome": "кроме" in lower,
        "ogovorka": "оговорк" in lower,
        "tail_mnenie": "по нашему мнению" in tail or "мнение аудитора" in tail,
        "mnenie_s_ogovorkoy": "мнение с оговоркой" in lower,
    }


def _year_matches(text: str, expected_year: str) -> bool:
    year = str(expected_year or "").strip()
    if not year.isdigit():
        return False
    years = _report_years(text)
    if year in years:
        return True
    lower = _lower(text)
    return year in lower


def _names_match(text: str, expected_names: list[str], *, inn: str | None, ogrn: str | None) -> bool:
    lower = _lower(text)
    if inn and inn in re.sub(r"\D", "", text):
        return True
    if ogrn and ogrn in re.sub(r"\D", "", text):
        return True

    keys = [_normalize_org_key(name) for name in expected_names if name and _normalize_org_key(name)]
    keys = [key for key in keys if len(key) >= 4]
    if not keys:
        return False

    quoted = [_normalize_org_key(name) for name in _quoted_names(text)]
    for key in keys:
        for candidate in quoted:
            if key in candidate or candidate in key:
                return True
        compact = re.sub(r"[^0-9a-zа-яё]+", "", lower)
        if key in compact:
            return True
        if len(key) >= 8 and key[:8] in compact:
            return True
    return False


def analyze_audit_text(
    text: str,
    *,
    expected_year: str,
    expected_names: list[str | None],
    inn: str | None = None,
    ogrn: str | None = None,
    trusted_audit: bool = False,
    confirm_year: bool = False,
    opinion_text: str | None = None,
    pdf_bytes: bytes | None = None,
) -> AuditAnalysis:
    clean = _squash(text)
    opinion_source = _squash(opinion_text) if opinion_text else clean
    names = [name for name in expected_names if name]
    is_audit = _is_audit_report(clean, trusted=trusted_audit)
    year_ok = _year_matches(clean, expected_year) or confirm_year
    org_ok = _names_match(clean, names, inn=inn, ogrn=ogrn)
    opinion = (
        _detect_opinion(clean, opinion_text=opinion_source, pdf_bytes=pdf_bytes)
        if is_audit
        else "unknown"
    )

    details: list[str] = []
    if not is_audit:
        return AuditAnalysis(
            is_audit_report=False,
            year_ok=False,
            org_ok=False,
            opinion="unknown",
            status=AUDIT_ANALYSIS_NOT_DONE,
            details=["Документ не похож на аудиторское заключение"],
        )

    details.append("Документ распознан как аудиторское заключение")
    if any(marker in _lower(clean) for marker in _FEDRESURS_EXCERPT_MARKERS[:3]):
        details.append("Источник: выдержка с Федресурса")
    elif trusted_audit and "результаты обязательного аудита" in _lower(clean):
        details.append("Источник: публикация обязательного аудита на Федресурсе")

    if year_ok:
        details.append(f"Отчетный год совпадает: {expected_year}")
    else:
        found_years = sorted(_report_years(clean))
        if found_years:
            details.append(f"Год в документе: {', '.join(found_years)}; ожидался {expected_year}")
        else:
            details.append(f"Отчетный год {expected_year} в документе не найден")

    if org_ok:
        details.append("Организация в документе совпадает")
    else:
        quoted = _quoted_names(clean)
        if quoted:
            details.append(f"В документе указано: «{quoted[0]}»")
        details.append("Название организации не совпало с карточкой")

    if opinion == "unqualified" and not year_ok:
        status = AUDIT_ANALYSIS_NOT_DONE
        details.append("Мнение не учитывается: год АЗ не совпадает с отчётным")
    elif opinion == "qualified" and not year_ok:
        status = AUDIT_ANALYSIS_NOT_DONE
        details.append("Мнение не учитывается: год АЗ не совпадает с отчётным")
    elif opinion == "unqualified":
        status = "АЗ без оговорки"
        if _has_unqualified_basis(_lower(clean)):
            details.append('Раздел: «Основание для выражения мнения»')
        else:
            details.append("Мнение аудитора: без оговорки")
    elif opinion == "qualified":
        status = "АЗ с оговоркой"
        if _has_qualified_basis(_lower(clean)):
            details.append('Раздел: «Основание для выражения мнения с оговоркой»')
        else:
            details.append("Мнение аудитора: с оговоркой")
    else:
        status = AUDIT_ANALYSIS_NOT_DONE
        details.append("Не удалось однозначно определить наличие оговорки")

    return AuditAnalysis(
        is_audit_report=is_audit,
        year_ok=year_ok,
        org_ok=org_ok,
        opinion=opinion,
        status=status,
        details=details,
    )
