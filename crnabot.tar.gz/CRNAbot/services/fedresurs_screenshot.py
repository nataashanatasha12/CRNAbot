from __future__ import annotations

import asyncio
import logging
import re
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from services.cookie_consent import dismiss_cookie_consent
from services.fedresurs import FEDRESURS_BASE, current_calendar_year, publications_card_url

logger = logging.getLogger("crnabot.fedresurs_screenshot")

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
)

_playwright_ref = None
_browser_ref = None
_browser_lock = None


def _get_browser_lock():
    global _browser_lock
    if _browser_lock is None:
        _browser_lock = asyncio.Lock()
    return _browser_lock


def _playwright_available() -> bool:
    try:
        import playwright  # noqa: F401

        return True
    except ImportError:
        return False


async def _launch_browser(playwright):
    launch_kwargs = {
        "headless": True,
        "args": ["--disable-blink-features=AutomationControlled"],
    }
    for channel in ("chrome", "chromium"):
        try:
            if channel == "chrome":
                return await playwright.chromium.launch(channel="chrome", **launch_kwargs)
            return await playwright.chromium.launch(**launch_kwargs)
        except Exception as exc:
            logger.info("Fedresurs Playwright launch via %s failed: %s", channel, exc)
    return None


async def _reset_browser() -> None:
    global _playwright_ref, _browser_ref
    if _browser_ref is not None:
        try:
            await _browser_ref.close()
        except Exception:
            pass
    _browser_ref = None
    if _playwright_ref is not None:
        try:
            await _playwright_ref.stop()
        except Exception:
            pass
    _playwright_ref = None


async def _ensure_browser():
    global _playwright_ref, _browser_ref
    if _browser_ref is not None:
        try:
            if _browser_ref.is_connected():
                return _browser_ref
        except Exception:
            pass
        await _reset_browser()
    from playwright.async_api import async_playwright

    _playwright_ref = await async_playwright().start()
    _browser_ref = await _launch_browser(_playwright_ref)
    if _browser_ref is None:
        raise RuntimeError("Не удалось запустить браузер для скриншота Федресурса.")
    return _browser_ref


def _page_blocked(text: str) -> bool:
    sample = (text or "").strip()
    if not sample:
        return True
    lower = sample.lower()
    if "403 forbidden" in lower:
        return True
    if lower.startswith("403") and "nginx" in lower and len(sample) < 400:
        return True
    return False


def _with_year_query(url: str, year: str) -> str:
    parsed = urlparse(url)
    params = dict(parse_qsl(parsed.query, keep_blank_values=True))
    params["startDate"] = f"{year}-01-01T00:00:00.000Z"
    params["endDate"] = f"{int(year) + 1}-01-01T00:00:00.000Z"
    return urlunparse(parsed._replace(query=urlencode(params)))


async def _install_publications_year_route(page, year: str) -> None:
    year = str(year).strip()

    async def _handler(route) -> None:
        request = route.request
        url = request.url
        if "/backend/companies/" in url and "/publications" in url:
            await route.continue_(url=_with_year_query(url, year))
            return
        await route.continue_()

    await page.route(re.compile(r".*/backend/companies/.*/publications.*"), _handler)


async def _wait_publications_ready(page, timeout_ms: int = 25000) -> bool:
    try:
        await page.wait_for_function(
            """() => {
                const text = (document.body?.innerText || '').replace(/\\s+/g, ' ');
                if (/403 Forbidden/i.test(text)) return false;
                return /публикац/i.test(text);
            }""",
            timeout=timeout_ms,
        )
        return True
    except Exception:
        return False


def _parse_publications_count(text: str) -> int | None:
    match = re.search(r"Найдено записей\s+(\d+)", text or "", re.IGNORECASE)
    if not match:
        return None
    try:
        return int(match.group(1))
    except ValueError:
        return None


async def _get_publications_count(page) -> int | None:
    try:
        body = await page.inner_text("body")
        return _parse_publications_count(body)
    except Exception:
        return None


async def _type_angular_date_field(field, value: str) -> None:
    """Ввод даты посимвольно, чтобы Angular ngModel принял значение."""
    await field.click(click_count=3)
    await field.press("Backspace")
    await field.press_sequentially(value, delay=50)
    await field.press("Tab")


async def _find_publications_search_button(page):
    wrap = page.locator(".datepicker-range-wrap")
    if await wrap.count():
        parent_btn = wrap.locator("xpath=..").locator("button.el-button").first
        if await parent_btn.count():
            return parent_btn
    buttons = page.locator("button.el-button")
    count = await buttons.count()
    for idx in range(count):
        btn = buttons.nth(idx)
        label = (await btn.inner_text()).strip()
        if label and "подпис" in label.lower():
            continue
        if not label:
            return btn
    if count > 1:
        return buttons.nth(1)
    return buttons.first


async def _wait_filtered_publications(
    page,
    *,
    year: str,
    initial_count: int | None,
    timeout_ms: int = 20000,
) -> bool:
    year = str(year).strip()
    try:
        await page.wait_for_function(
            """({year, initialCount}) => {
                const href = window.location.href;
                const periodMatch = href.match(/period=([^&]+)/);
                if (periodMatch) {
                    const raw = decodeURIComponent(periodMatch[1] || '');
                    if (raw && raw !== '{}' && raw !== '%7B%7D') {
                        return true;
                    }
                }
                const text = (document.body?.innerText || '').replace(/\\s+/g, ' ');
                const countMatch = text.match(/Найдено записей\\s+(\\d+)/i);
                const count = countMatch ? parseInt(countMatch[1], 10) : null;
                if (initialCount !== null && count !== null && count !== initialCount) {
                    return true;
                }
                const yearRe = new RegExp(`\\\\b${year}\\\\b`);
                if (count === 1 && yearRe.test(text)) {
                    return true;
                }
                return false;
            }""",
            arg={"year": year, "initialCount": initial_count},
            timeout=timeout_ms,
        )
        await page.wait_for_timeout(1200)
        return True
    except Exception as exc:
        logger.info(
            "Fedresurs filter wait timeout year=%s initial_count=%s: %s",
            year,
            initial_count,
            exc,
        )
        return False


async def _apply_year_filter_ui(page, year: str) -> bool:
    """Выставляет период на странице Федресурса через Angular-bound inputs."""
    year = str(year).strip()
    start = f"01.01.{year}"
    end = f"31.12.{year}"

    from_field = page.locator(".datepicker-range-wrap__input-field_from")
    to_field = page.locator(".datepicker-range-wrap__input-field_to")
    try:
        await from_field.wait_for(state="visible", timeout=15000)
        await to_field.wait_for(state="visible", timeout=15000)
    except Exception as exc:
        logger.info("Fedresurs datepicker not found year=%s: %s", year, exc)
        return False

    initial_count = await _get_publications_count(page)
    logger.info(
        "Fedresurs publications before filter year=%s count=%s",
        year,
        initial_count,
    )

    await _type_angular_date_field(from_field, start)
    await _type_angular_date_field(to_field, end)

    search_btn = await _find_publications_search_button(page)
    try:
        await search_btn.wait_for(state="visible", timeout=5000)
        for _ in range(20):
            if await search_btn.is_enabled():
                break
            await page.wait_for_timeout(250)
    except Exception:
        pass

    await search_btn.click()
    applied = await _wait_filtered_publications(page, year=year, initial_count=initial_count)
    final_count = await _get_publications_count(page)
    logger.info(
        "Fedresurs publications after filter year=%s count=%s applied=%s url=%s",
        year,
        final_count,
        applied,
        page.url,
    )
    return applied


async def _open_publications_page(page, company_guid: str, *, inn: str = "") -> bool:
    card_url = f"{FEDRESURS_BASE}/companies/{company_guid}"
    publications_url = publications_card_url(company_guid)
    inn = inn.strip()

    steps: list[tuple[str, str]] = [(f"{FEDRESURS_BASE}/", "domcontentloaded")]
    if inn:
        steps.append((f"{FEDRESURS_BASE}/entities?searchString={inn}", "domcontentloaded"))
    steps.extend([(card_url, "load"), (publications_url, "load")])

    for idx, (url, wait_until) in enumerate(steps):
        is_last = idx == len(steps) - 1
        try:
            await page.goto(url, wait_until=wait_until, timeout=60000)
            await page.wait_for_timeout(2000 if is_last else 1200)
            if is_last:
                await dismiss_cookie_consent(page, site="fedresurs")
            body = await page.inner_text("body")
            if _page_blocked(body):
                logger.info("Fedresurs blocked on url=%s guid=%s", url, company_guid)
                if is_last:
                    return False
                continue
        except Exception as exc:
            logger.info("Fedresurs navigation failed url=%s guid=%s: %s", url, company_guid, exc)
            if is_last:
                return False
    return await _wait_publications_ready(page)


async def _capture_live_publications(
    page,
    company_guid: str,
    *,
    inn: str,
    year: str,
) -> bytes | None:
    await _install_publications_year_route(page, year)
    if not await _open_publications_page(page, company_guid, inn=inn):
        return None

    body = await page.inner_text("body")
    if _page_blocked(body):
        return None

    if not await _apply_year_filter_ui(page, year):
        logger.info("Fedresurs year filter may not have applied guid=%s year=%s", company_guid, year)

    body = await page.inner_text("body")
    if _page_blocked(body):
        return None

    await dismiss_cookie_consent(page, site="fedresurs")
    data = await page.screenshot(full_page=True, type="png", animations="disabled")
    if len(data) < 1000:
        return None
    return data


async def _wait_publication_ready(page, timeout_ms: int = 25000) -> bool:
    try:
        await page.wait_for_function(
            """() => {
                const text = (document.body?.innerText || '').replace(/\\s+/g, ' ');
                if (/403 Forbidden/i.test(text)) return false;
                return /аудит|мнение|публикац|отчетн/i.test(text);
            }""",
            timeout=timeout_ms,
        )
        return True
    except Exception:
        return False


async def capture_fedresurs_publication_png(
    publication_url: str,
    *,
    inn: str | None = None,
    company_guid: str | None = None,
) -> bytes | None:
    """Скриншот карточки публикации на fedresurs.ru (например, «Результаты обязательного аудита»)."""
    url = (publication_url or "").strip()
    if not url:
        return None
    if not _playwright_available():
        logger.info("Playwright не установлен — скриншот публикации Федресурса пропущен url=%s", url)
        return None

    async with _get_browser_lock():
        context = page = None
        try:
            browser = await _ensure_browser()
            context = await browser.new_context(
                user_agent=USER_AGENT,
                locale="ru-RU",
                viewport={"width": 1440, "height": 1000},
                device_scale_factor=2,
                extra_http_headers={"Accept-Language": "ru-RU,ru;q=0.9"},
            )
            page = await context.new_page()
            if company_guid and inn:
                await _open_publications_page(page, company_guid, inn=inn)
            await page.goto(url, wait_until="load", timeout=60000)
            await page.wait_for_timeout(2000)
            body = await page.inner_text("body")
            if _page_blocked(body):
                logger.info("Fedresurs publication blocked url=%s", url)
                return None
            if not await _wait_publication_ready(page):
                logger.info("Fedresurs publication page not ready url=%s", url)
            await dismiss_cookie_consent(page, site="fedresurs")
            data = await page.screenshot(full_page=True, type="png", animations="disabled")
            if len(data) < 1000:
                return None
            logger.info("Fedresurs publication screenshot OK url=%s size=%s", url, len(data))
            return data
        except Exception as exc:
            logger.info("Fedresurs publication screenshot error url=%s: %s", url, exc)
            await _reset_browser()
            return None
        finally:
            if page:
                try:
                    await page.close()
                except Exception:
                    pass
            if context:
                try:
                    await context.close()
                except Exception:
                    pass


async def capture_fedresurs_publications_png(
    company_guid: str,
    *,
    inn: str | None = None,
    year: str | None = None,
    company_name: str | None = None,
    company_ogrn: str | None = None,
) -> bytes | None:
    """Реальный скриншот страницы публикаций на fedresurs.ru за текущий календарный год."""
    guid = (company_guid or "").strip()
    if not guid:
        return None
    if not _playwright_available():
        logger.info("Playwright не установлен — скриншот Федресурса пропущен guid=%s", guid)
        return None

    filter_year = str(year or current_calendar_year())
    _ = company_name, company_ogrn

    async with _get_browser_lock():
        context = page = None
        try:
            browser = await _ensure_browser()
            context = await browser.new_context(
                user_agent=USER_AGENT,
                locale="ru-RU",
                viewport={"width": 1440, "height": 1000},
                device_scale_factor=2,
                extra_http_headers={"Accept-Language": "ru-RU,ru;q=0.9"},
            )
            page = await context.new_page()
            data = await _capture_live_publications(
                page,
                guid,
                inn=inn or "",
                year=filter_year,
            )
            if data:
                logger.info(
                    "Fedresurs live screenshot OK guid=%s year=%s size=%s",
                    guid,
                    filter_year,
                    len(data),
                )
            else:
                logger.info("Fedresurs live screenshot unavailable guid=%s year=%s", guid, filter_year)
            return data
        except Exception as exc:
            logger.info("Fedresurs screenshot error guid=%s: %s", guid, exc)
            await _reset_browser()
            return None
        finally:
            if page:
                try:
                    await page.close()
                except Exception:
                    pass
            if context:
                try:
                    await context.close()
                except Exception:
                    pass
